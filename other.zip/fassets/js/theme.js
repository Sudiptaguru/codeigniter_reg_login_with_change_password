$(document).ready (function(){

$(".file-upload").on('change', function(){
          readURL(this);
    });


   var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.profile-pic').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
	
var cc = $('#menuSlider');
cc.owlCarousel({
	autoplay:true,
    loop:false,	
	margin:15,
    nav:false,
	dots:true,
	//smartSpeed:3000,
	//animateOut: 'fadeOut',
    items: 3,
	//navText: [ '<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>' ],
	
	responsive : {
    // breakpoint from 0 up
   0:{
            items:1,
        },
    // breakpoint from 480 up
   480:{
            items:1,
        },
    // breakpoint from 768 up
    768:{
            items:2,
        },
		// breakpoint from 768 up
    992:{
            items:3,
        }
}
});
	
	
var cc = $('#chefsSlider');
cc.owlCarousel({
	autoplay:true,
    loop:false,	
	margin:0,
    nav:false,
	dots:true,
	//smartSpeed:3000,
	//animateOut: 'fadeOut',
    items: 1,
	//navText: [ '<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>' ],
	

});
	
	
	
	
});




