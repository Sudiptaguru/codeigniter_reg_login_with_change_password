<?php
class Common_model extends CI_Model {
 
	/**
	* Responsable for auto load the database
	* @return void
	*/
	
	function add($table,$data){
		  $this->db->insert($table, $data);
		  return $this->db->insert_id();
	}
	function update($table,$data,$condition=null){
		if(isset($condition)){
				foreach($condition as $key => $value){
					  $this->db->where($key,$value);
				}
		}
		$this->db->update($table, $data);
		return true;
  
	}
	public function upddata($data)       
    {
        $this->db->where('cms_id',$data['cms_id']);
        $this->db->update('cms_master', $data);
    }

    public function delete_data($cms_id)
    {
        $this -> db -> where('cms_id', $cms_id);
        $this -> db -> delete('cms_master');
    }
	public function getRows($table, $condition, $order_by='', $group_by='',$limit = '')
	{
        $this->db->where($condition);        
        /*if($table=='tbl_package'){
            $this->db->order_by('category_id','asc');          
        }else{
            $this->db->order_by('date_of_creation', 'desc');
        }*/
        if (isset($order_by)) {
          $this->db->order_by($order_by);          
        }
         if (isset($limit)) {
          $this->db->limit($limit);          
        }

        if (isset($group_by)) {
          $this->db->group_by($group_by);          
        }

        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->result_array();    
        }

        return $res;            
    } 


	public function getRow($table,$condition){
        $this->db->where($condition);        
        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->row_array();    
        }
        return $res;            
    } 
	public function get($table,$what=null,$condition=null,$limit_start=null, $limit_end=null,$group=null,$condition1=null,$order_in=null,$order_by='DESC',$join=null,$join_type=null)
	{
		if(isset($what)){
				foreach ($what as $key => $value){
					$this->db->select($value);
				}
		}else{
				$this->db->select('*');
		}
		
		$this->db->from($table);
		if(isset($condition)){
				foreach ($condition as $key => $value){
					$this->db->where($key,$value);
				}
		}
		if(isset($condition1) && !empty($condition1)){
				$this->db->where($condition1);
		}
		if(isset($join)){
			 foreach ($join as $key => $value){
					$this->db->join($key,$value,$join_type[$key]);
			 }
		}
		if($limit_start != null){
					$this->db->limit($limit_start, $limit_end);    
		}
		if($group != null){
					$this->db->group_by($group);
		}
		
		if($order_in != null ){
			$this->db->order_by($order_in,$order_by);
		}
		$query = $this->db->get();
		return $query->result_array();
	}
	function count($table,$condition=null,$limit_start=null, $limit_end=null)
	{
		$this->db->select('*');
		$this->db->from($table);
		if(isset($condition)){
				foreach ($condition as $key => $value){
					 $this->db->where($key,$value);
				}
		}
		if($limit_start != null){
					$this->db->limit($limit_start, $limit_end);    
		}
		$query = $this->db->get();
		return $query->num_rows();        
	}
	function delete($table,$condition=null){
		if(isset($condition)){
				foreach ($condition as $key => $value){
						$this->db->where($key,$value);
			  }
		}
		$this->db->delete($table);
		return true;
	}
	function get_time_diff( $start,$end)
	{
		$uts['start'] = strtotime( $start );
		$uts['end'] = strtotime( $end );

		if( $uts['start']!==-1 && $uts['end']!==-1 ){
					if($uts['end'] >= $uts['start'] ){
					
						$diff = $uts['end'] - $uts['start'];
						if( $year=intval((floor($diff/(365*86400)))) )
							 $diff = $diff % (365*86400);
						if( $months=intval((floor($diff/(30*86400)))) )
							 $diff = $diff % (30*86400);
						if( $days=intval((floor($diff/86400))) )
							 $diff = $diff % 86400;
						if( $hours=intval((floor($diff/3600))) )
							 $diff = $diff % 3600;
						if( $minutes=intval((floor($diff/60))) )
							 $diff = $diff % 60;
	
						$diff = intval( $diff );
						$start= array('years'=>$year,'months'=>$months,'days'=>$days, 'hours'=>$hours, 'minutes'=>$minutes, 'seconds'=>$diff) ;
						if($start['years']>0)
							 {return( $start['years']);}
						elseif($start['months']>0)
							 {return( '');}
						else
							 {return( '');}
					}else{
						return '';
					}
		}else{
				return '';
		}
		return( false );
	}
   public function uploadImage($field,$DIR)
	{
		$return = false;
		if(!empty($_FILES[$field]['name']))
		{
			$allowed =  array('gif','png' ,'jpg','jpeg','JPG','JPEG','PNG','GIF');
			$ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
			if(in_array($ext,$allowed))
			{
				$filename=time().rand(0,99)."_".$field.".".$ext;
				move_uploaded_file($_FILES[$field]['tmp_name'],$DIR.$filename);
				
				$return = $filename;
			}
		}
		return $return;
	}
	public function mail($companyName='',$email_from='',$email_to='',$subject,$message,$IsSMTP=true)
	{
		if(!empty($email_to))
		{
			if($IsSMTP)
			{
				$config['protocol']     = 'smtp';
				$config['smtp_host']    = 'ssl://mail.fitser.com';
				$config['smtp_port']    = '465';        
				//$config['smtp_user']  = 'developer.net@met-technologies.com';
				//$config['smtp_pass']  = 'Dot123@#$%';
				$config['smtp_user']    = 'test@fitser.com';
				$config['smtp_pass']    = 'Test123@';
				$config['charset']      = 'utf-8';
				$config['newline']      = "\r\n";
				$config['mailtype']     = 'html'; // or html
				$config['validation']   = TRUE; // bool whether to validate email or not 
			}
			else
			{
				$config['charset'] = 'utf-8';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
			}
			
			$this->email->initialize($config);
			$this->email->from($email_from, $companyName);
			
			$this->email->to($email_to);
			//$this->email->cc('santu.dutta@met-technologies.com');
			$this->email->subject($subject);
			$this->email->message($message);
			return $this->email->send();
		}
		else
		{
			return false;
		}
	}
}
?>