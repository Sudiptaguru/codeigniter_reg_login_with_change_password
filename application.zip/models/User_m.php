<?php
class User_m extends CI_Model
{
	
	
	function __construct ()
	{
		parent::__construct();
	}

	public function validate ($email, $password)
	{
		
		$this->db->where('email',$email);
	
		$query	=	$this->db->get('user');
      //  echo $this-> db -> last_query();die;
		
		if ($query->num_rows() > 0){
			
			$record = $query->row();
			$status = $record->status;
			if ($status == "0"){
				 return 2;
			}
			if (password_verify($password, $record->password)){				
				$userdata = array(
									'user_id'=>$record->user_id,
									'first_name'=>$record->first_name,
									'last_name'=>$record->last_name,
									'email'=>$record->email,
                                    'group_id' => $record->group_id,
									'is_logged'=> TRUE
								);
				$this->session->set_userdata($userdata);
				return 1;
			} else {
				return 0; // wrong password
			}	
			
		}  else {
			return -1;
			
		}
	
	}

	public function logout ()
	{
		$arr = array (
					'user_id' => "",
					'email' => "",
					'first_name'=>"",
					'last_name'=>"",
                    'group_id' => "",
					'is_logged' => FALSE
					);
		$this->session->set_userdata($arr);
		return TRUE;
	}

	public function loggedin ()
	{
		return (bool) $this->session->userdata('is_logged');
	}

    public function getUser($id){
     
       $q =  $this -> db -> get_where('user',['user_id' => $id]);

        return $q -> first_row();
    }

    function getNew($table = false){
       
        $f = $this -> db -> list_fields('user');
        $temp = new stdClass();
        $temp -> user_id = false;
        foreach($f as $fields){
            $temp -> $fields = '';
        }
        return $temp;
    }
	

}