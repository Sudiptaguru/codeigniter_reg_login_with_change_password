<?php
class User_H {

    public $id;
    public $name;
    public $role;
    private $row;

   

    
    public static $_PROVIDER = 2;
    public static $_CUSTOMER = 3;
  

    function __construct(){
        $this -> id = false;
        $this -> name = '';
        $this -> role = '';
    }

    function setRow($row){
        $this -> row = $row;
    }

    function __set($key, $val){
        $this -> row -> $key = $val;
    }

    function __get($key){
        return $this -> row -> $key;
    }

    function getID(){
        return $this -> id;
    }

    function setID($id){
        $this -> id = $id;
    }

    function setRole($role){
        $this -> role = $role;
    }

    function getRole(){
        return $this -> role;
    }

    function goToDashboard(){
        if($this -> role == User_H::$_PROVIDER){
            return base_url("provider/Dashboard");
        }elseif($this -> role == User_H::$_CUSTOMER){
            return base_url("user/Dashboard");
        }
    }

    public static function fromDB($user_id){
    
        $CI =& get_instance();
        $user = $CI -> User_m -> getUser($user_id);
        echo '<pre>';print_r($user);die;
        if(is_object($user)) {
            $u = new User_H();
            $u->setRow($user);
            $u->setID($user->id);
            $u->setRole($user->user_type);
            $u->name = $user->first_name . ' ' . $user->last_name;
        }else{
            $user = $CI -> User_m -> getNew();
            $u = new User_H();
            $u -> setRow($user);
        }
        return $u;
    }

    function isUser(){
        if($this -> role == User_H::$_CUSTOMER){
            return true;
        }else{
            return false;
        }
    }

    function isProvider(){
        if($this -> role == User_H::$_PROVIDER){
            return true;
        }else{
            return false;
        }
    }

    function isPaidMember(){
        return ($this -> membership == "Paid") ? true : false;
    }

    function isLoggedIn(){
        if(isset($_SESSION['login'])){
            $user = $_SESSION['login'];
            if($user -> id == $this -> id){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public static function fromSession(){
        if($_SESSION['is_logged']){
            $login = $_SESSION['login'];
            return $login;
        }else{
            return new AI_User();
        }
    }

    public static function getUserTypes(){
        $ar = array(2 => 'Provider', 3 => 'Provider');
        return $ar;
    }

   

    function getCName(){
        return $this -> company_name;
    }

    function getName(){
        return $this -> name;
    }
}