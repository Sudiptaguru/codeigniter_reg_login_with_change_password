<?php
 class Menu {
 	private $CI;
    private static $instance = null;
    private $group_id;

	 private function __construct() {
       
			$this -> CI =  & get_instance();
			$this -> group_id = $_SESSION['admin_details']['group_id'];

		}

    public static function getInstance() {
        if (self::$instance == null) {
          self::$instance = new Menu();
        }
            return self::$instance;
    }    

	
 	 function category_menu() {
             
   
        $sql = "SELECT  menu.menu_id as mid, menu_name, menu_icon, parent_id, menu_url
                FROM    menu, role_menu
                WHERE   menu.menu_id = role_menu.menu_id
                AND     role_menu.role_id = '".$this -> group_id."'";
             

     
        $query = $this -> CI -> db -> query($sql);

        $cat = array(
            'items' => array(),
            'parents' => array()
        );
        
        foreach ($query->result() as $cats) {
           
            $cat['items'][$cats->mid] = $cats;
           
            $cat['parents'][$cats->parent_id][] = $cats->mid;
        }
       
    
        if ($cat) {
            $result =  $this -> build_category_menu(0, $cat);
            return $result;
        } else {
            return FALSE;
        }
    }

    private function build_category_menu($parent, $menu) {
        $html = "";
        if (isset($menu['parents'][$parent])) {
          
            foreach ($menu['parents'][$parent] as $itemId) {
                if (!isset($menu['parents'][$itemId])) {
                    $html .= "<li class='nav-item'>\n<a class='nav-link' href='".base_url(). $menu['items'][$itemId]->menu_url."'>". $menu['items'][$itemId]->menu_icon.' <p>'.  $menu['items'][$itemId]->menu_name . "</p></a>\n</li>\n";
                }
                

                  if (isset($menu['parents'][$itemId])) {
                	$html .= "<li class='nav-item'>";
                	$html .= '<a href="'.base_url(). $menu['items'][$itemId]->menu_url.'"'.' class="nav-link">';
              		$html .=  $menu['items'][$itemId]->menu_icon;
				    $html .= "<p>";
				    $html .= $menu['items'][$itemId]->menu_name ;
				    $html .= "<i class='right fas fa-angle-left'></i>";
				    $html .= "</p>";				            
				    $html .= "</a>";
                    $html .= "<ul class='nav nav-treeview'>";
                    $html .= $this -> build_category_menu($itemId, $menu);
                    $html .= "</ul>";
                    $html .= "</li>";
                }
            }
          
        }
        return $html;
    }


 }

