<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends My_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this -> load -> model('Account_m');

	}
	

	
	public function updateProfileImage()
	{
		
		$pic = '';
        $files =$_FILES;
        if (!empty($files) && $files['profile_image']['name'] != '') {
        	echo "<pre>";
   //      	print_r($files['profile_image']['name']);die;
			
            $pic = $this->commonFileUpload('uploads/profile/', $files['profile_image']['name'], 'profile_image');
           
            ($this->input->post());
             $data['user_id'] = $this->input->post('user_id');
            $data['profile_pic'] = $pic;
            $this->Account_m->update($data,$user_id);
            echo "Image Uploaded Successfully"; 
            
        }else{

        }	
	}

    function account(){
		/*
		$this -> data['account_detail']  = $this -> Account_m -> get_row();
		$this -> data['main']='user/account';
		$this -> data['title']='My Account';
		$this -> load -> view('user/_layout', $this -> data);
		*/
	}

}