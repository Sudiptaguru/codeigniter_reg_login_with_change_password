<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-26 00:05:58 --> Config Class Initialized
INFO - 2021-03-26 00:05:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:05:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:05:58 --> Utf8 Class Initialized
INFO - 2021-03-26 00:05:58 --> URI Class Initialized
INFO - 2021-03-26 00:05:58 --> Router Class Initialized
INFO - 2021-03-26 00:05:58 --> Output Class Initialized
INFO - 2021-03-26 00:05:58 --> Security Class Initialized
DEBUG - 2021-03-26 00:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:05:58 --> Input Class Initialized
INFO - 2021-03-26 00:05:58 --> Language Class Initialized
ERROR - 2021-03-26 00:05:58 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 42
INFO - 2021-03-26 00:06:29 --> Config Class Initialized
INFO - 2021-03-26 00:06:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:06:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:06:29 --> Utf8 Class Initialized
INFO - 2021-03-26 00:06:29 --> URI Class Initialized
INFO - 2021-03-26 00:06:29 --> Router Class Initialized
INFO - 2021-03-26 00:06:29 --> Output Class Initialized
INFO - 2021-03-26 00:06:29 --> Security Class Initialized
DEBUG - 2021-03-26 00:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:06:29 --> Input Class Initialized
INFO - 2021-03-26 00:06:29 --> Language Class Initialized
ERROR - 2021-03-26 00:06:29 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 42
INFO - 2021-03-26 00:06:31 --> Config Class Initialized
INFO - 2021-03-26 00:06:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:06:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:06:31 --> Utf8 Class Initialized
INFO - 2021-03-26 00:06:31 --> URI Class Initialized
INFO - 2021-03-26 00:06:31 --> Router Class Initialized
INFO - 2021-03-26 00:06:31 --> Output Class Initialized
INFO - 2021-03-26 00:06:31 --> Security Class Initialized
DEBUG - 2021-03-26 00:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:06:31 --> Input Class Initialized
INFO - 2021-03-26 00:06:31 --> Language Class Initialized
ERROR - 2021-03-26 00:06:31 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 42
INFO - 2021-03-26 00:06:47 --> Config Class Initialized
INFO - 2021-03-26 00:06:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:06:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:06:47 --> Utf8 Class Initialized
INFO - 2021-03-26 00:06:47 --> URI Class Initialized
INFO - 2021-03-26 00:06:47 --> Router Class Initialized
INFO - 2021-03-26 00:06:47 --> Output Class Initialized
INFO - 2021-03-26 00:06:47 --> Security Class Initialized
DEBUG - 2021-03-26 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:06:47 --> Input Class Initialized
INFO - 2021-03-26 00:06:47 --> Language Class Initialized
INFO - 2021-03-26 00:06:47 --> Loader Class Initialized
INFO - 2021-03-26 00:06:47 --> Helper loaded: url_helper
INFO - 2021-03-26 00:06:47 --> Helper loaded: form_helper
INFO - 2021-03-26 00:06:47 --> Helper loaded: common_helper
INFO - 2021-03-26 00:06:47 --> Helper loaded: util_helper
INFO - 2021-03-26 00:06:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:06:47 --> Form Validation Class Initialized
INFO - 2021-03-26 00:06:47 --> Controller Class Initialized
INFO - 2021-03-26 00:06:47 --> Model Class Initialized
ERROR - 2021-03-26 00:06:47 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\robust\php\application\models\admin\Permission_m.php 46
INFO - 2021-03-26 00:06:48 --> Config Class Initialized
INFO - 2021-03-26 00:06:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:06:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:06:48 --> Utf8 Class Initialized
INFO - 2021-03-26 00:06:48 --> URI Class Initialized
INFO - 2021-03-26 00:06:48 --> Router Class Initialized
INFO - 2021-03-26 00:06:48 --> Output Class Initialized
INFO - 2021-03-26 00:06:48 --> Security Class Initialized
DEBUG - 2021-03-26 00:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:06:48 --> Input Class Initialized
INFO - 2021-03-26 00:06:48 --> Language Class Initialized
INFO - 2021-03-26 00:06:48 --> Loader Class Initialized
INFO - 2021-03-26 00:06:48 --> Helper loaded: url_helper
INFO - 2021-03-26 00:06:48 --> Helper loaded: form_helper
INFO - 2021-03-26 00:06:48 --> Helper loaded: common_helper
INFO - 2021-03-26 00:06:48 --> Helper loaded: util_helper
INFO - 2021-03-26 00:06:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:06:48 --> Form Validation Class Initialized
INFO - 2021-03-26 00:06:48 --> Controller Class Initialized
INFO - 2021-03-26 00:06:48 --> Model Class Initialized
ERROR - 2021-03-26 00:06:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\robust\php\application\models\admin\Permission_m.php 46
INFO - 2021-03-26 00:07:26 --> Config Class Initialized
INFO - 2021-03-26 00:07:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:26 --> URI Class Initialized
INFO - 2021-03-26 00:07:26 --> Router Class Initialized
INFO - 2021-03-26 00:07:26 --> Output Class Initialized
INFO - 2021-03-26 00:07:26 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:26 --> Input Class Initialized
INFO - 2021-03-26 00:07:26 --> Language Class Initialized
INFO - 2021-03-26 00:07:26 --> Loader Class Initialized
INFO - 2021-03-26 00:07:26 --> Helper loaded: url_helper
INFO - 2021-03-26 00:07:26 --> Helper loaded: form_helper
INFO - 2021-03-26 00:07:26 --> Helper loaded: common_helper
INFO - 2021-03-26 00:07:26 --> Helper loaded: util_helper
INFO - 2021-03-26 00:07:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:07:26 --> Form Validation Class Initialized
INFO - 2021-03-26 00:07:26 --> Controller Class Initialized
INFO - 2021-03-26 00:07:26 --> Model Class Initialized
INFO - 2021-03-26 00:07:26 --> Model Class Initialized
INFO - 2021-03-26 00:07:26 --> Model Class Initialized
INFO - 2021-03-26 00:07:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:07:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:07:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:07:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:07:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:07:26 --> Final output sent to browser
DEBUG - 2021-03-26 00:07:26 --> Total execution time: 0.0414
INFO - 2021-03-26 00:07:26 --> Config Class Initialized
INFO - 2021-03-26 00:07:26 --> Config Class Initialized
INFO - 2021-03-26 00:07:26 --> Hooks Class Initialized
INFO - 2021-03-26 00:07:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:26 --> Utf8 Class Initialized
DEBUG - 2021-03-26 00:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:26 --> Config Class Initialized
INFO - 2021-03-26 00:07:26 --> URI Class Initialized
INFO - 2021-03-26 00:07:26 --> Hooks Class Initialized
INFO - 2021-03-26 00:07:26 --> URI Class Initialized
INFO - 2021-03-26 00:07:26 --> Router Class Initialized
INFO - 2021-03-26 00:07:26 --> Router Class Initialized
INFO - 2021-03-26 00:07:26 --> Output Class Initialized
DEBUG - 2021-03-26 00:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:26 --> Output Class Initialized
INFO - 2021-03-26 00:07:26 --> Security Class Initialized
INFO - 2021-03-26 00:07:26 --> URI Class Initialized
DEBUG - 2021-03-26 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:26 --> Security Class Initialized
INFO - 2021-03-26 00:07:26 --> Input Class Initialized
INFO - 2021-03-26 00:07:26 --> Language Class Initialized
INFO - 2021-03-26 00:07:26 --> Router Class Initialized
DEBUG - 2021-03-26 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:26 --> Input Class Initialized
ERROR - 2021-03-26 00:07:26 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:26 --> Language Class Initialized
INFO - 2021-03-26 00:07:26 --> Output Class Initialized
ERROR - 2021-03-26 00:07:26 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:26 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:26 --> Input Class Initialized
INFO - 2021-03-26 00:07:26 --> Config Class Initialized
INFO - 2021-03-26 00:07:26 --> Language Class Initialized
INFO - 2021-03-26 00:07:26 --> Hooks Class Initialized
ERROR - 2021-03-26 00:07:26 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:27 --> URI Class Initialized
INFO - 2021-03-26 00:07:27 --> Router Class Initialized
INFO - 2021-03-26 00:07:27 --> Output Class Initialized
INFO - 2021-03-26 00:07:27 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:27 --> Input Class Initialized
INFO - 2021-03-26 00:07:27 --> Language Class Initialized
ERROR - 2021-03-26 00:07:27 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:52 --> Config Class Initialized
INFO - 2021-03-26 00:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:52 --> URI Class Initialized
INFO - 2021-03-26 00:07:52 --> Router Class Initialized
INFO - 2021-03-26 00:07:52 --> Output Class Initialized
INFO - 2021-03-26 00:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:52 --> Input Class Initialized
INFO - 2021-03-26 00:07:52 --> Language Class Initialized
INFO - 2021-03-26 00:07:52 --> Loader Class Initialized
INFO - 2021-03-26 00:07:52 --> Helper loaded: url_helper
INFO - 2021-03-26 00:07:52 --> Helper loaded: form_helper
INFO - 2021-03-26 00:07:52 --> Helper loaded: common_helper
INFO - 2021-03-26 00:07:52 --> Helper loaded: util_helper
INFO - 2021-03-26 00:07:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:07:52 --> Form Validation Class Initialized
INFO - 2021-03-26 00:07:52 --> Controller Class Initialized
INFO - 2021-03-26 00:07:52 --> Model Class Initialized
INFO - 2021-03-26 00:07:52 --> Model Class Initialized
INFO - 2021-03-26 00:07:52 --> Model Class Initialized
INFO - 2021-03-26 00:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:07:52 --> Final output sent to browser
DEBUG - 2021-03-26 00:07:52 --> Total execution time: 0.0507
INFO - 2021-03-26 00:07:52 --> Config Class Initialized
INFO - 2021-03-26 00:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:52 --> URI Class Initialized
INFO - 2021-03-26 00:07:52 --> Router Class Initialized
INFO - 2021-03-26 00:07:52 --> Output Class Initialized
INFO - 2021-03-26 00:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:52 --> Input Class Initialized
INFO - 2021-03-26 00:07:52 --> Language Class Initialized
ERROR - 2021-03-26 00:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:52 --> Config Class Initialized
INFO - 2021-03-26 00:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:52 --> URI Class Initialized
INFO - 2021-03-26 00:07:52 --> Router Class Initialized
INFO - 2021-03-26 00:07:52 --> Output Class Initialized
INFO - 2021-03-26 00:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:52 --> Input Class Initialized
INFO - 2021-03-26 00:07:52 --> Language Class Initialized
ERROR - 2021-03-26 00:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:52 --> Config Class Initialized
INFO - 2021-03-26 00:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:52 --> URI Class Initialized
INFO - 2021-03-26 00:07:52 --> Router Class Initialized
INFO - 2021-03-26 00:07:52 --> Config Class Initialized
INFO - 2021-03-26 00:07:52 --> Hooks Class Initialized
INFO - 2021-03-26 00:07:52 --> Output Class Initialized
INFO - 2021-03-26 00:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 00:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:52 --> Input Class Initialized
INFO - 2021-03-26 00:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:52 --> Language Class Initialized
INFO - 2021-03-26 00:07:52 --> URI Class Initialized
INFO - 2021-03-26 00:07:52 --> Router Class Initialized
ERROR - 2021-03-26 00:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:52 --> Output Class Initialized
INFO - 2021-03-26 00:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:52 --> Input Class Initialized
INFO - 2021-03-26 00:07:52 --> Language Class Initialized
ERROR - 2021-03-26 00:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:07:55 --> Config Class Initialized
INFO - 2021-03-26 00:07:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:07:56 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:07:56 --> Utf8 Class Initialized
INFO - 2021-03-26 00:07:56 --> URI Class Initialized
INFO - 2021-03-26 00:07:56 --> Router Class Initialized
INFO - 2021-03-26 00:07:56 --> Output Class Initialized
INFO - 2021-03-26 00:07:56 --> Security Class Initialized
DEBUG - 2021-03-26 00:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:07:56 --> Input Class Initialized
INFO - 2021-03-26 00:07:56 --> Language Class Initialized
INFO - 2021-03-26 00:07:56 --> Loader Class Initialized
INFO - 2021-03-26 00:07:56 --> Helper loaded: url_helper
INFO - 2021-03-26 00:07:56 --> Helper loaded: form_helper
INFO - 2021-03-26 00:07:56 --> Helper loaded: common_helper
INFO - 2021-03-26 00:07:56 --> Helper loaded: util_helper
INFO - 2021-03-26 00:07:56 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:07:56 --> Form Validation Class Initialized
INFO - 2021-03-26 00:07:56 --> Controller Class Initialized
INFO - 2021-03-26 00:07:56 --> Model Class Initialized
INFO - 2021-03-26 00:07:56 --> Model Class Initialized
INFO - 2021-03-26 00:07:56 --> Model Class Initialized
INFO - 2021-03-26 00:09:45 --> Config Class Initialized
INFO - 2021-03-26 00:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:09:45 --> URI Class Initialized
INFO - 2021-03-26 00:09:45 --> Router Class Initialized
INFO - 2021-03-26 00:09:45 --> Output Class Initialized
INFO - 2021-03-26 00:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:09:45 --> Input Class Initialized
INFO - 2021-03-26 00:09:45 --> Language Class Initialized
INFO - 2021-03-26 00:09:45 --> Loader Class Initialized
INFO - 2021-03-26 00:09:45 --> Helper loaded: url_helper
INFO - 2021-03-26 00:09:45 --> Helper loaded: form_helper
INFO - 2021-03-26 00:09:45 --> Helper loaded: common_helper
INFO - 2021-03-26 00:09:45 --> Helper loaded: util_helper
INFO - 2021-03-26 00:09:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:09:45 --> Form Validation Class Initialized
INFO - 2021-03-26 00:09:45 --> Controller Class Initialized
INFO - 2021-03-26 00:09:45 --> Model Class Initialized
INFO - 2021-03-26 00:09:45 --> Model Class Initialized
INFO - 2021-03-26 00:09:45 --> Model Class Initialized
INFO - 2021-03-26 00:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:09:45 --> Final output sent to browser
DEBUG - 2021-03-26 00:09:45 --> Total execution time: 0.0358
INFO - 2021-03-26 00:09:45 --> Config Class Initialized
INFO - 2021-03-26 00:09:45 --> Hooks Class Initialized
INFO - 2021-03-26 00:09:45 --> Config Class Initialized
INFO - 2021-03-26 00:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:09:45 --> URI Class Initialized
INFO - 2021-03-26 00:09:45 --> URI Class Initialized
INFO - 2021-03-26 00:09:45 --> Router Class Initialized
INFO - 2021-03-26 00:09:45 --> Router Class Initialized
INFO - 2021-03-26 00:09:45 --> Output Class Initialized
INFO - 2021-03-26 00:09:45 --> Output Class Initialized
INFO - 2021-03-26 00:09:45 --> Security Class Initialized
INFO - 2021-03-26 00:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:09:45 --> Input Class Initialized
INFO - 2021-03-26 00:09:45 --> Input Class Initialized
INFO - 2021-03-26 00:09:45 --> Language Class Initialized
INFO - 2021-03-26 00:09:45 --> Language Class Initialized
ERROR - 2021-03-26 00:09:45 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:09:45 --> Config Class Initialized
INFO - 2021-03-26 00:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:09:45 --> URI Class Initialized
INFO - 2021-03-26 00:09:45 --> Config Class Initialized
INFO - 2021-03-26 00:09:45 --> Hooks Class Initialized
INFO - 2021-03-26 00:09:45 --> Router Class Initialized
INFO - 2021-03-26 00:09:45 --> Output Class Initialized
DEBUG - 2021-03-26 00:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:09:45 --> Security Class Initialized
INFO - 2021-03-26 00:09:45 --> URI Class Initialized
DEBUG - 2021-03-26 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:09:45 --> Input Class Initialized
INFO - 2021-03-26 00:09:45 --> Language Class Initialized
INFO - 2021-03-26 00:09:45 --> Router Class Initialized
INFO - 2021-03-26 00:09:45 --> Output Class Initialized
ERROR - 2021-03-26 00:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:09:45 --> Input Class Initialized
INFO - 2021-03-26 00:09:45 --> Language Class Initialized
ERROR - 2021-03-26 00:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:09:50 --> Config Class Initialized
INFO - 2021-03-26 00:09:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:09:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:09:50 --> Utf8 Class Initialized
INFO - 2021-03-26 00:09:50 --> URI Class Initialized
INFO - 2021-03-26 00:09:50 --> Router Class Initialized
INFO - 2021-03-26 00:09:50 --> Output Class Initialized
INFO - 2021-03-26 00:09:50 --> Security Class Initialized
DEBUG - 2021-03-26 00:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:09:50 --> Input Class Initialized
INFO - 2021-03-26 00:09:50 --> Language Class Initialized
INFO - 2021-03-26 00:09:50 --> Loader Class Initialized
INFO - 2021-03-26 00:09:50 --> Helper loaded: url_helper
INFO - 2021-03-26 00:09:50 --> Helper loaded: form_helper
INFO - 2021-03-26 00:09:50 --> Helper loaded: common_helper
INFO - 2021-03-26 00:09:50 --> Helper loaded: util_helper
INFO - 2021-03-26 00:09:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:09:50 --> Form Validation Class Initialized
INFO - 2021-03-26 00:09:50 --> Controller Class Initialized
INFO - 2021-03-26 00:09:50 --> Model Class Initialized
INFO - 2021-03-26 00:09:50 --> Model Class Initialized
INFO - 2021-03-26 00:09:50 --> Model Class Initialized
INFO - 2021-03-26 00:09:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:10:11 --> Config Class Initialized
INFO - 2021-03-26 00:10:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:11 --> URI Class Initialized
INFO - 2021-03-26 00:10:11 --> Router Class Initialized
INFO - 2021-03-26 00:10:11 --> Output Class Initialized
INFO - 2021-03-26 00:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 00:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:10:11 --> Input Class Initialized
INFO - 2021-03-26 00:10:11 --> Language Class Initialized
INFO - 2021-03-26 00:10:11 --> Loader Class Initialized
INFO - 2021-03-26 00:10:11 --> Helper loaded: url_helper
INFO - 2021-03-26 00:10:11 --> Helper loaded: form_helper
INFO - 2021-03-26 00:10:11 --> Helper loaded: common_helper
INFO - 2021-03-26 00:10:11 --> Helper loaded: util_helper
INFO - 2021-03-26 00:10:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:10:11 --> Form Validation Class Initialized
INFO - 2021-03-26 00:10:11 --> Controller Class Initialized
INFO - 2021-03-26 00:10:11 --> Model Class Initialized
INFO - 2021-03-26 00:10:11 --> Model Class Initialized
INFO - 2021-03-26 00:10:11 --> Model Class Initialized
INFO - 2021-03-26 00:10:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:10:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:10:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:10:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:10:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:10:11 --> Final output sent to browser
DEBUG - 2021-03-26 00:10:11 --> Total execution time: 0.0486
INFO - 2021-03-26 00:10:11 --> Config Class Initialized
INFO - 2021-03-26 00:10:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:11 --> URI Class Initialized
INFO - 2021-03-26 00:10:11 --> Router Class Initialized
INFO - 2021-03-26 00:10:11 --> Output Class Initialized
INFO - 2021-03-26 00:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 00:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:10:11 --> Input Class Initialized
INFO - 2021-03-26 00:10:11 --> Config Class Initialized
INFO - 2021-03-26 00:10:11 --> Hooks Class Initialized
INFO - 2021-03-26 00:10:11 --> Language Class Initialized
ERROR - 2021-03-26 00:10:11 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:11 --> URI Class Initialized
INFO - 2021-03-26 00:10:11 --> Router Class Initialized
INFO - 2021-03-26 00:10:11 --> Output Class Initialized
INFO - 2021-03-26 00:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 00:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:10:11 --> Input Class Initialized
INFO - 2021-03-26 00:10:11 --> Language Class Initialized
INFO - 2021-03-26 00:10:11 --> Config Class Initialized
INFO - 2021-03-26 00:10:11 --> Hooks Class Initialized
ERROR - 2021-03-26 00:10:11 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:10:11 --> Config Class Initialized
INFO - 2021-03-26 00:10:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:10:11 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 00:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:11 --> URI Class Initialized
INFO - 2021-03-26 00:10:11 --> URI Class Initialized
INFO - 2021-03-26 00:10:11 --> Router Class Initialized
INFO - 2021-03-26 00:10:11 --> Router Class Initialized
INFO - 2021-03-26 00:10:11 --> Output Class Initialized
INFO - 2021-03-26 00:10:11 --> Output Class Initialized
INFO - 2021-03-26 00:10:11 --> Security Class Initialized
INFO - 2021-03-26 00:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 00:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 00:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:10:11 --> Input Class Initialized
INFO - 2021-03-26 00:10:11 --> Input Class Initialized
INFO - 2021-03-26 00:10:11 --> Language Class Initialized
INFO - 2021-03-26 00:10:11 --> Language Class Initialized
ERROR - 2021-03-26 00:10:11 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:10:11 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:10:15 --> Config Class Initialized
INFO - 2021-03-26 00:10:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:10:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:10:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:10:15 --> URI Class Initialized
INFO - 2021-03-26 00:10:15 --> Router Class Initialized
INFO - 2021-03-26 00:10:15 --> Output Class Initialized
INFO - 2021-03-26 00:10:15 --> Security Class Initialized
DEBUG - 2021-03-26 00:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:10:15 --> Input Class Initialized
INFO - 2021-03-26 00:10:15 --> Language Class Initialized
INFO - 2021-03-26 00:10:15 --> Loader Class Initialized
INFO - 2021-03-26 00:10:15 --> Helper loaded: url_helper
INFO - 2021-03-26 00:10:15 --> Helper loaded: form_helper
INFO - 2021-03-26 00:10:15 --> Helper loaded: common_helper
INFO - 2021-03-26 00:10:15 --> Helper loaded: util_helper
INFO - 2021-03-26 00:10:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:10:15 --> Form Validation Class Initialized
INFO - 2021-03-26 00:10:15 --> Controller Class Initialized
INFO - 2021-03-26 00:10:15 --> Model Class Initialized
INFO - 2021-03-26 00:10:15 --> Model Class Initialized
INFO - 2021-03-26 00:10:15 --> Model Class Initialized
INFO - 2021-03-26 00:10:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:11:23 --> Config Class Initialized
INFO - 2021-03-26 00:11:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:11:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:11:23 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:23 --> URI Class Initialized
INFO - 2021-03-26 00:11:23 --> Router Class Initialized
INFO - 2021-03-26 00:11:23 --> Output Class Initialized
INFO - 2021-03-26 00:11:23 --> Security Class Initialized
DEBUG - 2021-03-26 00:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:11:23 --> Input Class Initialized
INFO - 2021-03-26 00:11:23 --> Language Class Initialized
INFO - 2021-03-26 00:11:23 --> Loader Class Initialized
INFO - 2021-03-26 00:11:23 --> Helper loaded: url_helper
INFO - 2021-03-26 00:11:23 --> Helper loaded: form_helper
INFO - 2021-03-26 00:11:23 --> Helper loaded: common_helper
INFO - 2021-03-26 00:11:23 --> Helper loaded: util_helper
INFO - 2021-03-26 00:11:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:11:23 --> Form Validation Class Initialized
INFO - 2021-03-26 00:11:23 --> Controller Class Initialized
INFO - 2021-03-26 00:11:23 --> Model Class Initialized
INFO - 2021-03-26 00:11:23 --> Model Class Initialized
INFO - 2021-03-26 00:11:23 --> Model Class Initialized
INFO - 2021-03-26 00:11:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:11:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:11:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:11:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:11:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:11:23 --> Final output sent to browser
DEBUG - 2021-03-26 00:11:23 --> Total execution time: 0.0462
INFO - 2021-03-26 00:11:23 --> Config Class Initialized
INFO - 2021-03-26 00:11:23 --> Hooks Class Initialized
INFO - 2021-03-26 00:11:23 --> Config Class Initialized
INFO - 2021-03-26 00:11:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:11:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:11:23 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:23 --> URI Class Initialized
DEBUG - 2021-03-26 00:11:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:11:23 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:23 --> Router Class Initialized
INFO - 2021-03-26 00:11:23 --> URI Class Initialized
INFO - 2021-03-26 00:11:23 --> Output Class Initialized
INFO - 2021-03-26 00:11:23 --> Router Class Initialized
INFO - 2021-03-26 00:11:23 --> Security Class Initialized
INFO - 2021-03-26 00:11:23 --> Output Class Initialized
DEBUG - 2021-03-26 00:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:11:23 --> Input Class Initialized
INFO - 2021-03-26 00:11:23 --> Security Class Initialized
INFO - 2021-03-26 00:11:23 --> Language Class Initialized
DEBUG - 2021-03-26 00:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:11:23 --> Input Class Initialized
ERROR - 2021-03-26 00:11:23 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:11:23 --> Language Class Initialized
ERROR - 2021-03-26 00:11:23 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:11:23 --> Config Class Initialized
INFO - 2021-03-26 00:11:23 --> Config Class Initialized
INFO - 2021-03-26 00:11:23 --> Hooks Class Initialized
INFO - 2021-03-26 00:11:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 00:11:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:11:23 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:23 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:23 --> URI Class Initialized
INFO - 2021-03-26 00:11:23 --> URI Class Initialized
INFO - 2021-03-26 00:11:23 --> Router Class Initialized
INFO - 2021-03-26 00:11:23 --> Router Class Initialized
INFO - 2021-03-26 00:11:23 --> Output Class Initialized
INFO - 2021-03-26 00:11:23 --> Output Class Initialized
INFO - 2021-03-26 00:11:23 --> Security Class Initialized
INFO - 2021-03-26 00:11:23 --> Security Class Initialized
DEBUG - 2021-03-26 00:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 00:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:11:23 --> Input Class Initialized
INFO - 2021-03-26 00:11:23 --> Input Class Initialized
INFO - 2021-03-26 00:11:23 --> Language Class Initialized
INFO - 2021-03-26 00:11:23 --> Language Class Initialized
ERROR - 2021-03-26 00:11:23 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:11:23 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:11:26 --> Config Class Initialized
INFO - 2021-03-26 00:11:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:11:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:11:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:11:26 --> URI Class Initialized
INFO - 2021-03-26 00:11:26 --> Router Class Initialized
INFO - 2021-03-26 00:11:27 --> Output Class Initialized
INFO - 2021-03-26 00:11:27 --> Security Class Initialized
DEBUG - 2021-03-26 00:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:11:27 --> Input Class Initialized
INFO - 2021-03-26 00:11:27 --> Language Class Initialized
INFO - 2021-03-26 00:11:27 --> Loader Class Initialized
INFO - 2021-03-26 00:11:27 --> Helper loaded: url_helper
INFO - 2021-03-26 00:11:27 --> Helper loaded: form_helper
INFO - 2021-03-26 00:11:27 --> Helper loaded: common_helper
INFO - 2021-03-26 00:11:27 --> Helper loaded: util_helper
INFO - 2021-03-26 00:11:27 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:11:27 --> Form Validation Class Initialized
INFO - 2021-03-26 00:11:27 --> Controller Class Initialized
INFO - 2021-03-26 00:11:27 --> Model Class Initialized
INFO - 2021-03-26 00:11:27 --> Model Class Initialized
INFO - 2021-03-26 00:11:27 --> Model Class Initialized
INFO - 2021-03-26 00:11:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:11:27 --> Final output sent to browser
DEBUG - 2021-03-26 00:11:27 --> Total execution time: 0.0649
INFO - 2021-03-26 00:12:25 --> Config Class Initialized
INFO - 2021-03-26 00:12:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:12:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:25 --> URI Class Initialized
INFO - 2021-03-26 00:12:25 --> Router Class Initialized
INFO - 2021-03-26 00:12:25 --> Output Class Initialized
INFO - 2021-03-26 00:12:25 --> Security Class Initialized
DEBUG - 2021-03-26 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:25 --> Input Class Initialized
INFO - 2021-03-26 00:12:25 --> Language Class Initialized
INFO - 2021-03-26 00:12:25 --> Loader Class Initialized
INFO - 2021-03-26 00:12:25 --> Helper loaded: url_helper
INFO - 2021-03-26 00:12:25 --> Helper loaded: form_helper
INFO - 2021-03-26 00:12:25 --> Helper loaded: common_helper
INFO - 2021-03-26 00:12:25 --> Helper loaded: util_helper
INFO - 2021-03-26 00:12:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:12:25 --> Form Validation Class Initialized
INFO - 2021-03-26 00:12:25 --> Controller Class Initialized
INFO - 2021-03-26 00:12:25 --> Model Class Initialized
INFO - 2021-03-26 00:12:25 --> Model Class Initialized
INFO - 2021-03-26 00:12:25 --> Model Class Initialized
INFO - 2021-03-26 00:12:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:12:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:12:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:12:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:12:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:12:25 --> Final output sent to browser
DEBUG - 2021-03-26 00:12:25 --> Total execution time: 0.0461
INFO - 2021-03-26 00:12:25 --> Config Class Initialized
INFO - 2021-03-26 00:12:25 --> Hooks Class Initialized
INFO - 2021-03-26 00:12:25 --> Config Class Initialized
INFO - 2021-03-26 00:12:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:12:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:25 --> URI Class Initialized
DEBUG - 2021-03-26 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:12:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:25 --> URI Class Initialized
INFO - 2021-03-26 00:12:25 --> Router Class Initialized
INFO - 2021-03-26 00:12:25 --> Router Class Initialized
INFO - 2021-03-26 00:12:25 --> Output Class Initialized
INFO - 2021-03-26 00:12:25 --> Output Class Initialized
INFO - 2021-03-26 00:12:25 --> Security Class Initialized
INFO - 2021-03-26 00:12:25 --> Security Class Initialized
DEBUG - 2021-03-26 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:25 --> Input Class Initialized
INFO - 2021-03-26 00:12:25 --> Language Class Initialized
DEBUG - 2021-03-26 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:25 --> Input Class Initialized
ERROR - 2021-03-26 00:12:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:12:25 --> Language Class Initialized
ERROR - 2021-03-26 00:12:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:12:25 --> Config Class Initialized
INFO - 2021-03-26 00:12:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:12:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:25 --> URI Class Initialized
INFO - 2021-03-26 00:12:25 --> Router Class Initialized
INFO - 2021-03-26 00:12:25 --> Config Class Initialized
INFO - 2021-03-26 00:12:25 --> Hooks Class Initialized
INFO - 2021-03-26 00:12:25 --> Output Class Initialized
INFO - 2021-03-26 00:12:25 --> Security Class Initialized
DEBUG - 2021-03-26 00:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:25 --> Input Class Initialized
INFO - 2021-03-26 00:12:25 --> URI Class Initialized
INFO - 2021-03-26 00:12:25 --> Language Class Initialized
INFO - 2021-03-26 00:12:25 --> Router Class Initialized
INFO - 2021-03-26 00:12:25 --> Output Class Initialized
INFO - 2021-03-26 00:12:25 --> Security Class Initialized
DEBUG - 2021-03-26 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:25 --> Input Class Initialized
INFO - 2021-03-26 00:12:25 --> Language Class Initialized
ERROR - 2021-03-26 00:12:25 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:12:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:12:32 --> Config Class Initialized
INFO - 2021-03-26 00:12:32 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:12:32 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:12:32 --> Utf8 Class Initialized
INFO - 2021-03-26 00:12:32 --> URI Class Initialized
INFO - 2021-03-26 00:12:32 --> Router Class Initialized
INFO - 2021-03-26 00:12:32 --> Output Class Initialized
INFO - 2021-03-26 00:12:32 --> Security Class Initialized
DEBUG - 2021-03-26 00:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:12:32 --> Input Class Initialized
INFO - 2021-03-26 00:12:32 --> Language Class Initialized
INFO - 2021-03-26 00:12:32 --> Loader Class Initialized
INFO - 2021-03-26 00:12:32 --> Helper loaded: url_helper
INFO - 2021-03-26 00:12:32 --> Helper loaded: form_helper
INFO - 2021-03-26 00:12:32 --> Helper loaded: common_helper
INFO - 2021-03-26 00:12:32 --> Helper loaded: util_helper
INFO - 2021-03-26 00:12:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:12:32 --> Form Validation Class Initialized
INFO - 2021-03-26 00:12:32 --> Controller Class Initialized
INFO - 2021-03-26 00:12:32 --> Model Class Initialized
INFO - 2021-03-26 00:12:32 --> Model Class Initialized
INFO - 2021-03-26 00:12:32 --> Model Class Initialized
INFO - 2021-03-26 00:12:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:12:32 --> Final output sent to browser
DEBUG - 2021-03-26 00:12:32 --> Total execution time: 0.0440
INFO - 2021-03-26 00:13:22 --> Config Class Initialized
INFO - 2021-03-26 00:13:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:13:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:22 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:22 --> URI Class Initialized
INFO - 2021-03-26 00:13:22 --> Router Class Initialized
INFO - 2021-03-26 00:13:22 --> Output Class Initialized
INFO - 2021-03-26 00:13:22 --> Security Class Initialized
DEBUG - 2021-03-26 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:22 --> Input Class Initialized
INFO - 2021-03-26 00:13:22 --> Language Class Initialized
INFO - 2021-03-26 00:13:22 --> Loader Class Initialized
INFO - 2021-03-26 00:13:22 --> Helper loaded: url_helper
INFO - 2021-03-26 00:13:22 --> Helper loaded: form_helper
INFO - 2021-03-26 00:13:22 --> Helper loaded: common_helper
INFO - 2021-03-26 00:13:22 --> Helper loaded: util_helper
INFO - 2021-03-26 00:13:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:13:22 --> Form Validation Class Initialized
INFO - 2021-03-26 00:13:22 --> Controller Class Initialized
INFO - 2021-03-26 00:13:22 --> Model Class Initialized
INFO - 2021-03-26 00:13:22 --> Model Class Initialized
INFO - 2021-03-26 00:13:22 --> Model Class Initialized
INFO - 2021-03-26 00:13:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:13:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:13:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:13:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:13:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:13:22 --> Final output sent to browser
DEBUG - 2021-03-26 00:13:22 --> Total execution time: 0.0384
INFO - 2021-03-26 00:13:22 --> Config Class Initialized
INFO - 2021-03-26 00:13:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:13:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:22 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:22 --> Config Class Initialized
INFO - 2021-03-26 00:13:22 --> URI Class Initialized
INFO - 2021-03-26 00:13:22 --> Hooks Class Initialized
INFO - 2021-03-26 00:13:22 --> Router Class Initialized
DEBUG - 2021-03-26 00:13:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:22 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:22 --> Output Class Initialized
INFO - 2021-03-26 00:13:22 --> URI Class Initialized
INFO - 2021-03-26 00:13:22 --> Security Class Initialized
INFO - 2021-03-26 00:13:22 --> Router Class Initialized
DEBUG - 2021-03-26 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:22 --> Input Class Initialized
INFO - 2021-03-26 00:13:22 --> Output Class Initialized
INFO - 2021-03-26 00:13:22 --> Language Class Initialized
INFO - 2021-03-26 00:13:22 --> Security Class Initialized
ERROR - 2021-03-26 00:13:22 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:22 --> Input Class Initialized
INFO - 2021-03-26 00:13:22 --> Language Class Initialized
ERROR - 2021-03-26 00:13:22 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:13:22 --> Config Class Initialized
INFO - 2021-03-26 00:13:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:13:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:22 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:22 --> URI Class Initialized
INFO - 2021-03-26 00:13:22 --> Router Class Initialized
INFO - 2021-03-26 00:13:22 --> Output Class Initialized
INFO - 2021-03-26 00:13:22 --> Security Class Initialized
DEBUG - 2021-03-26 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:22 --> Input Class Initialized
INFO - 2021-03-26 00:13:22 --> Language Class Initialized
ERROR - 2021-03-26 00:13:22 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:13:22 --> Config Class Initialized
INFO - 2021-03-26 00:13:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:13:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:22 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:22 --> URI Class Initialized
INFO - 2021-03-26 00:13:22 --> Router Class Initialized
INFO - 2021-03-26 00:13:22 --> Output Class Initialized
INFO - 2021-03-26 00:13:22 --> Security Class Initialized
DEBUG - 2021-03-26 00:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:22 --> Input Class Initialized
INFO - 2021-03-26 00:13:22 --> Language Class Initialized
ERROR - 2021-03-26 00:13:22 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:13:26 --> Config Class Initialized
INFO - 2021-03-26 00:13:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:13:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:13:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:13:26 --> URI Class Initialized
INFO - 2021-03-26 00:13:26 --> Router Class Initialized
INFO - 2021-03-26 00:13:26 --> Output Class Initialized
INFO - 2021-03-26 00:13:26 --> Security Class Initialized
DEBUG - 2021-03-26 00:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:13:26 --> Input Class Initialized
INFO - 2021-03-26 00:13:26 --> Language Class Initialized
INFO - 2021-03-26 00:13:26 --> Loader Class Initialized
INFO - 2021-03-26 00:13:26 --> Helper loaded: url_helper
INFO - 2021-03-26 00:13:26 --> Helper loaded: form_helper
INFO - 2021-03-26 00:13:26 --> Helper loaded: common_helper
INFO - 2021-03-26 00:13:26 --> Helper loaded: util_helper
INFO - 2021-03-26 00:13:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:13:26 --> Form Validation Class Initialized
INFO - 2021-03-26 00:13:26 --> Controller Class Initialized
INFO - 2021-03-26 00:13:26 --> Model Class Initialized
INFO - 2021-03-26 00:13:26 --> Model Class Initialized
INFO - 2021-03-26 00:13:26 --> Model Class Initialized
INFO - 2021-03-26 00:13:26 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:13:26 --> Final output sent to browser
DEBUG - 2021-03-26 00:13:26 --> Total execution time: 0.0373
INFO - 2021-03-26 00:14:14 --> Config Class Initialized
INFO - 2021-03-26 00:14:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:14 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:14 --> URI Class Initialized
INFO - 2021-03-26 00:14:14 --> Router Class Initialized
INFO - 2021-03-26 00:14:14 --> Output Class Initialized
INFO - 2021-03-26 00:14:14 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:14 --> Input Class Initialized
INFO - 2021-03-26 00:14:14 --> Language Class Initialized
INFO - 2021-03-26 00:14:14 --> Loader Class Initialized
INFO - 2021-03-26 00:14:14 --> Helper loaded: url_helper
INFO - 2021-03-26 00:14:14 --> Helper loaded: form_helper
INFO - 2021-03-26 00:14:14 --> Helper loaded: common_helper
INFO - 2021-03-26 00:14:14 --> Helper loaded: util_helper
INFO - 2021-03-26 00:14:14 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:14:14 --> Form Validation Class Initialized
INFO - 2021-03-26 00:14:14 --> Controller Class Initialized
INFO - 2021-03-26 00:14:14 --> Model Class Initialized
INFO - 2021-03-26 00:14:14 --> Model Class Initialized
INFO - 2021-03-26 00:14:14 --> Model Class Initialized
INFO - 2021-03-26 00:14:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:14:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:14:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:14:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:14:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:14:14 --> Final output sent to browser
DEBUG - 2021-03-26 00:14:14 --> Total execution time: 0.0404
INFO - 2021-03-26 00:14:14 --> Config Class Initialized
INFO - 2021-03-26 00:14:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:14 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:14 --> URI Class Initialized
INFO - 2021-03-26 00:14:14 --> Router Class Initialized
INFO - 2021-03-26 00:14:14 --> Output Class Initialized
INFO - 2021-03-26 00:14:14 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:14 --> Input Class Initialized
INFO - 2021-03-26 00:14:14 --> Language Class Initialized
ERROR - 2021-03-26 00:14:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:14 --> Config Class Initialized
INFO - 2021-03-26 00:14:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:14 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:14 --> URI Class Initialized
INFO - 2021-03-26 00:14:14 --> Router Class Initialized
INFO - 2021-03-26 00:14:14 --> Output Class Initialized
INFO - 2021-03-26 00:14:14 --> Security Class Initialized
INFO - 2021-03-26 00:14:14 --> Config Class Initialized
INFO - 2021-03-26 00:14:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:14 --> Input Class Initialized
INFO - 2021-03-26 00:14:14 --> Language Class Initialized
DEBUG - 2021-03-26 00:14:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:14 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:14 --> URI Class Initialized
ERROR - 2021-03-26 00:14:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:14 --> Router Class Initialized
INFO - 2021-03-26 00:14:14 --> Output Class Initialized
INFO - 2021-03-26 00:14:14 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:14 --> Input Class Initialized
INFO - 2021-03-26 00:14:14 --> Language Class Initialized
ERROR - 2021-03-26 00:14:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:14 --> Config Class Initialized
INFO - 2021-03-26 00:14:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:14 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:14 --> URI Class Initialized
INFO - 2021-03-26 00:14:14 --> Router Class Initialized
INFO - 2021-03-26 00:14:14 --> Output Class Initialized
INFO - 2021-03-26 00:14:14 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:14 --> Input Class Initialized
INFO - 2021-03-26 00:14:14 --> Language Class Initialized
ERROR - 2021-03-26 00:14:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:17 --> Config Class Initialized
INFO - 2021-03-26 00:14:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:17 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:17 --> URI Class Initialized
INFO - 2021-03-26 00:14:17 --> Router Class Initialized
INFO - 2021-03-26 00:14:17 --> Output Class Initialized
INFO - 2021-03-26 00:14:17 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:17 --> Input Class Initialized
INFO - 2021-03-26 00:14:17 --> Language Class Initialized
INFO - 2021-03-26 00:14:17 --> Loader Class Initialized
INFO - 2021-03-26 00:14:17 --> Helper loaded: url_helper
INFO - 2021-03-26 00:14:17 --> Helper loaded: form_helper
INFO - 2021-03-26 00:14:17 --> Helper loaded: common_helper
INFO - 2021-03-26 00:14:17 --> Helper loaded: util_helper
INFO - 2021-03-26 00:14:17 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:14:17 --> Form Validation Class Initialized
INFO - 2021-03-26 00:14:17 --> Controller Class Initialized
INFO - 2021-03-26 00:14:17 --> Model Class Initialized
INFO - 2021-03-26 00:14:17 --> Model Class Initialized
INFO - 2021-03-26 00:14:17 --> Model Class Initialized
INFO - 2021-03-26 00:14:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:14:17 --> Final output sent to browser
DEBUG - 2021-03-26 00:14:17 --> Total execution time: 0.0434
INFO - 2021-03-26 00:14:36 --> Config Class Initialized
INFO - 2021-03-26 00:14:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:36 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:36 --> URI Class Initialized
INFO - 2021-03-26 00:14:36 --> Router Class Initialized
INFO - 2021-03-26 00:14:36 --> Output Class Initialized
INFO - 2021-03-26 00:14:36 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:36 --> Input Class Initialized
INFO - 2021-03-26 00:14:36 --> Language Class Initialized
INFO - 2021-03-26 00:14:36 --> Loader Class Initialized
INFO - 2021-03-26 00:14:36 --> Helper loaded: url_helper
INFO - 2021-03-26 00:14:36 --> Helper loaded: form_helper
INFO - 2021-03-26 00:14:36 --> Helper loaded: common_helper
INFO - 2021-03-26 00:14:36 --> Helper loaded: util_helper
INFO - 2021-03-26 00:14:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:14:36 --> Form Validation Class Initialized
INFO - 2021-03-26 00:14:36 --> Controller Class Initialized
INFO - 2021-03-26 00:14:36 --> Model Class Initialized
INFO - 2021-03-26 00:14:36 --> Model Class Initialized
INFO - 2021-03-26 00:14:36 --> Model Class Initialized
INFO - 2021-03-26 00:14:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:14:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:14:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:14:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:14:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:14:36 --> Final output sent to browser
DEBUG - 2021-03-26 00:14:36 --> Total execution time: 0.0352
INFO - 2021-03-26 00:14:36 --> Config Class Initialized
INFO - 2021-03-26 00:14:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:36 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:36 --> URI Class Initialized
INFO - 2021-03-26 00:14:36 --> Router Class Initialized
INFO - 2021-03-26 00:14:36 --> Output Class Initialized
INFO - 2021-03-26 00:14:36 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:36 --> Input Class Initialized
INFO - 2021-03-26 00:14:36 --> Language Class Initialized
ERROR - 2021-03-26 00:14:36 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:36 --> Config Class Initialized
INFO - 2021-03-26 00:14:36 --> Hooks Class Initialized
INFO - 2021-03-26 00:14:36 --> Config Class Initialized
INFO - 2021-03-26 00:14:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:36 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:36 --> URI Class Initialized
DEBUG - 2021-03-26 00:14:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:36 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:36 --> URI Class Initialized
INFO - 2021-03-26 00:14:36 --> Router Class Initialized
INFO - 2021-03-26 00:14:36 --> Output Class Initialized
INFO - 2021-03-26 00:14:36 --> Router Class Initialized
INFO - 2021-03-26 00:14:36 --> Security Class Initialized
INFO - 2021-03-26 00:14:36 --> Output Class Initialized
DEBUG - 2021-03-26 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:36 --> Input Class Initialized
INFO - 2021-03-26 00:14:36 --> Language Class Initialized
INFO - 2021-03-26 00:14:36 --> Security Class Initialized
ERROR - 2021-03-26 00:14:36 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:36 --> Input Class Initialized
INFO - 2021-03-26 00:14:36 --> Language Class Initialized
ERROR - 2021-03-26 00:14:36 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:36 --> Config Class Initialized
INFO - 2021-03-26 00:14:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:36 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:36 --> URI Class Initialized
INFO - 2021-03-26 00:14:36 --> Router Class Initialized
INFO - 2021-03-26 00:14:36 --> Output Class Initialized
INFO - 2021-03-26 00:14:36 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:36 --> Input Class Initialized
INFO - 2021-03-26 00:14:36 --> Language Class Initialized
ERROR - 2021-03-26 00:14:36 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:14:39 --> Config Class Initialized
INFO - 2021-03-26 00:14:39 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:14:39 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:14:39 --> Utf8 Class Initialized
INFO - 2021-03-26 00:14:39 --> URI Class Initialized
INFO - 2021-03-26 00:14:39 --> Router Class Initialized
INFO - 2021-03-26 00:14:39 --> Output Class Initialized
INFO - 2021-03-26 00:14:39 --> Security Class Initialized
DEBUG - 2021-03-26 00:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:14:39 --> Input Class Initialized
INFO - 2021-03-26 00:14:39 --> Language Class Initialized
INFO - 2021-03-26 00:14:39 --> Loader Class Initialized
INFO - 2021-03-26 00:14:39 --> Helper loaded: url_helper
INFO - 2021-03-26 00:14:39 --> Helper loaded: form_helper
INFO - 2021-03-26 00:14:39 --> Helper loaded: common_helper
INFO - 2021-03-26 00:14:39 --> Helper loaded: util_helper
INFO - 2021-03-26 00:14:39 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:14:39 --> Form Validation Class Initialized
INFO - 2021-03-26 00:14:39 --> Controller Class Initialized
INFO - 2021-03-26 00:14:39 --> Model Class Initialized
INFO - 2021-03-26 00:14:39 --> Model Class Initialized
INFO - 2021-03-26 00:14:39 --> Model Class Initialized
INFO - 2021-03-26 00:14:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:14:39 --> Final output sent to browser
DEBUG - 2021-03-26 00:14:39 --> Total execution time: 0.0490
INFO - 2021-03-26 00:21:52 --> Config Class Initialized
INFO - 2021-03-26 00:21:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:21:52 --> URI Class Initialized
INFO - 2021-03-26 00:21:52 --> Router Class Initialized
INFO - 2021-03-26 00:21:52 --> Output Class Initialized
INFO - 2021-03-26 00:21:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:52 --> Input Class Initialized
INFO - 2021-03-26 00:21:52 --> Language Class Initialized
INFO - 2021-03-26 00:21:52 --> Loader Class Initialized
INFO - 2021-03-26 00:21:52 --> Helper loaded: url_helper
INFO - 2021-03-26 00:21:52 --> Helper loaded: form_helper
INFO - 2021-03-26 00:21:52 --> Helper loaded: common_helper
INFO - 2021-03-26 00:21:52 --> Helper loaded: util_helper
INFO - 2021-03-26 00:21:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:21:52 --> Form Validation Class Initialized
INFO - 2021-03-26 00:21:52 --> Controller Class Initialized
INFO - 2021-03-26 00:21:52 --> Model Class Initialized
INFO - 2021-03-26 00:21:52 --> Model Class Initialized
INFO - 2021-03-26 00:21:52 --> Model Class Initialized
INFO - 2021-03-26 00:21:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:21:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:21:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:21:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:21:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:21:52 --> Final output sent to browser
DEBUG - 2021-03-26 00:21:52 --> Total execution time: 0.0374
INFO - 2021-03-26 00:21:52 --> Config Class Initialized
INFO - 2021-03-26 00:21:52 --> Hooks Class Initialized
INFO - 2021-03-26 00:21:52 --> Config Class Initialized
INFO - 2021-03-26 00:21:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:21:52 --> URI Class Initialized
DEBUG - 2021-03-26 00:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:21:52 --> Router Class Initialized
INFO - 2021-03-26 00:21:52 --> URI Class Initialized
INFO - 2021-03-26 00:21:52 --> Output Class Initialized
INFO - 2021-03-26 00:21:52 --> Router Class Initialized
INFO - 2021-03-26 00:21:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:52 --> Input Class Initialized
INFO - 2021-03-26 00:21:52 --> Output Class Initialized
INFO - 2021-03-26 00:21:52 --> Language Class Initialized
INFO - 2021-03-26 00:21:52 --> Security Class Initialized
ERROR - 2021-03-26 00:21:52 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:52 --> Input Class Initialized
INFO - 2021-03-26 00:21:52 --> Language Class Initialized
ERROR - 2021-03-26 00:21:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:21:52 --> Config Class Initialized
INFO - 2021-03-26 00:21:52 --> Hooks Class Initialized
INFO - 2021-03-26 00:21:52 --> Config Class Initialized
INFO - 2021-03-26 00:21:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:52 --> Utf8 Class Initialized
DEBUG - 2021-03-26 00:21:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:52 --> Utf8 Class Initialized
INFO - 2021-03-26 00:21:52 --> URI Class Initialized
INFO - 2021-03-26 00:21:52 --> URI Class Initialized
INFO - 2021-03-26 00:21:52 --> Router Class Initialized
INFO - 2021-03-26 00:21:52 --> Router Class Initialized
INFO - 2021-03-26 00:21:52 --> Output Class Initialized
INFO - 2021-03-26 00:21:52 --> Output Class Initialized
INFO - 2021-03-26 00:21:52 --> Security Class Initialized
DEBUG - 2021-03-26 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:52 --> Input Class Initialized
INFO - 2021-03-26 00:21:52 --> Security Class Initialized
INFO - 2021-03-26 00:21:52 --> Language Class Initialized
DEBUG - 2021-03-26 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:52 --> Input Class Initialized
ERROR - 2021-03-26 00:21:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:21:52 --> Language Class Initialized
ERROR - 2021-03-26 00:21:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:21:57 --> Config Class Initialized
INFO - 2021-03-26 00:21:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:21:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:21:57 --> Utf8 Class Initialized
INFO - 2021-03-26 00:21:57 --> URI Class Initialized
INFO - 2021-03-26 00:21:57 --> Router Class Initialized
INFO - 2021-03-26 00:21:57 --> Output Class Initialized
INFO - 2021-03-26 00:21:57 --> Security Class Initialized
DEBUG - 2021-03-26 00:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:21:57 --> Input Class Initialized
INFO - 2021-03-26 00:21:57 --> Language Class Initialized
INFO - 2021-03-26 00:21:57 --> Loader Class Initialized
INFO - 2021-03-26 00:21:57 --> Helper loaded: url_helper
INFO - 2021-03-26 00:21:57 --> Helper loaded: form_helper
INFO - 2021-03-26 00:21:57 --> Helper loaded: common_helper
INFO - 2021-03-26 00:21:57 --> Helper loaded: util_helper
INFO - 2021-03-26 00:21:57 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:21:57 --> Form Validation Class Initialized
INFO - 2021-03-26 00:21:57 --> Controller Class Initialized
INFO - 2021-03-26 00:21:57 --> Model Class Initialized
INFO - 2021-03-26 00:21:57 --> Model Class Initialized
INFO - 2021-03-26 00:21:57 --> Model Class Initialized
INFO - 2021-03-26 00:21:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:21:57 --> Final output sent to browser
DEBUG - 2021-03-26 00:21:57 --> Total execution time: 0.0371
INFO - 2021-03-26 00:36:15 --> Config Class Initialized
INFO - 2021-03-26 00:36:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:36:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:36:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:36:15 --> URI Class Initialized
INFO - 2021-03-26 00:36:15 --> Router Class Initialized
INFO - 2021-03-26 00:36:15 --> Output Class Initialized
INFO - 2021-03-26 00:36:15 --> Security Class Initialized
DEBUG - 2021-03-26 00:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:15 --> Input Class Initialized
INFO - 2021-03-26 00:36:15 --> Language Class Initialized
INFO - 2021-03-26 00:36:15 --> Loader Class Initialized
INFO - 2021-03-26 00:36:15 --> Helper loaded: url_helper
INFO - 2021-03-26 00:36:15 --> Helper loaded: form_helper
INFO - 2021-03-26 00:36:15 --> Helper loaded: common_helper
INFO - 2021-03-26 00:36:15 --> Helper loaded: util_helper
INFO - 2021-03-26 00:36:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:36:15 --> Form Validation Class Initialized
INFO - 2021-03-26 00:36:15 --> Controller Class Initialized
INFO - 2021-03-26 00:36:15 --> Model Class Initialized
INFO - 2021-03-26 00:36:15 --> Model Class Initialized
INFO - 2021-03-26 00:36:15 --> Model Class Initialized
INFO - 2021-03-26 00:36:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:36:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:36:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:36:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:36:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:36:15 --> Final output sent to browser
DEBUG - 2021-03-26 00:36:15 --> Total execution time: 0.0379
INFO - 2021-03-26 00:36:15 --> Config Class Initialized
INFO - 2021-03-26 00:36:15 --> Hooks Class Initialized
INFO - 2021-03-26 00:36:15 --> Config Class Initialized
DEBUG - 2021-03-26 00:36:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:36:15 --> Hooks Class Initialized
INFO - 2021-03-26 00:36:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:36:15 --> URI Class Initialized
DEBUG - 2021-03-26 00:36:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:36:15 --> Router Class Initialized
INFO - 2021-03-26 00:36:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:36:15 --> URI Class Initialized
INFO - 2021-03-26 00:36:15 --> Output Class Initialized
INFO - 2021-03-26 00:36:15 --> Security Class Initialized
DEBUG - 2021-03-26 00:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:15 --> Input Class Initialized
INFO - 2021-03-26 00:36:15 --> Language Class Initialized
INFO - 2021-03-26 00:36:15 --> Router Class Initialized
INFO - 2021-03-26 00:36:15 --> Output Class Initialized
ERROR - 2021-03-26 00:36:15 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:36:15 --> Config Class Initialized
INFO - 2021-03-26 00:36:15 --> Security Class Initialized
INFO - 2021-03-26 00:36:15 --> Config Class Initialized
INFO - 2021-03-26 00:36:15 --> Hooks Class Initialized
INFO - 2021-03-26 00:36:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:36:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:36:15 --> Utf8 Class Initialized
DEBUG - 2021-03-26 00:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 00:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:36:15 --> Input Class Initialized
INFO - 2021-03-26 00:36:15 --> URI Class Initialized
INFO - 2021-03-26 00:36:15 --> URI Class Initialized
INFO - 2021-03-26 00:36:15 --> Language Class Initialized
INFO - 2021-03-26 00:36:15 --> Router Class Initialized
INFO - 2021-03-26 00:36:15 --> Router Class Initialized
ERROR - 2021-03-26 00:36:15 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:36:15 --> Output Class Initialized
INFO - 2021-03-26 00:36:15 --> Output Class Initialized
INFO - 2021-03-26 00:36:15 --> Security Class Initialized
INFO - 2021-03-26 00:36:15 --> Security Class Initialized
DEBUG - 2021-03-26 00:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:15 --> Input Class Initialized
DEBUG - 2021-03-26 00:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:15 --> Language Class Initialized
INFO - 2021-03-26 00:36:15 --> Input Class Initialized
INFO - 2021-03-26 00:36:15 --> Language Class Initialized
ERROR - 2021-03-26 00:36:15 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:36:15 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:36:24 --> Config Class Initialized
INFO - 2021-03-26 00:36:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:36:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:36:24 --> Utf8 Class Initialized
INFO - 2021-03-26 00:36:24 --> URI Class Initialized
INFO - 2021-03-26 00:36:24 --> Router Class Initialized
INFO - 2021-03-26 00:36:24 --> Output Class Initialized
INFO - 2021-03-26 00:36:24 --> Security Class Initialized
DEBUG - 2021-03-26 00:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:36:24 --> Input Class Initialized
INFO - 2021-03-26 00:36:24 --> Language Class Initialized
INFO - 2021-03-26 00:36:24 --> Loader Class Initialized
INFO - 2021-03-26 00:36:24 --> Helper loaded: url_helper
INFO - 2021-03-26 00:36:24 --> Helper loaded: form_helper
INFO - 2021-03-26 00:36:24 --> Helper loaded: common_helper
INFO - 2021-03-26 00:36:24 --> Helper loaded: util_helper
INFO - 2021-03-26 00:36:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:36:24 --> Form Validation Class Initialized
INFO - 2021-03-26 00:36:24 --> Controller Class Initialized
INFO - 2021-03-26 00:36:24 --> Model Class Initialized
INFO - 2021-03-26 00:36:24 --> Model Class Initialized
INFO - 2021-03-26 00:36:24 --> Model Class Initialized
INFO - 2021-03-26 00:36:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:36:24 --> Final output sent to browser
DEBUG - 2021-03-26 00:36:24 --> Total execution time: 0.0362
INFO - 2021-03-26 00:37:20 --> Config Class Initialized
INFO - 2021-03-26 00:37:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:37:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:37:20 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:20 --> URI Class Initialized
INFO - 2021-03-26 00:37:20 --> Router Class Initialized
INFO - 2021-03-26 00:37:20 --> Output Class Initialized
INFO - 2021-03-26 00:37:20 --> Security Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:20 --> Input Class Initialized
INFO - 2021-03-26 00:37:20 --> Language Class Initialized
INFO - 2021-03-26 00:37:20 --> Loader Class Initialized
INFO - 2021-03-26 00:37:20 --> Helper loaded: url_helper
INFO - 2021-03-26 00:37:20 --> Helper loaded: form_helper
INFO - 2021-03-26 00:37:20 --> Helper loaded: common_helper
INFO - 2021-03-26 00:37:20 --> Helper loaded: util_helper
INFO - 2021-03-26 00:37:20 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:37:20 --> Form Validation Class Initialized
INFO - 2021-03-26 00:37:20 --> Controller Class Initialized
INFO - 2021-03-26 00:37:20 --> Model Class Initialized
INFO - 2021-03-26 00:37:20 --> Model Class Initialized
INFO - 2021-03-26 00:37:20 --> Model Class Initialized
INFO - 2021-03-26 00:37:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:37:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:37:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:37:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:37:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:37:20 --> Final output sent to browser
DEBUG - 2021-03-26 00:37:20 --> Total execution time: 0.0525
INFO - 2021-03-26 00:37:20 --> Config Class Initialized
INFO - 2021-03-26 00:37:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:37:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:37:20 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:20 --> URI Class Initialized
INFO - 2021-03-26 00:37:20 --> Router Class Initialized
INFO - 2021-03-26 00:37:20 --> Output Class Initialized
INFO - 2021-03-26 00:37:20 --> Security Class Initialized
INFO - 2021-03-26 00:37:20 --> Config Class Initialized
INFO - 2021-03-26 00:37:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:20 --> Input Class Initialized
INFO - 2021-03-26 00:37:20 --> Language Class Initialized
DEBUG - 2021-03-26 00:37:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:37:20 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:20 --> URI Class Initialized
ERROR - 2021-03-26 00:37:20 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:37:20 --> Router Class Initialized
INFO - 2021-03-26 00:37:20 --> Output Class Initialized
INFO - 2021-03-26 00:37:20 --> Security Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:20 --> Input Class Initialized
INFO - 2021-03-26 00:37:20 --> Language Class Initialized
ERROR - 2021-03-26 00:37:20 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:37:20 --> Config Class Initialized
INFO - 2021-03-26 00:37:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:37:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:37:20 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:20 --> URI Class Initialized
INFO - 2021-03-26 00:37:20 --> Router Class Initialized
INFO - 2021-03-26 00:37:20 --> Config Class Initialized
INFO - 2021-03-26 00:37:20 --> Output Class Initialized
INFO - 2021-03-26 00:37:20 --> Hooks Class Initialized
INFO - 2021-03-26 00:37:20 --> Security Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:20 --> Input Class Initialized
INFO - 2021-03-26 00:37:20 --> Language Class Initialized
DEBUG - 2021-03-26 00:37:20 --> UTF-8 Support Enabled
ERROR - 2021-03-26 00:37:20 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:37:20 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:20 --> URI Class Initialized
INFO - 2021-03-26 00:37:20 --> Router Class Initialized
INFO - 2021-03-26 00:37:20 --> Output Class Initialized
INFO - 2021-03-26 00:37:20 --> Security Class Initialized
DEBUG - 2021-03-26 00:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:20 --> Input Class Initialized
INFO - 2021-03-26 00:37:20 --> Language Class Initialized
ERROR - 2021-03-26 00:37:20 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:37:24 --> Config Class Initialized
INFO - 2021-03-26 00:37:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 00:37:24 --> URI Class Initialized
INFO - 2021-03-26 00:37:24 --> Router Class Initialized
INFO - 2021-03-26 00:37:24 --> Output Class Initialized
INFO - 2021-03-26 00:37:24 --> Security Class Initialized
DEBUG - 2021-03-26 00:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:37:24 --> Input Class Initialized
INFO - 2021-03-26 00:37:24 --> Language Class Initialized
INFO - 2021-03-26 00:37:24 --> Loader Class Initialized
INFO - 2021-03-26 00:37:24 --> Helper loaded: url_helper
INFO - 2021-03-26 00:37:24 --> Helper loaded: form_helper
INFO - 2021-03-26 00:37:24 --> Helper loaded: common_helper
INFO - 2021-03-26 00:37:24 --> Helper loaded: util_helper
INFO - 2021-03-26 00:37:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:37:24 --> Form Validation Class Initialized
INFO - 2021-03-26 00:37:24 --> Controller Class Initialized
INFO - 2021-03-26 00:37:24 --> Model Class Initialized
INFO - 2021-03-26 00:37:24 --> Model Class Initialized
INFO - 2021-03-26 00:37:24 --> Model Class Initialized
INFO - 2021-03-26 00:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:37:24 --> Final output sent to browser
DEBUG - 2021-03-26 00:37:24 --> Total execution time: 0.0347
INFO - 2021-03-26 00:39:06 --> Config Class Initialized
INFO - 2021-03-26 00:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:06 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:06 --> URI Class Initialized
INFO - 2021-03-26 00:39:06 --> Router Class Initialized
INFO - 2021-03-26 00:39:06 --> Output Class Initialized
INFO - 2021-03-26 00:39:06 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:06 --> Input Class Initialized
INFO - 2021-03-26 00:39:06 --> Language Class Initialized
INFO - 2021-03-26 00:39:06 --> Loader Class Initialized
INFO - 2021-03-26 00:39:06 --> Helper loaded: url_helper
INFO - 2021-03-26 00:39:06 --> Helper loaded: form_helper
INFO - 2021-03-26 00:39:06 --> Helper loaded: common_helper
INFO - 2021-03-26 00:39:06 --> Helper loaded: util_helper
INFO - 2021-03-26 00:39:06 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:39:06 --> Form Validation Class Initialized
INFO - 2021-03-26 00:39:06 --> Controller Class Initialized
INFO - 2021-03-26 00:39:06 --> Model Class Initialized
INFO - 2021-03-26 00:39:06 --> Model Class Initialized
INFO - 2021-03-26 00:39:06 --> Model Class Initialized
INFO - 2021-03-26 00:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:39:06 --> Final output sent to browser
DEBUG - 2021-03-26 00:39:06 --> Total execution time: 0.0433
INFO - 2021-03-26 00:39:06 --> Config Class Initialized
INFO - 2021-03-26 00:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:06 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:06 --> URI Class Initialized
INFO - 2021-03-26 00:39:06 --> Router Class Initialized
INFO - 2021-03-26 00:39:06 --> Output Class Initialized
INFO - 2021-03-26 00:39:06 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:06 --> Input Class Initialized
INFO - 2021-03-26 00:39:06 --> Language Class Initialized
ERROR - 2021-03-26 00:39:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:39:06 --> Config Class Initialized
INFO - 2021-03-26 00:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:06 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:06 --> URI Class Initialized
INFO - 2021-03-26 00:39:06 --> Router Class Initialized
INFO - 2021-03-26 00:39:06 --> Output Class Initialized
INFO - 2021-03-26 00:39:06 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:06 --> Input Class Initialized
INFO - 2021-03-26 00:39:06 --> Language Class Initialized
INFO - 2021-03-26 00:39:06 --> Config Class Initialized
INFO - 2021-03-26 00:39:06 --> Hooks Class Initialized
ERROR - 2021-03-26 00:39:06 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:06 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:06 --> URI Class Initialized
INFO - 2021-03-26 00:39:06 --> Config Class Initialized
INFO - 2021-03-26 00:39:06 --> Hooks Class Initialized
INFO - 2021-03-26 00:39:06 --> Router Class Initialized
INFO - 2021-03-26 00:39:06 --> Output Class Initialized
DEBUG - 2021-03-26 00:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:06 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:06 --> Security Class Initialized
INFO - 2021-03-26 00:39:06 --> URI Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:06 --> Input Class Initialized
INFO - 2021-03-26 00:39:06 --> Router Class Initialized
INFO - 2021-03-26 00:39:06 --> Language Class Initialized
INFO - 2021-03-26 00:39:06 --> Output Class Initialized
ERROR - 2021-03-26 00:39:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:39:06 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:06 --> Input Class Initialized
INFO - 2021-03-26 00:39:06 --> Language Class Initialized
ERROR - 2021-03-26 00:39:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:39:12 --> Config Class Initialized
INFO - 2021-03-26 00:39:12 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:12 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:12 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:12 --> URI Class Initialized
INFO - 2021-03-26 00:39:12 --> Router Class Initialized
INFO - 2021-03-26 00:39:12 --> Output Class Initialized
INFO - 2021-03-26 00:39:12 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:12 --> Input Class Initialized
INFO - 2021-03-26 00:39:12 --> Language Class Initialized
INFO - 2021-03-26 00:39:12 --> Loader Class Initialized
INFO - 2021-03-26 00:39:12 --> Helper loaded: url_helper
INFO - 2021-03-26 00:39:12 --> Helper loaded: form_helper
INFO - 2021-03-26 00:39:12 --> Helper loaded: common_helper
INFO - 2021-03-26 00:39:12 --> Helper loaded: util_helper
INFO - 2021-03-26 00:39:12 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:39:12 --> Form Validation Class Initialized
INFO - 2021-03-26 00:39:12 --> Controller Class Initialized
INFO - 2021-03-26 00:39:12 --> Model Class Initialized
INFO - 2021-03-26 00:39:12 --> Model Class Initialized
INFO - 2021-03-26 00:39:12 --> Model Class Initialized
INFO - 2021-03-26 00:39:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:39:12 --> Final output sent to browser
DEBUG - 2021-03-26 00:39:12 --> Total execution time: 0.0386
INFO - 2021-03-26 00:39:25 --> Config Class Initialized
INFO - 2021-03-26 00:39:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:25 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:25 --> URI Class Initialized
INFO - 2021-03-26 00:39:25 --> Router Class Initialized
INFO - 2021-03-26 00:39:25 --> Output Class Initialized
INFO - 2021-03-26 00:39:25 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:25 --> Input Class Initialized
INFO - 2021-03-26 00:39:25 --> Language Class Initialized
INFO - 2021-03-26 00:39:25 --> Loader Class Initialized
INFO - 2021-03-26 00:39:25 --> Helper loaded: url_helper
INFO - 2021-03-26 00:39:25 --> Helper loaded: form_helper
INFO - 2021-03-26 00:39:25 --> Helper loaded: common_helper
INFO - 2021-03-26 00:39:25 --> Helper loaded: util_helper
INFO - 2021-03-26 00:39:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:39:25 --> Form Validation Class Initialized
INFO - 2021-03-26 00:39:25 --> Controller Class Initialized
INFO - 2021-03-26 00:39:25 --> Model Class Initialized
INFO - 2021-03-26 00:39:25 --> Model Class Initialized
INFO - 2021-03-26 00:39:25 --> Model Class Initialized
INFO - 2021-03-26 00:39:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:39:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:39:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:39:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:39:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:39:25 --> Final output sent to browser
DEBUG - 2021-03-26 00:39:25 --> Total execution time: 0.0367
INFO - 2021-03-26 00:39:26 --> Config Class Initialized
INFO - 2021-03-26 00:39:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:26 --> URI Class Initialized
INFO - 2021-03-26 00:39:26 --> Router Class Initialized
INFO - 2021-03-26 00:39:26 --> Output Class Initialized
INFO - 2021-03-26 00:39:26 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:26 --> Input Class Initialized
INFO - 2021-03-26 00:39:26 --> Language Class Initialized
ERROR - 2021-03-26 00:39:26 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:39:26 --> Config Class Initialized
INFO - 2021-03-26 00:39:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:26 --> URI Class Initialized
INFO - 2021-03-26 00:39:26 --> Router Class Initialized
INFO - 2021-03-26 00:39:26 --> Output Class Initialized
INFO - 2021-03-26 00:39:26 --> Config Class Initialized
INFO - 2021-03-26 00:39:26 --> Security Class Initialized
INFO - 2021-03-26 00:39:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:26 --> Input Class Initialized
INFO - 2021-03-26 00:39:26 --> Language Class Initialized
ERROR - 2021-03-26 00:39:26 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:39:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:26 --> URI Class Initialized
INFO - 2021-03-26 00:39:26 --> Config Class Initialized
INFO - 2021-03-26 00:39:26 --> Hooks Class Initialized
INFO - 2021-03-26 00:39:26 --> Router Class Initialized
DEBUG - 2021-03-26 00:39:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:26 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:26 --> URI Class Initialized
INFO - 2021-03-26 00:39:26 --> Output Class Initialized
INFO - 2021-03-26 00:39:26 --> Router Class Initialized
INFO - 2021-03-26 00:39:26 --> Security Class Initialized
INFO - 2021-03-26 00:39:26 --> Output Class Initialized
INFO - 2021-03-26 00:39:26 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:26 --> Input Class Initialized
INFO - 2021-03-26 00:39:26 --> Language Class Initialized
DEBUG - 2021-03-26 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:26 --> Input Class Initialized
INFO - 2021-03-26 00:39:26 --> Language Class Initialized
ERROR - 2021-03-26 00:39:26 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 00:39:26 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:39:29 --> Config Class Initialized
INFO - 2021-03-26 00:39:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:39:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:39:29 --> Utf8 Class Initialized
INFO - 2021-03-26 00:39:29 --> URI Class Initialized
INFO - 2021-03-26 00:39:29 --> Router Class Initialized
INFO - 2021-03-26 00:39:29 --> Output Class Initialized
INFO - 2021-03-26 00:39:29 --> Security Class Initialized
DEBUG - 2021-03-26 00:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:39:29 --> Input Class Initialized
INFO - 2021-03-26 00:39:29 --> Language Class Initialized
INFO - 2021-03-26 00:39:29 --> Loader Class Initialized
INFO - 2021-03-26 00:39:29 --> Helper loaded: url_helper
INFO - 2021-03-26 00:39:29 --> Helper loaded: form_helper
INFO - 2021-03-26 00:39:29 --> Helper loaded: common_helper
INFO - 2021-03-26 00:39:29 --> Helper loaded: util_helper
INFO - 2021-03-26 00:39:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:39:29 --> Form Validation Class Initialized
INFO - 2021-03-26 00:39:29 --> Controller Class Initialized
INFO - 2021-03-26 00:39:29 --> Model Class Initialized
INFO - 2021-03-26 00:39:29 --> Model Class Initialized
INFO - 2021-03-26 00:39:29 --> Model Class Initialized
INFO - 2021-03-26 00:39:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:39:29 --> Final output sent to browser
DEBUG - 2021-03-26 00:39:29 --> Total execution time: 0.0363
INFO - 2021-03-26 00:42:46 --> Config Class Initialized
INFO - 2021-03-26 00:42:46 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:42:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:42:46 --> Utf8 Class Initialized
INFO - 2021-03-26 00:42:46 --> URI Class Initialized
INFO - 2021-03-26 00:42:46 --> Router Class Initialized
INFO - 2021-03-26 00:42:46 --> Output Class Initialized
INFO - 2021-03-26 00:42:46 --> Security Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:42:46 --> Input Class Initialized
INFO - 2021-03-26 00:42:46 --> Language Class Initialized
INFO - 2021-03-26 00:42:46 --> Loader Class Initialized
INFO - 2021-03-26 00:42:46 --> Helper loaded: url_helper
INFO - 2021-03-26 00:42:46 --> Helper loaded: form_helper
INFO - 2021-03-26 00:42:46 --> Helper loaded: common_helper
INFO - 2021-03-26 00:42:46 --> Helper loaded: util_helper
INFO - 2021-03-26 00:42:46 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:42:46 --> Form Validation Class Initialized
INFO - 2021-03-26 00:42:46 --> Controller Class Initialized
INFO - 2021-03-26 00:42:46 --> Model Class Initialized
INFO - 2021-03-26 00:42:46 --> Model Class Initialized
INFO - 2021-03-26 00:42:46 --> Model Class Initialized
INFO - 2021-03-26 00:42:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:42:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:42:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:42:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:42:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:42:46 --> Final output sent to browser
DEBUG - 2021-03-26 00:42:46 --> Total execution time: 0.0382
INFO - 2021-03-26 00:42:46 --> Config Class Initialized
INFO - 2021-03-26 00:42:46 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:42:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:42:46 --> Utf8 Class Initialized
INFO - 2021-03-26 00:42:46 --> URI Class Initialized
INFO - 2021-03-26 00:42:46 --> Router Class Initialized
INFO - 2021-03-26 00:42:46 --> Output Class Initialized
INFO - 2021-03-26 00:42:46 --> Security Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:42:46 --> Input Class Initialized
INFO - 2021-03-26 00:42:46 --> Language Class Initialized
INFO - 2021-03-26 00:42:46 --> Config Class Initialized
INFO - 2021-03-26 00:42:46 --> Hooks Class Initialized
ERROR - 2021-03-26 00:42:46 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:42:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:42:46 --> Utf8 Class Initialized
INFO - 2021-03-26 00:42:46 --> URI Class Initialized
INFO - 2021-03-26 00:42:46 --> Router Class Initialized
INFO - 2021-03-26 00:42:46 --> Output Class Initialized
INFO - 2021-03-26 00:42:46 --> Security Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:42:46 --> Input Class Initialized
INFO - 2021-03-26 00:42:46 --> Language Class Initialized
ERROR - 2021-03-26 00:42:46 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:42:46 --> Config Class Initialized
INFO - 2021-03-26 00:42:46 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:42:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:42:46 --> Utf8 Class Initialized
INFO - 2021-03-26 00:42:46 --> Config Class Initialized
INFO - 2021-03-26 00:42:46 --> URI Class Initialized
INFO - 2021-03-26 00:42:46 --> Hooks Class Initialized
INFO - 2021-03-26 00:42:46 --> Router Class Initialized
DEBUG - 2021-03-26 00:42:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:42:46 --> Output Class Initialized
INFO - 2021-03-26 00:42:46 --> Utf8 Class Initialized
INFO - 2021-03-26 00:42:46 --> Security Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:42:46 --> Input Class Initialized
INFO - 2021-03-26 00:42:46 --> Language Class Initialized
ERROR - 2021-03-26 00:42:46 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:42:46 --> URI Class Initialized
INFO - 2021-03-26 00:42:46 --> Router Class Initialized
INFO - 2021-03-26 00:42:46 --> Output Class Initialized
INFO - 2021-03-26 00:42:46 --> Security Class Initialized
DEBUG - 2021-03-26 00:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:42:46 --> Input Class Initialized
INFO - 2021-03-26 00:42:46 --> Language Class Initialized
ERROR - 2021-03-26 00:42:46 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:43:45 --> Config Class Initialized
INFO - 2021-03-26 00:43:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:43:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:43:45 --> URI Class Initialized
INFO - 2021-03-26 00:43:45 --> Router Class Initialized
INFO - 2021-03-26 00:43:45 --> Output Class Initialized
INFO - 2021-03-26 00:43:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:45 --> Input Class Initialized
INFO - 2021-03-26 00:43:45 --> Language Class Initialized
INFO - 2021-03-26 00:43:45 --> Loader Class Initialized
INFO - 2021-03-26 00:43:45 --> Helper loaded: url_helper
INFO - 2021-03-26 00:43:45 --> Helper loaded: form_helper
INFO - 2021-03-26 00:43:45 --> Helper loaded: common_helper
INFO - 2021-03-26 00:43:45 --> Helper loaded: util_helper
INFO - 2021-03-26 00:43:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:43:45 --> Form Validation Class Initialized
INFO - 2021-03-26 00:43:45 --> Controller Class Initialized
INFO - 2021-03-26 00:43:45 --> Model Class Initialized
INFO - 2021-03-26 00:43:45 --> Model Class Initialized
INFO - 2021-03-26 00:43:45 --> Model Class Initialized
INFO - 2021-03-26 00:43:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:43:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:43:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:43:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:43:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:43:45 --> Final output sent to browser
DEBUG - 2021-03-26 00:43:45 --> Total execution time: 0.0420
INFO - 2021-03-26 00:43:45 --> Config Class Initialized
INFO - 2021-03-26 00:43:45 --> Hooks Class Initialized
INFO - 2021-03-26 00:43:45 --> Config Class Initialized
INFO - 2021-03-26 00:43:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:43:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:43:45 --> URI Class Initialized
DEBUG - 2021-03-26 00:43:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:43:45 --> URI Class Initialized
INFO - 2021-03-26 00:43:45 --> Router Class Initialized
INFO - 2021-03-26 00:43:45 --> Router Class Initialized
INFO - 2021-03-26 00:43:45 --> Output Class Initialized
INFO - 2021-03-26 00:43:45 --> Output Class Initialized
INFO - 2021-03-26 00:43:45 --> Security Class Initialized
INFO - 2021-03-26 00:43:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:45 --> Input Class Initialized
INFO - 2021-03-26 00:43:45 --> Language Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:45 --> Input Class Initialized
ERROR - 2021-03-26 00:43:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:43:45 --> Language Class Initialized
ERROR - 2021-03-26 00:43:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:43:45 --> Config Class Initialized
INFO - 2021-03-26 00:43:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:43:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:45 --> Utf8 Class Initialized
INFO - 2021-03-26 00:43:45 --> URI Class Initialized
INFO - 2021-03-26 00:43:45 --> Router Class Initialized
INFO - 2021-03-26 00:43:45 --> Config Class Initialized
INFO - 2021-03-26 00:43:45 --> Hooks Class Initialized
INFO - 2021-03-26 00:43:45 --> Output Class Initialized
INFO - 2021-03-26 00:43:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:43:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:45 --> Input Class Initialized
INFO - 2021-03-26 00:43:45 --> URI Class Initialized
INFO - 2021-03-26 00:43:45 --> Language Class Initialized
INFO - 2021-03-26 00:43:45 --> Router Class Initialized
ERROR - 2021-03-26 00:43:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:43:45 --> Output Class Initialized
INFO - 2021-03-26 00:43:45 --> Security Class Initialized
DEBUG - 2021-03-26 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:45 --> Input Class Initialized
INFO - 2021-03-26 00:43:45 --> Language Class Initialized
ERROR - 2021-03-26 00:43:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:43:50 --> Config Class Initialized
INFO - 2021-03-26 00:43:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:43:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:43:50 --> Utf8 Class Initialized
INFO - 2021-03-26 00:43:50 --> URI Class Initialized
INFO - 2021-03-26 00:43:50 --> Router Class Initialized
INFO - 2021-03-26 00:43:50 --> Output Class Initialized
INFO - 2021-03-26 00:43:50 --> Security Class Initialized
DEBUG - 2021-03-26 00:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:43:50 --> Input Class Initialized
INFO - 2021-03-26 00:43:50 --> Language Class Initialized
INFO - 2021-03-26 00:43:50 --> Loader Class Initialized
INFO - 2021-03-26 00:43:50 --> Helper loaded: url_helper
INFO - 2021-03-26 00:43:50 --> Helper loaded: form_helper
INFO - 2021-03-26 00:43:50 --> Helper loaded: common_helper
INFO - 2021-03-26 00:43:50 --> Helper loaded: util_helper
INFO - 2021-03-26 00:43:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:43:50 --> Form Validation Class Initialized
INFO - 2021-03-26 00:43:50 --> Controller Class Initialized
INFO - 2021-03-26 00:43:50 --> Model Class Initialized
INFO - 2021-03-26 00:43:50 --> Model Class Initialized
INFO - 2021-03-26 00:43:50 --> Model Class Initialized
INFO - 2021-03-26 00:43:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:43:50 --> Final output sent to browser
DEBUG - 2021-03-26 00:43:50 --> Total execution time: 0.0365
INFO - 2021-03-26 00:55:03 --> Config Class Initialized
INFO - 2021-03-26 00:55:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:55:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:55:03 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:03 --> URI Class Initialized
INFO - 2021-03-26 00:55:03 --> Router Class Initialized
INFO - 2021-03-26 00:55:03 --> Output Class Initialized
INFO - 2021-03-26 00:55:03 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:03 --> Input Class Initialized
INFO - 2021-03-26 00:55:03 --> Language Class Initialized
INFO - 2021-03-26 00:55:03 --> Loader Class Initialized
INFO - 2021-03-26 00:55:03 --> Helper loaded: url_helper
INFO - 2021-03-26 00:55:03 --> Helper loaded: form_helper
INFO - 2021-03-26 00:55:03 --> Helper loaded: common_helper
INFO - 2021-03-26 00:55:03 --> Helper loaded: util_helper
INFO - 2021-03-26 00:55:03 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:55:03 --> Form Validation Class Initialized
INFO - 2021-03-26 00:55:03 --> Controller Class Initialized
INFO - 2021-03-26 00:55:03 --> Model Class Initialized
INFO - 2021-03-26 00:55:03 --> Model Class Initialized
INFO - 2021-03-26 00:55:03 --> Model Class Initialized
INFO - 2021-03-26 00:55:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:55:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:55:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:55:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:55:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:55:03 --> Final output sent to browser
DEBUG - 2021-03-26 00:55:03 --> Total execution time: 0.0390
INFO - 2021-03-26 00:55:03 --> Config Class Initialized
INFO - 2021-03-26 00:55:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:55:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:55:03 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:03 --> URI Class Initialized
INFO - 2021-03-26 00:55:03 --> Router Class Initialized
INFO - 2021-03-26 00:55:03 --> Config Class Initialized
INFO - 2021-03-26 00:55:03 --> Hooks Class Initialized
INFO - 2021-03-26 00:55:03 --> Output Class Initialized
INFO - 2021-03-26 00:55:03 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:03 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:03 --> Input Class Initialized
INFO - 2021-03-26 00:55:03 --> URI Class Initialized
INFO - 2021-03-26 00:55:03 --> Language Class Initialized
INFO - 2021-03-26 00:55:03 --> Router Class Initialized
ERROR - 2021-03-26 00:55:03 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:55:03 --> Output Class Initialized
INFO - 2021-03-26 00:55:03 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:03 --> Input Class Initialized
INFO - 2021-03-26 00:55:03 --> Language Class Initialized
ERROR - 2021-03-26 00:55:03 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:55:03 --> Config Class Initialized
INFO - 2021-03-26 00:55:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:55:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:55:03 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:03 --> URI Class Initialized
INFO - 2021-03-26 00:55:03 --> Router Class Initialized
INFO - 2021-03-26 00:55:03 --> Output Class Initialized
INFO - 2021-03-26 00:55:03 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:03 --> Input Class Initialized
INFO - 2021-03-26 00:55:03 --> Language Class Initialized
ERROR - 2021-03-26 00:55:03 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:55:03 --> Config Class Initialized
INFO - 2021-03-26 00:55:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:55:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:55:03 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:03 --> URI Class Initialized
INFO - 2021-03-26 00:55:03 --> Router Class Initialized
INFO - 2021-03-26 00:55:03 --> Output Class Initialized
INFO - 2021-03-26 00:55:03 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:03 --> Input Class Initialized
INFO - 2021-03-26 00:55:03 --> Language Class Initialized
ERROR - 2021-03-26 00:55:03 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:55:15 --> Config Class Initialized
INFO - 2021-03-26 00:55:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:55:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:55:15 --> Utf8 Class Initialized
INFO - 2021-03-26 00:55:15 --> URI Class Initialized
INFO - 2021-03-26 00:55:15 --> Router Class Initialized
INFO - 2021-03-26 00:55:15 --> Output Class Initialized
INFO - 2021-03-26 00:55:15 --> Security Class Initialized
DEBUG - 2021-03-26 00:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:55:15 --> Input Class Initialized
INFO - 2021-03-26 00:55:15 --> Language Class Initialized
INFO - 2021-03-26 00:55:15 --> Loader Class Initialized
INFO - 2021-03-26 00:55:15 --> Helper loaded: url_helper
INFO - 2021-03-26 00:55:15 --> Helper loaded: form_helper
INFO - 2021-03-26 00:55:15 --> Helper loaded: common_helper
INFO - 2021-03-26 00:55:15 --> Helper loaded: util_helper
INFO - 2021-03-26 00:55:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:55:15 --> Form Validation Class Initialized
INFO - 2021-03-26 00:55:15 --> Controller Class Initialized
INFO - 2021-03-26 00:55:15 --> Model Class Initialized
INFO - 2021-03-26 00:55:15 --> Model Class Initialized
INFO - 2021-03-26 00:55:15 --> Model Class Initialized
INFO - 2021-03-26 00:55:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:55:15 --> Final output sent to browser
DEBUG - 2021-03-26 00:55:15 --> Total execution time: 0.0498
INFO - 2021-03-26 00:58:51 --> Config Class Initialized
INFO - 2021-03-26 00:58:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:51 --> URI Class Initialized
INFO - 2021-03-26 00:58:51 --> Router Class Initialized
INFO - 2021-03-26 00:58:51 --> Output Class Initialized
INFO - 2021-03-26 00:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:51 --> Input Class Initialized
INFO - 2021-03-26 00:58:51 --> Language Class Initialized
INFO - 2021-03-26 00:58:51 --> Loader Class Initialized
INFO - 2021-03-26 00:58:51 --> Helper loaded: url_helper
INFO - 2021-03-26 00:58:51 --> Helper loaded: form_helper
INFO - 2021-03-26 00:58:51 --> Helper loaded: common_helper
INFO - 2021-03-26 00:58:51 --> Helper loaded: util_helper
INFO - 2021-03-26 00:58:51 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:58:51 --> Form Validation Class Initialized
INFO - 2021-03-26 00:58:51 --> Controller Class Initialized
INFO - 2021-03-26 00:58:51 --> Model Class Initialized
INFO - 2021-03-26 00:58:51 --> Model Class Initialized
INFO - 2021-03-26 00:58:51 --> Model Class Initialized
INFO - 2021-03-26 00:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 00:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 00:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 00:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 00:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 00:58:51 --> Final output sent to browser
DEBUG - 2021-03-26 00:58:51 --> Total execution time: 0.0412
INFO - 2021-03-26 00:58:51 --> Config Class Initialized
INFO - 2021-03-26 00:58:51 --> Hooks Class Initialized
INFO - 2021-03-26 00:58:51 --> Config Class Initialized
INFO - 2021-03-26 00:58:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:51 --> URI Class Initialized
DEBUG - 2021-03-26 00:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:51 --> URI Class Initialized
INFO - 2021-03-26 00:58:51 --> Router Class Initialized
INFO - 2021-03-26 00:58:51 --> Output Class Initialized
INFO - 2021-03-26 00:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:51 --> Input Class Initialized
INFO - 2021-03-26 00:58:51 --> Router Class Initialized
INFO - 2021-03-26 00:58:51 --> Language Class Initialized
INFO - 2021-03-26 00:58:51 --> Output Class Initialized
ERROR - 2021-03-26 00:58:51 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:51 --> Input Class Initialized
INFO - 2021-03-26 00:58:51 --> Language Class Initialized
ERROR - 2021-03-26 00:58:51 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:58:51 --> Config Class Initialized
INFO - 2021-03-26 00:58:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:51 --> URI Class Initialized
INFO - 2021-03-26 00:58:51 --> Router Class Initialized
INFO - 2021-03-26 00:58:51 --> Output Class Initialized
INFO - 2021-03-26 00:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:51 --> Input Class Initialized
INFO - 2021-03-26 00:58:51 --> Language Class Initialized
INFO - 2021-03-26 00:58:51 --> Config Class Initialized
INFO - 2021-03-26 00:58:51 --> Hooks Class Initialized
ERROR - 2021-03-26 00:58:51 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 00:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:51 --> URI Class Initialized
INFO - 2021-03-26 00:58:51 --> Router Class Initialized
INFO - 2021-03-26 00:58:51 --> Output Class Initialized
INFO - 2021-03-26 00:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:51 --> Input Class Initialized
INFO - 2021-03-26 00:58:51 --> Language Class Initialized
ERROR - 2021-03-26 00:58:51 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 00:58:54 --> Config Class Initialized
INFO - 2021-03-26 00:58:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 00:58:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 00:58:54 --> Utf8 Class Initialized
INFO - 2021-03-26 00:58:54 --> URI Class Initialized
INFO - 2021-03-26 00:58:54 --> Router Class Initialized
INFO - 2021-03-26 00:58:54 --> Output Class Initialized
INFO - 2021-03-26 00:58:54 --> Security Class Initialized
DEBUG - 2021-03-26 00:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 00:58:54 --> Input Class Initialized
INFO - 2021-03-26 00:58:54 --> Language Class Initialized
INFO - 2021-03-26 00:58:54 --> Loader Class Initialized
INFO - 2021-03-26 00:58:54 --> Helper loaded: url_helper
INFO - 2021-03-26 00:58:54 --> Helper loaded: form_helper
INFO - 2021-03-26 00:58:54 --> Helper loaded: common_helper
INFO - 2021-03-26 00:58:54 --> Helper loaded: util_helper
INFO - 2021-03-26 00:58:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 00:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 00:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 00:58:54 --> Form Validation Class Initialized
INFO - 2021-03-26 00:58:54 --> Controller Class Initialized
INFO - 2021-03-26 00:58:54 --> Model Class Initialized
INFO - 2021-03-26 00:58:54 --> Model Class Initialized
INFO - 2021-03-26 00:58:54 --> Model Class Initialized
INFO - 2021-03-26 00:58:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 00:58:54 --> Final output sent to browser
DEBUG - 2021-03-26 00:58:54 --> Total execution time: 0.0463
INFO - 2021-03-26 01:07:52 --> Config Class Initialized
INFO - 2021-03-26 01:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:07:52 --> URI Class Initialized
INFO - 2021-03-26 01:07:52 --> Router Class Initialized
INFO - 2021-03-26 01:07:52 --> Output Class Initialized
INFO - 2021-03-26 01:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 01:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:07:52 --> Input Class Initialized
INFO - 2021-03-26 01:07:52 --> Language Class Initialized
INFO - 2021-03-26 01:07:52 --> Loader Class Initialized
INFO - 2021-03-26 01:07:52 --> Helper loaded: url_helper
INFO - 2021-03-26 01:07:52 --> Helper loaded: form_helper
INFO - 2021-03-26 01:07:52 --> Helper loaded: common_helper
INFO - 2021-03-26 01:07:52 --> Helper loaded: util_helper
INFO - 2021-03-26 01:07:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:07:52 --> Form Validation Class Initialized
INFO - 2021-03-26 01:07:52 --> Controller Class Initialized
INFO - 2021-03-26 01:07:52 --> Model Class Initialized
INFO - 2021-03-26 01:07:52 --> Model Class Initialized
INFO - 2021-03-26 01:07:52 --> Model Class Initialized
INFO - 2021-03-26 01:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:07:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:07:52 --> Final output sent to browser
DEBUG - 2021-03-26 01:07:52 --> Total execution time: 0.0375
INFO - 2021-03-26 01:07:52 --> Config Class Initialized
INFO - 2021-03-26 01:07:52 --> Hooks Class Initialized
INFO - 2021-03-26 01:07:52 --> Config Class Initialized
INFO - 2021-03-26 01:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:07:52 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:07:52 --> URI Class Initialized
INFO - 2021-03-26 01:07:52 --> URI Class Initialized
INFO - 2021-03-26 01:07:52 --> Router Class Initialized
INFO - 2021-03-26 01:07:52 --> Output Class Initialized
INFO - 2021-03-26 01:07:52 --> Router Class Initialized
INFO - 2021-03-26 01:07:52 --> Security Class Initialized
INFO - 2021-03-26 01:07:52 --> Output Class Initialized
DEBUG - 2021-03-26 01:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:07:52 --> Input Class Initialized
INFO - 2021-03-26 01:07:52 --> Language Class Initialized
INFO - 2021-03-26 01:07:52 --> Security Class Initialized
ERROR - 2021-03-26 01:07:52 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 01:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:07:52 --> Input Class Initialized
INFO - 2021-03-26 01:07:52 --> Language Class Initialized
ERROR - 2021-03-26 01:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:07:52 --> Config Class Initialized
INFO - 2021-03-26 01:07:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:07:52 --> URI Class Initialized
INFO - 2021-03-26 01:07:52 --> Config Class Initialized
INFO - 2021-03-26 01:07:52 --> Hooks Class Initialized
INFO - 2021-03-26 01:07:52 --> Router Class Initialized
DEBUG - 2021-03-26 01:07:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:07:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:07:52 --> Output Class Initialized
INFO - 2021-03-26 01:07:52 --> URI Class Initialized
INFO - 2021-03-26 01:07:52 --> Security Class Initialized
INFO - 2021-03-26 01:07:52 --> Router Class Initialized
DEBUG - 2021-03-26 01:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:07:52 --> Input Class Initialized
INFO - 2021-03-26 01:07:52 --> Language Class Initialized
INFO - 2021-03-26 01:07:52 --> Output Class Initialized
ERROR - 2021-03-26 01:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:07:52 --> Security Class Initialized
DEBUG - 2021-03-26 01:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:07:52 --> Input Class Initialized
INFO - 2021-03-26 01:07:52 --> Language Class Initialized
ERROR - 2021-03-26 01:07:52 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:08:00 --> Config Class Initialized
INFO - 2021-03-26 01:08:00 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:08:00 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:00 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:00 --> URI Class Initialized
INFO - 2021-03-26 01:08:00 --> Router Class Initialized
INFO - 2021-03-26 01:08:00 --> Output Class Initialized
INFO - 2021-03-26 01:08:00 --> Security Class Initialized
DEBUG - 2021-03-26 01:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:00 --> Input Class Initialized
INFO - 2021-03-26 01:08:00 --> Language Class Initialized
INFO - 2021-03-26 01:08:00 --> Loader Class Initialized
INFO - 2021-03-26 01:08:00 --> Helper loaded: url_helper
INFO - 2021-03-26 01:08:00 --> Helper loaded: form_helper
INFO - 2021-03-26 01:08:00 --> Helper loaded: common_helper
INFO - 2021-03-26 01:08:00 --> Helper loaded: util_helper
INFO - 2021-03-26 01:08:00 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:08:00 --> Form Validation Class Initialized
INFO - 2021-03-26 01:08:00 --> Controller Class Initialized
INFO - 2021-03-26 01:08:00 --> Model Class Initialized
INFO - 2021-03-26 01:08:00 --> Model Class Initialized
INFO - 2021-03-26 01:08:00 --> Model Class Initialized
INFO - 2021-03-26 01:08:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:08:00 --> Final output sent to browser
DEBUG - 2021-03-26 01:08:00 --> Total execution time: 0.0350
INFO - 2021-03-26 01:08:58 --> Config Class Initialized
INFO - 2021-03-26 01:08:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:08:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:58 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:58 --> URI Class Initialized
INFO - 2021-03-26 01:08:58 --> Router Class Initialized
INFO - 2021-03-26 01:08:58 --> Output Class Initialized
INFO - 2021-03-26 01:08:58 --> Security Class Initialized
DEBUG - 2021-03-26 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:58 --> Input Class Initialized
INFO - 2021-03-26 01:08:58 --> Language Class Initialized
INFO - 2021-03-26 01:08:58 --> Loader Class Initialized
INFO - 2021-03-26 01:08:58 --> Helper loaded: url_helper
INFO - 2021-03-26 01:08:58 --> Helper loaded: form_helper
INFO - 2021-03-26 01:08:58 --> Helper loaded: common_helper
INFO - 2021-03-26 01:08:58 --> Helper loaded: util_helper
INFO - 2021-03-26 01:08:58 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:08:58 --> Form Validation Class Initialized
INFO - 2021-03-26 01:08:58 --> Controller Class Initialized
INFO - 2021-03-26 01:08:58 --> Model Class Initialized
INFO - 2021-03-26 01:08:58 --> Model Class Initialized
INFO - 2021-03-26 01:08:58 --> Model Class Initialized
INFO - 2021-03-26 01:08:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:08:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:08:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:08:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:08:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:08:58 --> Final output sent to browser
DEBUG - 2021-03-26 01:08:58 --> Total execution time: 0.0383
INFO - 2021-03-26 01:08:59 --> Config Class Initialized
INFO - 2021-03-26 01:08:59 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:59 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:59 --> URI Class Initialized
INFO - 2021-03-26 01:08:59 --> Config Class Initialized
INFO - 2021-03-26 01:08:59 --> Hooks Class Initialized
INFO - 2021-03-26 01:08:59 --> Router Class Initialized
DEBUG - 2021-03-26 01:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:59 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:59 --> Output Class Initialized
INFO - 2021-03-26 01:08:59 --> URI Class Initialized
INFO - 2021-03-26 01:08:59 --> Router Class Initialized
INFO - 2021-03-26 01:08:59 --> Security Class Initialized
DEBUG - 2021-03-26 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:59 --> Input Class Initialized
INFO - 2021-03-26 01:08:59 --> Output Class Initialized
INFO - 2021-03-26 01:08:59 --> Language Class Initialized
INFO - 2021-03-26 01:08:59 --> Security Class Initialized
DEBUG - 2021-03-26 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:59 --> Input Class Initialized
INFO - 2021-03-26 01:08:59 --> Language Class Initialized
ERROR - 2021-03-26 01:08:59 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:08:59 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:08:59 --> Config Class Initialized
INFO - 2021-03-26 01:08:59 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:59 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:59 --> Config Class Initialized
INFO - 2021-03-26 01:08:59 --> URI Class Initialized
INFO - 2021-03-26 01:08:59 --> Hooks Class Initialized
INFO - 2021-03-26 01:08:59 --> Router Class Initialized
INFO - 2021-03-26 01:08:59 --> Output Class Initialized
DEBUG - 2021-03-26 01:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:08:59 --> Utf8 Class Initialized
INFO - 2021-03-26 01:08:59 --> Security Class Initialized
INFO - 2021-03-26 01:08:59 --> URI Class Initialized
DEBUG - 2021-03-26 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:59 --> Input Class Initialized
INFO - 2021-03-26 01:08:59 --> Language Class Initialized
INFO - 2021-03-26 01:08:59 --> Router Class Initialized
ERROR - 2021-03-26 01:08:59 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:08:59 --> Output Class Initialized
INFO - 2021-03-26 01:08:59 --> Security Class Initialized
DEBUG - 2021-03-26 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:08:59 --> Input Class Initialized
INFO - 2021-03-26 01:08:59 --> Language Class Initialized
ERROR - 2021-03-26 01:08:59 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:09:01 --> Config Class Initialized
INFO - 2021-03-26 01:09:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:09:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:01 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:01 --> URI Class Initialized
INFO - 2021-03-26 01:09:01 --> Router Class Initialized
INFO - 2021-03-26 01:09:01 --> Output Class Initialized
INFO - 2021-03-26 01:09:01 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:01 --> Input Class Initialized
INFO - 2021-03-26 01:09:01 --> Language Class Initialized
INFO - 2021-03-26 01:09:01 --> Loader Class Initialized
INFO - 2021-03-26 01:09:01 --> Helper loaded: url_helper
INFO - 2021-03-26 01:09:01 --> Helper loaded: form_helper
INFO - 2021-03-26 01:09:01 --> Helper loaded: common_helper
INFO - 2021-03-26 01:09:01 --> Helper loaded: util_helper
INFO - 2021-03-26 01:09:01 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:09:01 --> Form Validation Class Initialized
INFO - 2021-03-26 01:09:01 --> Controller Class Initialized
INFO - 2021-03-26 01:09:01 --> Model Class Initialized
INFO - 2021-03-26 01:09:01 --> Model Class Initialized
INFO - 2021-03-26 01:09:01 --> Model Class Initialized
INFO - 2021-03-26 01:09:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:09:01 --> Final output sent to browser
DEBUG - 2021-03-26 01:09:01 --> Total execution time: 0.0347
INFO - 2021-03-26 01:09:45 --> Config Class Initialized
INFO - 2021-03-26 01:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:45 --> URI Class Initialized
INFO - 2021-03-26 01:09:45 --> Router Class Initialized
INFO - 2021-03-26 01:09:45 --> Output Class Initialized
INFO - 2021-03-26 01:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:45 --> Input Class Initialized
INFO - 2021-03-26 01:09:45 --> Language Class Initialized
INFO - 2021-03-26 01:09:45 --> Loader Class Initialized
INFO - 2021-03-26 01:09:45 --> Helper loaded: url_helper
INFO - 2021-03-26 01:09:45 --> Helper loaded: form_helper
INFO - 2021-03-26 01:09:45 --> Helper loaded: common_helper
INFO - 2021-03-26 01:09:45 --> Helper loaded: util_helper
INFO - 2021-03-26 01:09:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:09:45 --> Form Validation Class Initialized
INFO - 2021-03-26 01:09:45 --> Controller Class Initialized
INFO - 2021-03-26 01:09:45 --> Model Class Initialized
INFO - 2021-03-26 01:09:45 --> Model Class Initialized
INFO - 2021-03-26 01:09:45 --> Model Class Initialized
INFO - 2021-03-26 01:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:09:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:09:45 --> Final output sent to browser
DEBUG - 2021-03-26 01:09:45 --> Total execution time: 0.0409
INFO - 2021-03-26 01:09:45 --> Config Class Initialized
INFO - 2021-03-26 01:09:45 --> Hooks Class Initialized
INFO - 2021-03-26 01:09:45 --> Config Class Initialized
INFO - 2021-03-26 01:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:45 --> URI Class Initialized
INFO - 2021-03-26 01:09:45 --> Router Class Initialized
INFO - 2021-03-26 01:09:45 --> Output Class Initialized
INFO - 2021-03-26 01:09:45 --> URI Class Initialized
INFO - 2021-03-26 01:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:45 --> Input Class Initialized
INFO - 2021-03-26 01:09:45 --> Language Class Initialized
INFO - 2021-03-26 01:09:45 --> Router Class Initialized
ERROR - 2021-03-26 01:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:09:45 --> Output Class Initialized
INFO - 2021-03-26 01:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:45 --> Input Class Initialized
INFO - 2021-03-26 01:09:45 --> Language Class Initialized
ERROR - 2021-03-26 01:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:09:45 --> Config Class Initialized
INFO - 2021-03-26 01:09:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:09:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:45 --> URI Class Initialized
INFO - 2021-03-26 01:09:45 --> Router Class Initialized
INFO - 2021-03-26 01:09:45 --> Output Class Initialized
INFO - 2021-03-26 01:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:45 --> Config Class Initialized
INFO - 2021-03-26 01:09:45 --> Input Class Initialized
INFO - 2021-03-26 01:09:45 --> Hooks Class Initialized
INFO - 2021-03-26 01:09:45 --> Language Class Initialized
DEBUG - 2021-03-26 01:09:45 --> UTF-8 Support Enabled
ERROR - 2021-03-26 01:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:09:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:45 --> URI Class Initialized
INFO - 2021-03-26 01:09:45 --> Router Class Initialized
INFO - 2021-03-26 01:09:45 --> Output Class Initialized
INFO - 2021-03-26 01:09:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:45 --> Input Class Initialized
INFO - 2021-03-26 01:09:45 --> Language Class Initialized
ERROR - 2021-03-26 01:09:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:09:52 --> Config Class Initialized
INFO - 2021-03-26 01:09:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:09:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:09:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:09:52 --> URI Class Initialized
INFO - 2021-03-26 01:09:52 --> Router Class Initialized
INFO - 2021-03-26 01:09:52 --> Output Class Initialized
INFO - 2021-03-26 01:09:52 --> Security Class Initialized
DEBUG - 2021-03-26 01:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:09:52 --> Input Class Initialized
INFO - 2021-03-26 01:09:52 --> Language Class Initialized
INFO - 2021-03-26 01:09:52 --> Loader Class Initialized
INFO - 2021-03-26 01:09:52 --> Helper loaded: url_helper
INFO - 2021-03-26 01:09:52 --> Helper loaded: form_helper
INFO - 2021-03-26 01:09:52 --> Helper loaded: common_helper
INFO - 2021-03-26 01:09:52 --> Helper loaded: util_helper
INFO - 2021-03-26 01:09:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:09:52 --> Form Validation Class Initialized
INFO - 2021-03-26 01:09:52 --> Controller Class Initialized
INFO - 2021-03-26 01:09:52 --> Model Class Initialized
INFO - 2021-03-26 01:09:52 --> Model Class Initialized
INFO - 2021-03-26 01:09:52 --> Model Class Initialized
INFO - 2021-03-26 01:09:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:09:52 --> Final output sent to browser
DEBUG - 2021-03-26 01:09:52 --> Total execution time: 0.0606
INFO - 2021-03-26 01:10:35 --> Config Class Initialized
INFO - 2021-03-26 01:10:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:10:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:10:35 --> Utf8 Class Initialized
INFO - 2021-03-26 01:10:35 --> URI Class Initialized
INFO - 2021-03-26 01:10:35 --> Router Class Initialized
INFO - 2021-03-26 01:10:35 --> Output Class Initialized
INFO - 2021-03-26 01:10:35 --> Security Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:10:35 --> Input Class Initialized
INFO - 2021-03-26 01:10:35 --> Language Class Initialized
INFO - 2021-03-26 01:10:35 --> Loader Class Initialized
INFO - 2021-03-26 01:10:35 --> Helper loaded: url_helper
INFO - 2021-03-26 01:10:35 --> Helper loaded: form_helper
INFO - 2021-03-26 01:10:35 --> Helper loaded: common_helper
INFO - 2021-03-26 01:10:35 --> Helper loaded: util_helper
INFO - 2021-03-26 01:10:35 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:10:35 --> Form Validation Class Initialized
INFO - 2021-03-26 01:10:35 --> Controller Class Initialized
INFO - 2021-03-26 01:10:35 --> Model Class Initialized
INFO - 2021-03-26 01:10:35 --> Model Class Initialized
INFO - 2021-03-26 01:10:35 --> Model Class Initialized
INFO - 2021-03-26 01:10:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:10:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:10:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:10:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:10:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:10:35 --> Final output sent to browser
DEBUG - 2021-03-26 01:10:35 --> Total execution time: 0.0499
INFO - 2021-03-26 01:10:35 --> Config Class Initialized
INFO - 2021-03-26 01:10:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:10:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:10:35 --> Utf8 Class Initialized
INFO - 2021-03-26 01:10:35 --> URI Class Initialized
INFO - 2021-03-26 01:10:35 --> Router Class Initialized
INFO - 2021-03-26 01:10:35 --> Output Class Initialized
INFO - 2021-03-26 01:10:35 --> Security Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:10:35 --> Input Class Initialized
INFO - 2021-03-26 01:10:35 --> Language Class Initialized
ERROR - 2021-03-26 01:10:35 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:10:35 --> Config Class Initialized
INFO - 2021-03-26 01:10:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:10:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:10:35 --> Utf8 Class Initialized
INFO - 2021-03-26 01:10:35 --> URI Class Initialized
INFO - 2021-03-26 01:10:35 --> Router Class Initialized
INFO - 2021-03-26 01:10:35 --> Output Class Initialized
INFO - 2021-03-26 01:10:35 --> Security Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:10:35 --> Input Class Initialized
INFO - 2021-03-26 01:10:35 --> Language Class Initialized
ERROR - 2021-03-26 01:10:35 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:10:35 --> Config Class Initialized
INFO - 2021-03-26 01:10:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:10:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:10:35 --> Utf8 Class Initialized
INFO - 2021-03-26 01:10:35 --> URI Class Initialized
INFO - 2021-03-26 01:10:35 --> Router Class Initialized
INFO - 2021-03-26 01:10:35 --> Config Class Initialized
INFO - 2021-03-26 01:10:35 --> Output Class Initialized
INFO - 2021-03-26 01:10:35 --> Hooks Class Initialized
INFO - 2021-03-26 01:10:35 --> Security Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:10:35 --> Input Class Initialized
DEBUG - 2021-03-26 01:10:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:10:35 --> Language Class Initialized
INFO - 2021-03-26 01:10:35 --> Utf8 Class Initialized
INFO - 2021-03-26 01:10:35 --> URI Class Initialized
ERROR - 2021-03-26 01:10:35 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:10:35 --> Router Class Initialized
INFO - 2021-03-26 01:10:35 --> Output Class Initialized
INFO - 2021-03-26 01:10:35 --> Security Class Initialized
DEBUG - 2021-03-26 01:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:10:35 --> Input Class Initialized
INFO - 2021-03-26 01:10:35 --> Language Class Initialized
ERROR - 2021-03-26 01:10:35 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:11:13 --> Config Class Initialized
INFO - 2021-03-26 01:11:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:11:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:11:13 --> Utf8 Class Initialized
INFO - 2021-03-26 01:11:13 --> URI Class Initialized
INFO - 2021-03-26 01:11:13 --> Router Class Initialized
INFO - 2021-03-26 01:11:13 --> Output Class Initialized
INFO - 2021-03-26 01:11:13 --> Security Class Initialized
DEBUG - 2021-03-26 01:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:11:13 --> Input Class Initialized
INFO - 2021-03-26 01:11:13 --> Language Class Initialized
INFO - 2021-03-26 01:11:13 --> Loader Class Initialized
INFO - 2021-03-26 01:11:13 --> Helper loaded: url_helper
INFO - 2021-03-26 01:11:13 --> Helper loaded: form_helper
INFO - 2021-03-26 01:11:13 --> Helper loaded: common_helper
INFO - 2021-03-26 01:11:13 --> Helper loaded: util_helper
INFO - 2021-03-26 01:11:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:11:13 --> Form Validation Class Initialized
INFO - 2021-03-26 01:11:13 --> Controller Class Initialized
INFO - 2021-03-26 01:11:13 --> Model Class Initialized
INFO - 2021-03-26 01:11:13 --> Model Class Initialized
INFO - 2021-03-26 01:11:13 --> Model Class Initialized
INFO - 2021-03-26 01:11:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:11:13 --> Final output sent to browser
DEBUG - 2021-03-26 01:11:13 --> Total execution time: 0.0380
INFO - 2021-03-26 01:12:11 --> Config Class Initialized
INFO - 2021-03-26 01:12:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:12:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:11 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:11 --> URI Class Initialized
INFO - 2021-03-26 01:12:11 --> Router Class Initialized
INFO - 2021-03-26 01:12:11 --> Output Class Initialized
INFO - 2021-03-26 01:12:11 --> Security Class Initialized
DEBUG - 2021-03-26 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:11 --> Input Class Initialized
INFO - 2021-03-26 01:12:11 --> Language Class Initialized
INFO - 2021-03-26 01:12:11 --> Loader Class Initialized
INFO - 2021-03-26 01:12:11 --> Helper loaded: url_helper
INFO - 2021-03-26 01:12:11 --> Helper loaded: form_helper
INFO - 2021-03-26 01:12:11 --> Helper loaded: common_helper
INFO - 2021-03-26 01:12:11 --> Helper loaded: util_helper
INFO - 2021-03-26 01:12:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:12:11 --> Form Validation Class Initialized
INFO - 2021-03-26 01:12:11 --> Controller Class Initialized
INFO - 2021-03-26 01:12:11 --> Model Class Initialized
INFO - 2021-03-26 01:12:11 --> Model Class Initialized
INFO - 2021-03-26 01:12:11 --> Model Class Initialized
INFO - 2021-03-26 01:12:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:12:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:12:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:12:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:12:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:12:11 --> Final output sent to browser
DEBUG - 2021-03-26 01:12:11 --> Total execution time: 0.0515
INFO - 2021-03-26 01:12:11 --> Config Class Initialized
INFO - 2021-03-26 01:12:11 --> Hooks Class Initialized
INFO - 2021-03-26 01:12:11 --> Config Class Initialized
DEBUG - 2021-03-26 01:12:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:11 --> Hooks Class Initialized
INFO - 2021-03-26 01:12:11 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:11 --> URI Class Initialized
INFO - 2021-03-26 01:12:11 --> Router Class Initialized
DEBUG - 2021-03-26 01:12:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:11 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:11 --> Output Class Initialized
INFO - 2021-03-26 01:12:11 --> URI Class Initialized
INFO - 2021-03-26 01:12:11 --> Security Class Initialized
INFO - 2021-03-26 01:12:11 --> Router Class Initialized
DEBUG - 2021-03-26 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:11 --> Input Class Initialized
INFO - 2021-03-26 01:12:11 --> Language Class Initialized
INFO - 2021-03-26 01:12:11 --> Output Class Initialized
ERROR - 2021-03-26 01:12:11 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:12:11 --> Security Class Initialized
DEBUG - 2021-03-26 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:11 --> Input Class Initialized
INFO - 2021-03-26 01:12:11 --> Language Class Initialized
ERROR - 2021-03-26 01:12:11 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:12:11 --> Config Class Initialized
INFO - 2021-03-26 01:12:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:12:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:11 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:11 --> URI Class Initialized
INFO - 2021-03-26 01:12:11 --> Config Class Initialized
INFO - 2021-03-26 01:12:11 --> Hooks Class Initialized
INFO - 2021-03-26 01:12:11 --> Router Class Initialized
DEBUG - 2021-03-26 01:12:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:11 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:11 --> Output Class Initialized
INFO - 2021-03-26 01:12:11 --> URI Class Initialized
INFO - 2021-03-26 01:12:11 --> Security Class Initialized
INFO - 2021-03-26 01:12:11 --> Router Class Initialized
DEBUG - 2021-03-26 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:11 --> Input Class Initialized
INFO - 2021-03-26 01:12:11 --> Output Class Initialized
INFO - 2021-03-26 01:12:11 --> Language Class Initialized
INFO - 2021-03-26 01:12:11 --> Security Class Initialized
ERROR - 2021-03-26 01:12:11 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 01:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:11 --> Input Class Initialized
INFO - 2021-03-26 01:12:11 --> Language Class Initialized
ERROR - 2021-03-26 01:12:11 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:12:20 --> Config Class Initialized
INFO - 2021-03-26 01:12:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:12:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:12:20 --> Utf8 Class Initialized
INFO - 2021-03-26 01:12:20 --> URI Class Initialized
INFO - 2021-03-26 01:12:20 --> Router Class Initialized
INFO - 2021-03-26 01:12:20 --> Output Class Initialized
INFO - 2021-03-26 01:12:20 --> Security Class Initialized
DEBUG - 2021-03-26 01:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:12:20 --> Input Class Initialized
INFO - 2021-03-26 01:12:20 --> Language Class Initialized
INFO - 2021-03-26 01:12:20 --> Loader Class Initialized
INFO - 2021-03-26 01:12:20 --> Helper loaded: url_helper
INFO - 2021-03-26 01:12:20 --> Helper loaded: form_helper
INFO - 2021-03-26 01:12:20 --> Helper loaded: common_helper
INFO - 2021-03-26 01:12:20 --> Helper loaded: util_helper
INFO - 2021-03-26 01:12:20 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:12:20 --> Form Validation Class Initialized
INFO - 2021-03-26 01:12:20 --> Controller Class Initialized
INFO - 2021-03-26 01:12:20 --> Model Class Initialized
INFO - 2021-03-26 01:12:20 --> Model Class Initialized
INFO - 2021-03-26 01:12:20 --> Model Class Initialized
INFO - 2021-03-26 01:12:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:12:20 --> Final output sent to browser
DEBUG - 2021-03-26 01:12:20 --> Total execution time: 0.0371
INFO - 2021-03-26 01:20:37 --> Config Class Initialized
INFO - 2021-03-26 01:20:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:20:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:37 --> Utf8 Class Initialized
INFO - 2021-03-26 01:20:37 --> URI Class Initialized
INFO - 2021-03-26 01:20:37 --> Router Class Initialized
INFO - 2021-03-26 01:20:37 --> Output Class Initialized
INFO - 2021-03-26 01:20:37 --> Security Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:37 --> Input Class Initialized
INFO - 2021-03-26 01:20:37 --> Language Class Initialized
INFO - 2021-03-26 01:20:37 --> Loader Class Initialized
INFO - 2021-03-26 01:20:37 --> Helper loaded: url_helper
INFO - 2021-03-26 01:20:37 --> Helper loaded: form_helper
INFO - 2021-03-26 01:20:37 --> Helper loaded: common_helper
INFO - 2021-03-26 01:20:37 --> Helper loaded: util_helper
INFO - 2021-03-26 01:20:37 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:20:37 --> Form Validation Class Initialized
INFO - 2021-03-26 01:20:37 --> Controller Class Initialized
INFO - 2021-03-26 01:20:37 --> Model Class Initialized
INFO - 2021-03-26 01:20:37 --> Model Class Initialized
INFO - 2021-03-26 01:20:37 --> Model Class Initialized
INFO - 2021-03-26 01:20:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:20:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:20:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:20:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:20:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:20:37 --> Final output sent to browser
DEBUG - 2021-03-26 01:20:37 --> Total execution time: 0.0564
INFO - 2021-03-26 01:20:37 --> Config Class Initialized
INFO - 2021-03-26 01:20:37 --> Hooks Class Initialized
INFO - 2021-03-26 01:20:37 --> Config Class Initialized
INFO - 2021-03-26 01:20:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:20:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:37 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:20:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:37 --> URI Class Initialized
INFO - 2021-03-26 01:20:37 --> Utf8 Class Initialized
INFO - 2021-03-26 01:20:37 --> URI Class Initialized
INFO - 2021-03-26 01:20:37 --> Router Class Initialized
INFO - 2021-03-26 01:20:37 --> Router Class Initialized
INFO - 2021-03-26 01:20:37 --> Output Class Initialized
INFO - 2021-03-26 01:20:37 --> Output Class Initialized
INFO - 2021-03-26 01:20:37 --> Security Class Initialized
INFO - 2021-03-26 01:20:37 --> Security Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:37 --> Input Class Initialized
INFO - 2021-03-26 01:20:37 --> Language Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:37 --> Input Class Initialized
INFO - 2021-03-26 01:20:37 --> Language Class Initialized
ERROR - 2021-03-26 01:20:37 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:20:37 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:20:37 --> Config Class Initialized
INFO - 2021-03-26 01:20:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:20:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:37 --> Utf8 Class Initialized
INFO - 2021-03-26 01:20:37 --> URI Class Initialized
INFO - 2021-03-26 01:20:37 --> Router Class Initialized
INFO - 2021-03-26 01:20:37 --> Output Class Initialized
INFO - 2021-03-26 01:20:37 --> Security Class Initialized
INFO - 2021-03-26 01:20:37 --> Config Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:37 --> Input Class Initialized
INFO - 2021-03-26 01:20:37 --> Hooks Class Initialized
INFO - 2021-03-26 01:20:37 --> Language Class Initialized
ERROR - 2021-03-26 01:20:37 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 01:20:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:37 --> Utf8 Class Initialized
INFO - 2021-03-26 01:20:37 --> URI Class Initialized
INFO - 2021-03-26 01:20:37 --> Router Class Initialized
INFO - 2021-03-26 01:20:37 --> Output Class Initialized
INFO - 2021-03-26 01:20:37 --> Security Class Initialized
DEBUG - 2021-03-26 01:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:37 --> Input Class Initialized
INFO - 2021-03-26 01:20:37 --> Language Class Initialized
ERROR - 2021-03-26 01:20:37 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:20:42 --> Config Class Initialized
INFO - 2021-03-26 01:20:42 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:20:42 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:20:42 --> Utf8 Class Initialized
INFO - 2021-03-26 01:20:42 --> URI Class Initialized
INFO - 2021-03-26 01:20:42 --> Router Class Initialized
INFO - 2021-03-26 01:20:42 --> Output Class Initialized
INFO - 2021-03-26 01:20:42 --> Security Class Initialized
DEBUG - 2021-03-26 01:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:20:42 --> Input Class Initialized
INFO - 2021-03-26 01:20:42 --> Language Class Initialized
INFO - 2021-03-26 01:20:42 --> Loader Class Initialized
INFO - 2021-03-26 01:20:42 --> Helper loaded: url_helper
INFO - 2021-03-26 01:20:42 --> Helper loaded: form_helper
INFO - 2021-03-26 01:20:42 --> Helper loaded: common_helper
INFO - 2021-03-26 01:20:42 --> Helper loaded: util_helper
INFO - 2021-03-26 01:20:42 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:20:42 --> Form Validation Class Initialized
INFO - 2021-03-26 01:20:42 --> Controller Class Initialized
INFO - 2021-03-26 01:20:42 --> Model Class Initialized
INFO - 2021-03-26 01:20:42 --> Model Class Initialized
INFO - 2021-03-26 01:20:42 --> Model Class Initialized
INFO - 2021-03-26 01:20:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:20:42 --> Final output sent to browser
DEBUG - 2021-03-26 01:20:42 --> Total execution time: 0.0466
INFO - 2021-03-26 01:23:47 --> Config Class Initialized
INFO - 2021-03-26 01:23:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:23:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:47 --> URI Class Initialized
INFO - 2021-03-26 01:23:47 --> Router Class Initialized
INFO - 2021-03-26 01:23:47 --> Output Class Initialized
INFO - 2021-03-26 01:23:47 --> Security Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:23:47 --> Input Class Initialized
INFO - 2021-03-26 01:23:47 --> Language Class Initialized
INFO - 2021-03-26 01:23:47 --> Loader Class Initialized
INFO - 2021-03-26 01:23:47 --> Helper loaded: url_helper
INFO - 2021-03-26 01:23:47 --> Helper loaded: form_helper
INFO - 2021-03-26 01:23:47 --> Helper loaded: common_helper
INFO - 2021-03-26 01:23:47 --> Helper loaded: util_helper
INFO - 2021-03-26 01:23:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:23:47 --> Form Validation Class Initialized
INFO - 2021-03-26 01:23:47 --> Controller Class Initialized
INFO - 2021-03-26 01:23:47 --> Model Class Initialized
INFO - 2021-03-26 01:23:47 --> Model Class Initialized
INFO - 2021-03-26 01:23:47 --> Model Class Initialized
INFO - 2021-03-26 01:23:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:23:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:23:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:23:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:23:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:23:47 --> Final output sent to browser
DEBUG - 2021-03-26 01:23:47 --> Total execution time: 0.0370
INFO - 2021-03-26 01:23:47 --> Config Class Initialized
INFO - 2021-03-26 01:23:47 --> Hooks Class Initialized
INFO - 2021-03-26 01:23:47 --> Config Class Initialized
INFO - 2021-03-26 01:23:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:23:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:47 --> URI Class Initialized
DEBUG - 2021-03-26 01:23:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:47 --> Router Class Initialized
INFO - 2021-03-26 01:23:47 --> URI Class Initialized
INFO - 2021-03-26 01:23:47 --> Output Class Initialized
INFO - 2021-03-26 01:23:47 --> Router Class Initialized
INFO - 2021-03-26 01:23:47 --> Output Class Initialized
INFO - 2021-03-26 01:23:47 --> Security Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:23:47 --> Input Class Initialized
INFO - 2021-03-26 01:23:47 --> Security Class Initialized
INFO - 2021-03-26 01:23:47 --> Language Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:23:47 --> Input Class Initialized
ERROR - 2021-03-26 01:23:47 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:23:47 --> Language Class Initialized
ERROR - 2021-03-26 01:23:47 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:23:47 --> Config Class Initialized
INFO - 2021-03-26 01:23:47 --> Hooks Class Initialized
INFO - 2021-03-26 01:23:47 --> Config Class Initialized
DEBUG - 2021-03-26 01:23:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:47 --> URI Class Initialized
INFO - 2021-03-26 01:23:47 --> Router Class Initialized
INFO - 2021-03-26 01:23:47 --> Output Class Initialized
INFO - 2021-03-26 01:23:47 --> Hooks Class Initialized
INFO - 2021-03-26 01:23:47 --> Security Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 01:23:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:47 --> Input Class Initialized
INFO - 2021-03-26 01:23:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:47 --> Language Class Initialized
INFO - 2021-03-26 01:23:47 --> URI Class Initialized
ERROR - 2021-03-26 01:23:47 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:23:47 --> Router Class Initialized
INFO - 2021-03-26 01:23:47 --> Output Class Initialized
INFO - 2021-03-26 01:23:47 --> Security Class Initialized
DEBUG - 2021-03-26 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:23:47 --> Input Class Initialized
INFO - 2021-03-26 01:23:47 --> Language Class Initialized
ERROR - 2021-03-26 01:23:47 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:23:52 --> Config Class Initialized
INFO - 2021-03-26 01:23:52 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:23:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:23:52 --> Utf8 Class Initialized
INFO - 2021-03-26 01:23:52 --> URI Class Initialized
INFO - 2021-03-26 01:23:52 --> Router Class Initialized
INFO - 2021-03-26 01:23:52 --> Output Class Initialized
INFO - 2021-03-26 01:23:52 --> Security Class Initialized
DEBUG - 2021-03-26 01:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:23:52 --> Input Class Initialized
INFO - 2021-03-26 01:23:52 --> Language Class Initialized
INFO - 2021-03-26 01:23:52 --> Loader Class Initialized
INFO - 2021-03-26 01:23:52 --> Helper loaded: url_helper
INFO - 2021-03-26 01:23:52 --> Helper loaded: form_helper
INFO - 2021-03-26 01:23:52 --> Helper loaded: common_helper
INFO - 2021-03-26 01:23:52 --> Helper loaded: util_helper
INFO - 2021-03-26 01:23:52 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:23:52 --> Form Validation Class Initialized
INFO - 2021-03-26 01:23:52 --> Controller Class Initialized
INFO - 2021-03-26 01:23:52 --> Model Class Initialized
INFO - 2021-03-26 01:23:52 --> Model Class Initialized
INFO - 2021-03-26 01:23:52 --> Model Class Initialized
INFO - 2021-03-26 01:23:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:23:52 --> Final output sent to browser
DEBUG - 2021-03-26 01:23:52 --> Total execution time: 0.0362
INFO - 2021-03-26 01:25:06 --> Config Class Initialized
INFO - 2021-03-26 01:25:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:25:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:06 --> Utf8 Class Initialized
INFO - 2021-03-26 01:25:06 --> URI Class Initialized
INFO - 2021-03-26 01:25:06 --> Router Class Initialized
INFO - 2021-03-26 01:25:06 --> Output Class Initialized
INFO - 2021-03-26 01:25:06 --> Security Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:06 --> Input Class Initialized
INFO - 2021-03-26 01:25:06 --> Language Class Initialized
INFO - 2021-03-26 01:25:06 --> Loader Class Initialized
INFO - 2021-03-26 01:25:06 --> Helper loaded: url_helper
INFO - 2021-03-26 01:25:06 --> Helper loaded: form_helper
INFO - 2021-03-26 01:25:06 --> Helper loaded: common_helper
INFO - 2021-03-26 01:25:06 --> Helper loaded: util_helper
INFO - 2021-03-26 01:25:06 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:25:06 --> Form Validation Class Initialized
INFO - 2021-03-26 01:25:06 --> Controller Class Initialized
INFO - 2021-03-26 01:25:06 --> Model Class Initialized
INFO - 2021-03-26 01:25:06 --> Model Class Initialized
INFO - 2021-03-26 01:25:06 --> Model Class Initialized
INFO - 2021-03-26 01:25:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:25:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:25:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:25:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:25:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:25:06 --> Final output sent to browser
DEBUG - 2021-03-26 01:25:06 --> Total execution time: 0.0367
INFO - 2021-03-26 01:25:06 --> Config Class Initialized
INFO - 2021-03-26 01:25:06 --> Hooks Class Initialized
INFO - 2021-03-26 01:25:06 --> Config Class Initialized
INFO - 2021-03-26 01:25:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:25:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:06 --> Utf8 Class Initialized
INFO - 2021-03-26 01:25:06 --> URI Class Initialized
DEBUG - 2021-03-26 01:25:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:06 --> Utf8 Class Initialized
INFO - 2021-03-26 01:25:06 --> Router Class Initialized
INFO - 2021-03-26 01:25:06 --> URI Class Initialized
INFO - 2021-03-26 01:25:06 --> Output Class Initialized
INFO - 2021-03-26 01:25:06 --> Router Class Initialized
INFO - 2021-03-26 01:25:06 --> Security Class Initialized
INFO - 2021-03-26 01:25:06 --> Output Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:06 --> Input Class Initialized
INFO - 2021-03-26 01:25:06 --> Security Class Initialized
INFO - 2021-03-26 01:25:06 --> Language Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:06 --> Input Class Initialized
ERROR - 2021-03-26 01:25:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:25:06 --> Language Class Initialized
ERROR - 2021-03-26 01:25:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:25:06 --> Config Class Initialized
INFO - 2021-03-26 01:25:06 --> Hooks Class Initialized
INFO - 2021-03-26 01:25:06 --> Config Class Initialized
INFO - 2021-03-26 01:25:06 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:25:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:06 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:25:06 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:06 --> Utf8 Class Initialized
INFO - 2021-03-26 01:25:06 --> URI Class Initialized
INFO - 2021-03-26 01:25:06 --> URI Class Initialized
INFO - 2021-03-26 01:25:06 --> Router Class Initialized
INFO - 2021-03-26 01:25:06 --> Router Class Initialized
INFO - 2021-03-26 01:25:06 --> Output Class Initialized
INFO - 2021-03-26 01:25:06 --> Output Class Initialized
INFO - 2021-03-26 01:25:06 --> Security Class Initialized
INFO - 2021-03-26 01:25:06 --> Security Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:06 --> Input Class Initialized
DEBUG - 2021-03-26 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:06 --> Language Class Initialized
INFO - 2021-03-26 01:25:06 --> Input Class Initialized
INFO - 2021-03-26 01:25:06 --> Language Class Initialized
ERROR - 2021-03-26 01:25:06 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:25:06 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:25:15 --> Config Class Initialized
INFO - 2021-03-26 01:25:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:25:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:25:15 --> Utf8 Class Initialized
INFO - 2021-03-26 01:25:15 --> URI Class Initialized
INFO - 2021-03-26 01:25:15 --> Router Class Initialized
INFO - 2021-03-26 01:25:15 --> Output Class Initialized
INFO - 2021-03-26 01:25:15 --> Security Class Initialized
DEBUG - 2021-03-26 01:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:25:15 --> Input Class Initialized
INFO - 2021-03-26 01:25:15 --> Language Class Initialized
INFO - 2021-03-26 01:25:15 --> Loader Class Initialized
INFO - 2021-03-26 01:25:15 --> Helper loaded: url_helper
INFO - 2021-03-26 01:25:15 --> Helper loaded: form_helper
INFO - 2021-03-26 01:25:15 --> Helper loaded: common_helper
INFO - 2021-03-26 01:25:15 --> Helper loaded: util_helper
INFO - 2021-03-26 01:25:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:25:15 --> Form Validation Class Initialized
INFO - 2021-03-26 01:25:15 --> Controller Class Initialized
INFO - 2021-03-26 01:25:15 --> Model Class Initialized
INFO - 2021-03-26 01:25:15 --> Model Class Initialized
INFO - 2021-03-26 01:25:15 --> Model Class Initialized
INFO - 2021-03-26 01:25:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:25:15 --> Final output sent to browser
DEBUG - 2021-03-26 01:25:15 --> Total execution time: 0.0388
INFO - 2021-03-26 01:27:25 --> Config Class Initialized
INFO - 2021-03-26 01:27:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:27:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:25 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:25 --> URI Class Initialized
INFO - 2021-03-26 01:27:25 --> Router Class Initialized
INFO - 2021-03-26 01:27:25 --> Output Class Initialized
INFO - 2021-03-26 01:27:25 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:25 --> Input Class Initialized
INFO - 2021-03-26 01:27:25 --> Language Class Initialized
INFO - 2021-03-26 01:27:25 --> Loader Class Initialized
INFO - 2021-03-26 01:27:25 --> Helper loaded: url_helper
INFO - 2021-03-26 01:27:25 --> Helper loaded: form_helper
INFO - 2021-03-26 01:27:25 --> Helper loaded: common_helper
INFO - 2021-03-26 01:27:25 --> Helper loaded: util_helper
INFO - 2021-03-26 01:27:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:27:25 --> Form Validation Class Initialized
INFO - 2021-03-26 01:27:25 --> Controller Class Initialized
INFO - 2021-03-26 01:27:25 --> Model Class Initialized
INFO - 2021-03-26 01:27:25 --> Model Class Initialized
INFO - 2021-03-26 01:27:25 --> Model Class Initialized
INFO - 2021-03-26 01:27:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:27:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:27:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:27:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:27:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:27:25 --> Final output sent to browser
DEBUG - 2021-03-26 01:27:25 --> Total execution time: 0.0385
INFO - 2021-03-26 01:27:25 --> Config Class Initialized
INFO - 2021-03-26 01:27:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:27:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:25 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:25 --> URI Class Initialized
INFO - 2021-03-26 01:27:25 --> Router Class Initialized
INFO - 2021-03-26 01:27:25 --> Config Class Initialized
INFO - 2021-03-26 01:27:25 --> Hooks Class Initialized
INFO - 2021-03-26 01:27:25 --> Output Class Initialized
DEBUG - 2021-03-26 01:27:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:25 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:25 --> URI Class Initialized
INFO - 2021-03-26 01:27:25 --> Router Class Initialized
INFO - 2021-03-26 01:27:25 --> Output Class Initialized
INFO - 2021-03-26 01:27:25 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:25 --> Input Class Initialized
INFO - 2021-03-26 01:27:25 --> Security Class Initialized
INFO - 2021-03-26 01:27:25 --> Language Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:25 --> Input Class Initialized
ERROR - 2021-03-26 01:27:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:27:25 --> Language Class Initialized
ERROR - 2021-03-26 01:27:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:27:25 --> Config Class Initialized
INFO - 2021-03-26 01:27:25 --> Hooks Class Initialized
INFO - 2021-03-26 01:27:25 --> Config Class Initialized
INFO - 2021-03-26 01:27:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:27:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:25 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:25 --> URI Class Initialized
INFO - 2021-03-26 01:27:25 --> Router Class Initialized
DEBUG - 2021-03-26 01:27:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:25 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:25 --> Output Class Initialized
INFO - 2021-03-26 01:27:25 --> URI Class Initialized
INFO - 2021-03-26 01:27:25 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:25 --> Input Class Initialized
INFO - 2021-03-26 01:27:25 --> Router Class Initialized
INFO - 2021-03-26 01:27:25 --> Language Class Initialized
INFO - 2021-03-26 01:27:25 --> Output Class Initialized
ERROR - 2021-03-26 01:27:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:27:25 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:25 --> Input Class Initialized
INFO - 2021-03-26 01:27:25 --> Language Class Initialized
ERROR - 2021-03-26 01:27:25 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:27:31 --> Config Class Initialized
INFO - 2021-03-26 01:27:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:27:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:31 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:31 --> URI Class Initialized
INFO - 2021-03-26 01:27:31 --> Router Class Initialized
INFO - 2021-03-26 01:27:31 --> Output Class Initialized
INFO - 2021-03-26 01:27:31 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:31 --> Input Class Initialized
INFO - 2021-03-26 01:27:31 --> Language Class Initialized
INFO - 2021-03-26 01:27:31 --> Loader Class Initialized
INFO - 2021-03-26 01:27:31 --> Helper loaded: url_helper
INFO - 2021-03-26 01:27:31 --> Helper loaded: form_helper
INFO - 2021-03-26 01:27:31 --> Helper loaded: common_helper
INFO - 2021-03-26 01:27:31 --> Helper loaded: util_helper
INFO - 2021-03-26 01:27:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:27:31 --> Form Validation Class Initialized
INFO - 2021-03-26 01:27:31 --> Controller Class Initialized
INFO - 2021-03-26 01:27:31 --> Model Class Initialized
INFO - 2021-03-26 01:27:31 --> Model Class Initialized
INFO - 2021-03-26 01:27:31 --> Model Class Initialized
INFO - 2021-03-26 01:27:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:27:31 --> Final output sent to browser
DEBUG - 2021-03-26 01:27:31 --> Total execution time: 0.0376
INFO - 2021-03-26 01:27:37 --> Config Class Initialized
INFO - 2021-03-26 01:27:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:27:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:27:37 --> Utf8 Class Initialized
INFO - 2021-03-26 01:27:37 --> URI Class Initialized
INFO - 2021-03-26 01:27:37 --> Router Class Initialized
INFO - 2021-03-26 01:27:38 --> Output Class Initialized
INFO - 2021-03-26 01:27:38 --> Security Class Initialized
DEBUG - 2021-03-26 01:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:27:38 --> Input Class Initialized
INFO - 2021-03-26 01:27:38 --> Language Class Initialized
ERROR - 2021-03-26 01:27:38 --> 404 Page Not Found: administrator/Permission/get_assigned_menu
INFO - 2021-03-26 01:28:38 --> Config Class Initialized
INFO - 2021-03-26 01:28:38 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:28:38 --> Utf8 Class Initialized
INFO - 2021-03-26 01:28:38 --> URI Class Initialized
INFO - 2021-03-26 01:28:38 --> Router Class Initialized
INFO - 2021-03-26 01:28:38 --> Output Class Initialized
INFO - 2021-03-26 01:28:38 --> Security Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:28:38 --> Input Class Initialized
INFO - 2021-03-26 01:28:38 --> Language Class Initialized
INFO - 2021-03-26 01:28:38 --> Loader Class Initialized
INFO - 2021-03-26 01:28:38 --> Helper loaded: url_helper
INFO - 2021-03-26 01:28:38 --> Helper loaded: form_helper
INFO - 2021-03-26 01:28:38 --> Helper loaded: common_helper
INFO - 2021-03-26 01:28:38 --> Helper loaded: util_helper
INFO - 2021-03-26 01:28:38 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:28:38 --> Form Validation Class Initialized
INFO - 2021-03-26 01:28:38 --> Controller Class Initialized
INFO - 2021-03-26 01:28:38 --> Model Class Initialized
INFO - 2021-03-26 01:28:38 --> Model Class Initialized
INFO - 2021-03-26 01:28:38 --> Model Class Initialized
INFO - 2021-03-26 01:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:28:38 --> Final output sent to browser
DEBUG - 2021-03-26 01:28:38 --> Total execution time: 0.0493
INFO - 2021-03-26 01:28:38 --> Config Class Initialized
INFO - 2021-03-26 01:28:38 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:28:38 --> Utf8 Class Initialized
INFO - 2021-03-26 01:28:38 --> URI Class Initialized
INFO - 2021-03-26 01:28:38 --> Router Class Initialized
INFO - 2021-03-26 01:28:38 --> Output Class Initialized
INFO - 2021-03-26 01:28:38 --> Security Class Initialized
INFO - 2021-03-26 01:28:38 --> Config Class Initialized
INFO - 2021-03-26 01:28:38 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:28:38 --> Input Class Initialized
INFO - 2021-03-26 01:28:38 --> Language Class Initialized
DEBUG - 2021-03-26 01:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:28:38 --> Utf8 Class Initialized
ERROR - 2021-03-26 01:28:38 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:28:38 --> URI Class Initialized
INFO - 2021-03-26 01:28:38 --> Router Class Initialized
INFO - 2021-03-26 01:28:38 --> Output Class Initialized
INFO - 2021-03-26 01:28:38 --> Security Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:28:38 --> Input Class Initialized
INFO - 2021-03-26 01:28:38 --> Language Class Initialized
ERROR - 2021-03-26 01:28:38 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:28:38 --> Config Class Initialized
INFO - 2021-03-26 01:28:38 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:28:38 --> Utf8 Class Initialized
INFO - 2021-03-26 01:28:38 --> URI Class Initialized
INFO - 2021-03-26 01:28:38 --> Router Class Initialized
INFO - 2021-03-26 01:28:38 --> Output Class Initialized
INFO - 2021-03-26 01:28:38 --> Security Class Initialized
INFO - 2021-03-26 01:28:38 --> Config Class Initialized
INFO - 2021-03-26 01:28:38 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:28:38 --> Input Class Initialized
INFO - 2021-03-26 01:28:38 --> Language Class Initialized
DEBUG - 2021-03-26 01:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:28:38 --> Utf8 Class Initialized
ERROR - 2021-03-26 01:28:38 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:28:38 --> URI Class Initialized
INFO - 2021-03-26 01:28:38 --> Router Class Initialized
INFO - 2021-03-26 01:28:38 --> Output Class Initialized
INFO - 2021-03-26 01:28:38 --> Security Class Initialized
DEBUG - 2021-03-26 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:28:38 --> Input Class Initialized
INFO - 2021-03-26 01:28:38 --> Language Class Initialized
ERROR - 2021-03-26 01:28:38 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:29:45 --> Config Class Initialized
INFO - 2021-03-26 01:29:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:29:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:29:45 --> URI Class Initialized
INFO - 2021-03-26 01:29:45 --> Router Class Initialized
INFO - 2021-03-26 01:29:45 --> Output Class Initialized
INFO - 2021-03-26 01:29:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:45 --> Input Class Initialized
INFO - 2021-03-26 01:29:45 --> Language Class Initialized
INFO - 2021-03-26 01:29:45 --> Loader Class Initialized
INFO - 2021-03-26 01:29:45 --> Helper loaded: url_helper
INFO - 2021-03-26 01:29:45 --> Helper loaded: form_helper
INFO - 2021-03-26 01:29:45 --> Helper loaded: common_helper
INFO - 2021-03-26 01:29:45 --> Helper loaded: util_helper
INFO - 2021-03-26 01:29:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:29:45 --> Form Validation Class Initialized
INFO - 2021-03-26 01:29:45 --> Controller Class Initialized
INFO - 2021-03-26 01:29:45 --> Model Class Initialized
INFO - 2021-03-26 01:29:45 --> Model Class Initialized
INFO - 2021-03-26 01:29:45 --> Model Class Initialized
INFO - 2021-03-26 01:29:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:29:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:29:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:29:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:29:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:29:45 --> Final output sent to browser
DEBUG - 2021-03-26 01:29:45 --> Total execution time: 0.0608
INFO - 2021-03-26 01:29:45 --> Config Class Initialized
INFO - 2021-03-26 01:29:45 --> Hooks Class Initialized
INFO - 2021-03-26 01:29:45 --> Config Class Initialized
INFO - 2021-03-26 01:29:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:29:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:29:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:29:45 --> URI Class Initialized
INFO - 2021-03-26 01:29:45 --> URI Class Initialized
INFO - 2021-03-26 01:29:45 --> Router Class Initialized
INFO - 2021-03-26 01:29:45 --> Router Class Initialized
INFO - 2021-03-26 01:29:45 --> Output Class Initialized
INFO - 2021-03-26 01:29:45 --> Output Class Initialized
INFO - 2021-03-26 01:29:45 --> Security Class Initialized
INFO - 2021-03-26 01:29:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:45 --> Input Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:45 --> Language Class Initialized
INFO - 2021-03-26 01:29:45 --> Input Class Initialized
INFO - 2021-03-26 01:29:45 --> Language Class Initialized
ERROR - 2021-03-26 01:29:45 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:29:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:29:45 --> Config Class Initialized
INFO - 2021-03-26 01:29:45 --> Config Class Initialized
INFO - 2021-03-26 01:29:45 --> Hooks Class Initialized
INFO - 2021-03-26 01:29:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:29:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:29:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:45 --> URI Class Initialized
INFO - 2021-03-26 01:29:45 --> Utf8 Class Initialized
INFO - 2021-03-26 01:29:45 --> Router Class Initialized
INFO - 2021-03-26 01:29:45 --> URI Class Initialized
INFO - 2021-03-26 01:29:45 --> Output Class Initialized
INFO - 2021-03-26 01:29:45 --> Router Class Initialized
INFO - 2021-03-26 01:29:45 --> Security Class Initialized
INFO - 2021-03-26 01:29:45 --> Output Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:45 --> Input Class Initialized
INFO - 2021-03-26 01:29:45 --> Language Class Initialized
INFO - 2021-03-26 01:29:45 --> Security Class Initialized
DEBUG - 2021-03-26 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:45 --> Input Class Initialized
ERROR - 2021-03-26 01:29:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:29:45 --> Language Class Initialized
ERROR - 2021-03-26 01:29:45 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:29:49 --> Config Class Initialized
INFO - 2021-03-26 01:29:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:29:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:29:49 --> Utf8 Class Initialized
INFO - 2021-03-26 01:29:49 --> URI Class Initialized
INFO - 2021-03-26 01:29:49 --> Router Class Initialized
INFO - 2021-03-26 01:29:49 --> Output Class Initialized
INFO - 2021-03-26 01:29:49 --> Security Class Initialized
DEBUG - 2021-03-26 01:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:29:49 --> Input Class Initialized
INFO - 2021-03-26 01:29:49 --> Language Class Initialized
INFO - 2021-03-26 01:29:49 --> Loader Class Initialized
INFO - 2021-03-26 01:29:49 --> Helper loaded: url_helper
INFO - 2021-03-26 01:29:49 --> Helper loaded: form_helper
INFO - 2021-03-26 01:29:49 --> Helper loaded: common_helper
INFO - 2021-03-26 01:29:49 --> Helper loaded: util_helper
INFO - 2021-03-26 01:29:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:29:49 --> Form Validation Class Initialized
INFO - 2021-03-26 01:29:49 --> Controller Class Initialized
INFO - 2021-03-26 01:29:49 --> Model Class Initialized
INFO - 2021-03-26 01:29:49 --> Model Class Initialized
INFO - 2021-03-26 01:29:49 --> Model Class Initialized
INFO - 2021-03-26 01:29:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:29:49 --> Final output sent to browser
DEBUG - 2021-03-26 01:29:49 --> Total execution time: 0.0380
INFO - 2021-03-26 01:30:08 --> Config Class Initialized
INFO - 2021-03-26 01:30:08 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:30:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:30:08 --> Utf8 Class Initialized
INFO - 2021-03-26 01:30:08 --> URI Class Initialized
INFO - 2021-03-26 01:30:08 --> Router Class Initialized
INFO - 2021-03-26 01:30:08 --> Output Class Initialized
INFO - 2021-03-26 01:30:08 --> Security Class Initialized
DEBUG - 2021-03-26 01:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:30:08 --> Input Class Initialized
INFO - 2021-03-26 01:30:08 --> Language Class Initialized
INFO - 2021-03-26 01:30:08 --> Loader Class Initialized
INFO - 2021-03-26 01:30:08 --> Helper loaded: url_helper
INFO - 2021-03-26 01:30:08 --> Helper loaded: form_helper
INFO - 2021-03-26 01:30:08 --> Helper loaded: common_helper
INFO - 2021-03-26 01:30:08 --> Helper loaded: util_helper
INFO - 2021-03-26 01:30:08 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:30:08 --> Form Validation Class Initialized
INFO - 2021-03-26 01:30:08 --> Controller Class Initialized
INFO - 2021-03-26 01:30:08 --> Model Class Initialized
INFO - 2021-03-26 01:30:08 --> Model Class Initialized
INFO - 2021-03-26 01:30:08 --> Model Class Initialized
INFO - 2021-03-26 01:30:08 --> Final output sent to browser
DEBUG - 2021-03-26 01:30:08 --> Total execution time: 0.0426
INFO - 2021-03-26 01:31:18 --> Config Class Initialized
INFO - 2021-03-26 01:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:18 --> Utf8 Class Initialized
INFO - 2021-03-26 01:31:18 --> URI Class Initialized
INFO - 2021-03-26 01:31:18 --> Router Class Initialized
INFO - 2021-03-26 01:31:18 --> Output Class Initialized
INFO - 2021-03-26 01:31:18 --> Security Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:18 --> Input Class Initialized
INFO - 2021-03-26 01:31:18 --> Language Class Initialized
INFO - 2021-03-26 01:31:18 --> Loader Class Initialized
INFO - 2021-03-26 01:31:18 --> Helper loaded: url_helper
INFO - 2021-03-26 01:31:18 --> Helper loaded: form_helper
INFO - 2021-03-26 01:31:18 --> Helper loaded: common_helper
INFO - 2021-03-26 01:31:18 --> Helper loaded: util_helper
INFO - 2021-03-26 01:31:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:31:18 --> Form Validation Class Initialized
INFO - 2021-03-26 01:31:18 --> Controller Class Initialized
INFO - 2021-03-26 01:31:18 --> Model Class Initialized
INFO - 2021-03-26 01:31:18 --> Model Class Initialized
INFO - 2021-03-26 01:31:18 --> Model Class Initialized
INFO - 2021-03-26 01:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:31:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:31:18 --> Final output sent to browser
DEBUG - 2021-03-26 01:31:18 --> Total execution time: 0.0398
INFO - 2021-03-26 01:31:18 --> Config Class Initialized
INFO - 2021-03-26 01:31:18 --> Hooks Class Initialized
INFO - 2021-03-26 01:31:18 --> Config Class Initialized
INFO - 2021-03-26 01:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:18 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:18 --> Utf8 Class Initialized
INFO - 2021-03-26 01:31:18 --> URI Class Initialized
INFO - 2021-03-26 01:31:18 --> URI Class Initialized
INFO - 2021-03-26 01:31:18 --> Router Class Initialized
INFO - 2021-03-26 01:31:18 --> Router Class Initialized
INFO - 2021-03-26 01:31:18 --> Output Class Initialized
INFO - 2021-03-26 01:31:18 --> Output Class Initialized
INFO - 2021-03-26 01:31:18 --> Security Class Initialized
INFO - 2021-03-26 01:31:18 --> Security Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:18 --> Input Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:18 --> Input Class Initialized
INFO - 2021-03-26 01:31:18 --> Language Class Initialized
INFO - 2021-03-26 01:31:18 --> Language Class Initialized
ERROR - 2021-03-26 01:31:18 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:31:18 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:31:18 --> Config Class Initialized
INFO - 2021-03-26 01:31:18 --> Hooks Class Initialized
INFO - 2021-03-26 01:31:18 --> Config Class Initialized
INFO - 2021-03-26 01:31:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:18 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:31:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:18 --> URI Class Initialized
INFO - 2021-03-26 01:31:18 --> Utf8 Class Initialized
INFO - 2021-03-26 01:31:18 --> URI Class Initialized
INFO - 2021-03-26 01:31:18 --> Router Class Initialized
INFO - 2021-03-26 01:31:18 --> Router Class Initialized
INFO - 2021-03-26 01:31:18 --> Output Class Initialized
INFO - 2021-03-26 01:31:18 --> Security Class Initialized
INFO - 2021-03-26 01:31:18 --> Output Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:18 --> Input Class Initialized
INFO - 2021-03-26 01:31:18 --> Security Class Initialized
INFO - 2021-03-26 01:31:18 --> Language Class Initialized
DEBUG - 2021-03-26 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:18 --> Input Class Initialized
INFO - 2021-03-26 01:31:18 --> Language Class Initialized
ERROR - 2021-03-26 01:31:18 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:31:18 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:31:41 --> Config Class Initialized
INFO - 2021-03-26 01:31:41 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:31:41 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:41 --> Utf8 Class Initialized
INFO - 2021-03-26 01:31:41 --> URI Class Initialized
INFO - 2021-03-26 01:31:41 --> Router Class Initialized
INFO - 2021-03-26 01:31:41 --> Output Class Initialized
INFO - 2021-03-26 01:31:41 --> Security Class Initialized
DEBUG - 2021-03-26 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:41 --> Input Class Initialized
INFO - 2021-03-26 01:31:41 --> Language Class Initialized
INFO - 2021-03-26 01:31:41 --> Loader Class Initialized
INFO - 2021-03-26 01:31:41 --> Helper loaded: url_helper
INFO - 2021-03-26 01:31:41 --> Helper loaded: form_helper
INFO - 2021-03-26 01:31:41 --> Helper loaded: common_helper
INFO - 2021-03-26 01:31:41 --> Helper loaded: util_helper
INFO - 2021-03-26 01:31:41 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:31:41 --> Form Validation Class Initialized
INFO - 2021-03-26 01:31:41 --> Controller Class Initialized
INFO - 2021-03-26 01:31:41 --> Model Class Initialized
INFO - 2021-03-26 01:31:41 --> Model Class Initialized
INFO - 2021-03-26 01:31:41 --> Model Class Initialized
INFO - 2021-03-26 01:31:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:31:41 --> Final output sent to browser
DEBUG - 2021-03-26 01:31:41 --> Total execution time: 0.0428
INFO - 2021-03-26 01:31:47 --> Config Class Initialized
INFO - 2021-03-26 01:31:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:31:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:31:47 --> Utf8 Class Initialized
INFO - 2021-03-26 01:31:47 --> URI Class Initialized
INFO - 2021-03-26 01:31:47 --> Router Class Initialized
INFO - 2021-03-26 01:31:47 --> Output Class Initialized
INFO - 2021-03-26 01:31:47 --> Security Class Initialized
DEBUG - 2021-03-26 01:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:31:47 --> Input Class Initialized
INFO - 2021-03-26 01:31:47 --> Language Class Initialized
INFO - 2021-03-26 01:31:47 --> Loader Class Initialized
INFO - 2021-03-26 01:31:47 --> Helper loaded: url_helper
INFO - 2021-03-26 01:31:47 --> Helper loaded: form_helper
INFO - 2021-03-26 01:31:47 --> Helper loaded: common_helper
INFO - 2021-03-26 01:31:47 --> Helper loaded: util_helper
INFO - 2021-03-26 01:31:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:31:47 --> Form Validation Class Initialized
INFO - 2021-03-26 01:31:47 --> Controller Class Initialized
INFO - 2021-03-26 01:31:47 --> Model Class Initialized
INFO - 2021-03-26 01:31:47 --> Model Class Initialized
INFO - 2021-03-26 01:31:47 --> Model Class Initialized
INFO - 2021-03-26 01:31:47 --> Final output sent to browser
DEBUG - 2021-03-26 01:31:47 --> Total execution time: 0.0501
INFO - 2021-03-26 01:32:16 --> Config Class Initialized
INFO - 2021-03-26 01:32:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:32:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:16 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:16 --> URI Class Initialized
INFO - 2021-03-26 01:32:16 --> Router Class Initialized
INFO - 2021-03-26 01:32:16 --> Output Class Initialized
INFO - 2021-03-26 01:32:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:16 --> Input Class Initialized
INFO - 2021-03-26 01:32:16 --> Language Class Initialized
INFO - 2021-03-26 01:32:16 --> Loader Class Initialized
INFO - 2021-03-26 01:32:16 --> Helper loaded: url_helper
INFO - 2021-03-26 01:32:16 --> Helper loaded: form_helper
INFO - 2021-03-26 01:32:16 --> Helper loaded: common_helper
INFO - 2021-03-26 01:32:16 --> Helper loaded: util_helper
INFO - 2021-03-26 01:32:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:32:16 --> Form Validation Class Initialized
INFO - 2021-03-26 01:32:16 --> Controller Class Initialized
INFO - 2021-03-26 01:32:16 --> Model Class Initialized
INFO - 2021-03-26 01:32:16 --> Model Class Initialized
INFO - 2021-03-26 01:32:16 --> Model Class Initialized
INFO - 2021-03-26 01:32:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:32:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:32:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:32:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:32:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:32:16 --> Final output sent to browser
DEBUG - 2021-03-26 01:32:16 --> Total execution time: 0.0424
INFO - 2021-03-26 01:32:16 --> Config Class Initialized
INFO - 2021-03-26 01:32:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:32:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:16 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:16 --> URI Class Initialized
INFO - 2021-03-26 01:32:16 --> Router Class Initialized
INFO - 2021-03-26 01:32:16 --> Config Class Initialized
INFO - 2021-03-26 01:32:16 --> Output Class Initialized
INFO - 2021-03-26 01:32:16 --> Hooks Class Initialized
INFO - 2021-03-26 01:32:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:16 --> Utf8 Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:16 --> Input Class Initialized
INFO - 2021-03-26 01:32:16 --> URI Class Initialized
INFO - 2021-03-26 01:32:16 --> Language Class Initialized
INFO - 2021-03-26 01:32:16 --> Router Class Initialized
ERROR - 2021-03-26 01:32:16 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:32:16 --> Output Class Initialized
INFO - 2021-03-26 01:32:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:16 --> Input Class Initialized
INFO - 2021-03-26 01:32:16 --> Language Class Initialized
ERROR - 2021-03-26 01:32:16 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:32:16 --> Config Class Initialized
INFO - 2021-03-26 01:32:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:32:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:16 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:16 --> URI Class Initialized
INFO - 2021-03-26 01:32:16 --> Router Class Initialized
INFO - 2021-03-26 01:32:16 --> Output Class Initialized
INFO - 2021-03-26 01:32:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:16 --> Input Class Initialized
INFO - 2021-03-26 01:32:16 --> Language Class Initialized
INFO - 2021-03-26 01:32:16 --> Config Class Initialized
INFO - 2021-03-26 01:32:16 --> Hooks Class Initialized
ERROR - 2021-03-26 01:32:16 --> 404 Page Not Found: administrator/Permission/dist
DEBUG - 2021-03-26 01:32:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:16 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:16 --> URI Class Initialized
INFO - 2021-03-26 01:32:16 --> Router Class Initialized
INFO - 2021-03-26 01:32:16 --> Output Class Initialized
INFO - 2021-03-26 01:32:16 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:16 --> Input Class Initialized
INFO - 2021-03-26 01:32:16 --> Language Class Initialized
ERROR - 2021-03-26 01:32:16 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:32:22 --> Config Class Initialized
INFO - 2021-03-26 01:32:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:32:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:22 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:22 --> URI Class Initialized
INFO - 2021-03-26 01:32:22 --> Router Class Initialized
INFO - 2021-03-26 01:32:22 --> Output Class Initialized
INFO - 2021-03-26 01:32:22 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:22 --> Input Class Initialized
INFO - 2021-03-26 01:32:22 --> Language Class Initialized
INFO - 2021-03-26 01:32:22 --> Loader Class Initialized
INFO - 2021-03-26 01:32:22 --> Helper loaded: url_helper
INFO - 2021-03-26 01:32:22 --> Helper loaded: form_helper
INFO - 2021-03-26 01:32:22 --> Helper loaded: common_helper
INFO - 2021-03-26 01:32:22 --> Helper loaded: util_helper
INFO - 2021-03-26 01:32:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:32:22 --> Form Validation Class Initialized
INFO - 2021-03-26 01:32:22 --> Controller Class Initialized
INFO - 2021-03-26 01:32:22 --> Model Class Initialized
INFO - 2021-03-26 01:32:22 --> Model Class Initialized
INFO - 2021-03-26 01:32:22 --> Model Class Initialized
INFO - 2021-03-26 01:32:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:32:22 --> Final output sent to browser
DEBUG - 2021-03-26 01:32:22 --> Total execution time: 0.0407
INFO - 2021-03-26 01:32:36 --> Config Class Initialized
INFO - 2021-03-26 01:32:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:32:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:32:36 --> Utf8 Class Initialized
INFO - 2021-03-26 01:32:36 --> URI Class Initialized
INFO - 2021-03-26 01:32:36 --> Router Class Initialized
INFO - 2021-03-26 01:32:36 --> Output Class Initialized
INFO - 2021-03-26 01:32:36 --> Security Class Initialized
DEBUG - 2021-03-26 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:32:36 --> Input Class Initialized
INFO - 2021-03-26 01:32:36 --> Language Class Initialized
INFO - 2021-03-26 01:32:36 --> Loader Class Initialized
INFO - 2021-03-26 01:32:36 --> Helper loaded: url_helper
INFO - 2021-03-26 01:32:36 --> Helper loaded: form_helper
INFO - 2021-03-26 01:32:36 --> Helper loaded: common_helper
INFO - 2021-03-26 01:32:36 --> Helper loaded: util_helper
INFO - 2021-03-26 01:32:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:32:36 --> Form Validation Class Initialized
INFO - 2021-03-26 01:32:36 --> Controller Class Initialized
INFO - 2021-03-26 01:32:36 --> Model Class Initialized
INFO - 2021-03-26 01:32:36 --> Model Class Initialized
INFO - 2021-03-26 01:32:36 --> Model Class Initialized
INFO - 2021-03-26 01:32:36 --> Final output sent to browser
DEBUG - 2021-03-26 01:32:36 --> Total execution time: 0.0491
INFO - 2021-03-26 01:33:14 --> Config Class Initialized
INFO - 2021-03-26 01:33:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:14 --> URI Class Initialized
INFO - 2021-03-26 01:33:14 --> Router Class Initialized
INFO - 2021-03-26 01:33:14 --> Output Class Initialized
INFO - 2021-03-26 01:33:14 --> Security Class Initialized
DEBUG - 2021-03-26 01:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:14 --> Input Class Initialized
INFO - 2021-03-26 01:33:14 --> Language Class Initialized
INFO - 2021-03-26 01:33:14 --> Loader Class Initialized
INFO - 2021-03-26 01:33:14 --> Helper loaded: url_helper
INFO - 2021-03-26 01:33:14 --> Helper loaded: form_helper
INFO - 2021-03-26 01:33:14 --> Helper loaded: common_helper
INFO - 2021-03-26 01:33:14 --> Helper loaded: util_helper
INFO - 2021-03-26 01:33:14 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:33:14 --> Form Validation Class Initialized
INFO - 2021-03-26 01:33:14 --> Controller Class Initialized
INFO - 2021-03-26 01:33:14 --> Model Class Initialized
INFO - 2021-03-26 01:33:14 --> Model Class Initialized
INFO - 2021-03-26 01:33:14 --> Model Class Initialized
INFO - 2021-03-26 01:33:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 01:33:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 01:33:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 01:33:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 01:33:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 01:33:14 --> Final output sent to browser
DEBUG - 2021-03-26 01:33:14 --> Total execution time: 0.0407
INFO - 2021-03-26 01:33:14 --> Config Class Initialized
INFO - 2021-03-26 01:33:14 --> Config Class Initialized
INFO - 2021-03-26 01:33:14 --> Hooks Class Initialized
INFO - 2021-03-26 01:33:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 01:33:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:14 --> URI Class Initialized
INFO - 2021-03-26 01:33:14 --> URI Class Initialized
INFO - 2021-03-26 01:33:14 --> Router Class Initialized
INFO - 2021-03-26 01:33:14 --> Router Class Initialized
INFO - 2021-03-26 01:33:14 --> Output Class Initialized
INFO - 2021-03-26 01:33:14 --> Output Class Initialized
INFO - 2021-03-26 01:33:14 --> Security Class Initialized
INFO - 2021-03-26 01:33:14 --> Security Class Initialized
DEBUG - 2021-03-26 01:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 01:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:14 --> Input Class Initialized
INFO - 2021-03-26 01:33:14 --> Input Class Initialized
INFO - 2021-03-26 01:33:14 --> Language Class Initialized
INFO - 2021-03-26 01:33:14 --> Language Class Initialized
ERROR - 2021-03-26 01:33:14 --> 404 Page Not Found: administrator/Permission/dist
ERROR - 2021-03-26 01:33:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:33:14 --> Config Class Initialized
INFO - 2021-03-26 01:33:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:14 --> URI Class Initialized
INFO - 2021-03-26 01:33:14 --> Router Class Initialized
INFO - 2021-03-26 01:33:14 --> Output Class Initialized
INFO - 2021-03-26 01:33:14 --> Security Class Initialized
INFO - 2021-03-26 01:33:14 --> Config Class Initialized
INFO - 2021-03-26 01:33:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:14 --> Input Class Initialized
INFO - 2021-03-26 01:33:14 --> Language Class Initialized
DEBUG - 2021-03-26 01:33:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:14 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:14 --> URI Class Initialized
ERROR - 2021-03-26 01:33:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:33:14 --> Router Class Initialized
INFO - 2021-03-26 01:33:14 --> Output Class Initialized
INFO - 2021-03-26 01:33:14 --> Security Class Initialized
DEBUG - 2021-03-26 01:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:14 --> Input Class Initialized
INFO - 2021-03-26 01:33:14 --> Language Class Initialized
ERROR - 2021-03-26 01:33:14 --> 404 Page Not Found: administrator/Permission/dist
INFO - 2021-03-26 01:33:18 --> Config Class Initialized
INFO - 2021-03-26 01:33:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:18 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:18 --> URI Class Initialized
INFO - 2021-03-26 01:33:18 --> Router Class Initialized
INFO - 2021-03-26 01:33:18 --> Output Class Initialized
INFO - 2021-03-26 01:33:18 --> Security Class Initialized
DEBUG - 2021-03-26 01:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:18 --> Input Class Initialized
INFO - 2021-03-26 01:33:18 --> Language Class Initialized
INFO - 2021-03-26 01:33:18 --> Loader Class Initialized
INFO - 2021-03-26 01:33:18 --> Helper loaded: url_helper
INFO - 2021-03-26 01:33:18 --> Helper loaded: form_helper
INFO - 2021-03-26 01:33:18 --> Helper loaded: common_helper
INFO - 2021-03-26 01:33:18 --> Helper loaded: util_helper
INFO - 2021-03-26 01:33:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:33:18 --> Form Validation Class Initialized
INFO - 2021-03-26 01:33:18 --> Controller Class Initialized
INFO - 2021-03-26 01:33:18 --> Model Class Initialized
INFO - 2021-03-26 01:33:18 --> Model Class Initialized
INFO - 2021-03-26 01:33:18 --> Model Class Initialized
INFO - 2021-03-26 01:33:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 01:33:18 --> Final output sent to browser
DEBUG - 2021-03-26 01:33:18 --> Total execution time: 0.0405
INFO - 2021-03-26 01:33:23 --> Config Class Initialized
INFO - 2021-03-26 01:33:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:33:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:33:23 --> Utf8 Class Initialized
INFO - 2021-03-26 01:33:23 --> URI Class Initialized
INFO - 2021-03-26 01:33:23 --> Router Class Initialized
INFO - 2021-03-26 01:33:23 --> Output Class Initialized
INFO - 2021-03-26 01:33:23 --> Security Class Initialized
DEBUG - 2021-03-26 01:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:33:23 --> Input Class Initialized
INFO - 2021-03-26 01:33:23 --> Language Class Initialized
INFO - 2021-03-26 01:33:23 --> Loader Class Initialized
INFO - 2021-03-26 01:33:23 --> Helper loaded: url_helper
INFO - 2021-03-26 01:33:23 --> Helper loaded: form_helper
INFO - 2021-03-26 01:33:23 --> Helper loaded: common_helper
INFO - 2021-03-26 01:33:23 --> Helper loaded: util_helper
INFO - 2021-03-26 01:33:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:33:23 --> Form Validation Class Initialized
INFO - 2021-03-26 01:33:23 --> Controller Class Initialized
INFO - 2021-03-26 01:33:23 --> Model Class Initialized
INFO - 2021-03-26 01:33:23 --> Model Class Initialized
INFO - 2021-03-26 01:33:23 --> Model Class Initialized
INFO - 2021-03-26 01:33:23 --> Final output sent to browser
DEBUG - 2021-03-26 01:33:23 --> Total execution time: 0.0375
INFO - 2021-03-26 01:38:50 --> Config Class Initialized
INFO - 2021-03-26 01:38:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:38:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:38:50 --> Utf8 Class Initialized
INFO - 2021-03-26 01:38:50 --> URI Class Initialized
INFO - 2021-03-26 01:38:50 --> Router Class Initialized
INFO - 2021-03-26 01:38:50 --> Output Class Initialized
INFO - 2021-03-26 01:38:50 --> Security Class Initialized
DEBUG - 2021-03-26 01:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:38:50 --> Input Class Initialized
INFO - 2021-03-26 01:38:50 --> Language Class Initialized
INFO - 2021-03-26 01:38:50 --> Loader Class Initialized
INFO - 2021-03-26 01:38:50 --> Helper loaded: url_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: form_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: common_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: util_helper
INFO - 2021-03-26 01:38:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:38:50 --> Form Validation Class Initialized
INFO - 2021-03-26 01:38:50 --> Controller Class Initialized
INFO - 2021-03-26 01:38:50 --> Model Class Initialized
INFO - 2021-03-26 01:38:50 --> Config Class Initialized
INFO - 2021-03-26 01:38:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 01:38:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 01:38:50 --> Utf8 Class Initialized
INFO - 2021-03-26 01:38:50 --> URI Class Initialized
INFO - 2021-03-26 01:38:50 --> Router Class Initialized
INFO - 2021-03-26 01:38:50 --> Output Class Initialized
INFO - 2021-03-26 01:38:50 --> Security Class Initialized
DEBUG - 2021-03-26 01:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 01:38:50 --> Input Class Initialized
INFO - 2021-03-26 01:38:50 --> Language Class Initialized
INFO - 2021-03-26 01:38:50 --> Loader Class Initialized
INFO - 2021-03-26 01:38:50 --> Helper loaded: url_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: form_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: common_helper
INFO - 2021-03-26 01:38:50 --> Helper loaded: util_helper
INFO - 2021-03-26 01:38:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 01:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 01:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 01:38:50 --> Form Validation Class Initialized
INFO - 2021-03-26 01:38:50 --> Controller Class Initialized
INFO - 2021-03-26 01:38:50 --> Model Class Initialized
INFO - 2021-03-26 01:38:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-26 01:38:50 --> Final output sent to browser
DEBUG - 2021-03-26 01:38:50 --> Total execution time: 0.0386
INFO - 2021-03-26 20:33:32 --> Config Class Initialized
INFO - 2021-03-26 20:33:32 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:32 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:32 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:32 --> URI Class Initialized
INFO - 2021-03-26 20:33:32 --> Router Class Initialized
INFO - 2021-03-26 20:33:32 --> Output Class Initialized
INFO - 2021-03-26 20:33:32 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:32 --> Input Class Initialized
INFO - 2021-03-26 20:33:32 --> Language Class Initialized
INFO - 2021-03-26 20:33:32 --> Loader Class Initialized
INFO - 2021-03-26 20:33:32 --> Helper loaded: url_helper
INFO - 2021-03-26 20:33:32 --> Helper loaded: form_helper
INFO - 2021-03-26 20:33:32 --> Helper loaded: common_helper
INFO - 2021-03-26 20:33:32 --> Helper loaded: util_helper
INFO - 2021-03-26 20:33:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:33:32 --> Form Validation Class Initialized
INFO - 2021-03-26 20:33:32 --> Controller Class Initialized
INFO - 2021-03-26 20:33:32 --> Model Class Initialized
INFO - 2021-03-26 20:33:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-26 20:33:32 --> Final output sent to browser
DEBUG - 2021-03-26 20:33:32 --> Total execution time: 0.0468
INFO - 2021-03-26 20:33:43 --> Config Class Initialized
INFO - 2021-03-26 20:33:43 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:43 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:43 --> URI Class Initialized
INFO - 2021-03-26 20:33:43 --> Router Class Initialized
INFO - 2021-03-26 20:33:43 --> Output Class Initialized
INFO - 2021-03-26 20:33:43 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:43 --> Input Class Initialized
INFO - 2021-03-26 20:33:43 --> Language Class Initialized
INFO - 2021-03-26 20:33:43 --> Loader Class Initialized
INFO - 2021-03-26 20:33:43 --> Helper loaded: url_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: form_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: common_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: util_helper
INFO - 2021-03-26 20:33:43 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:33:43 --> Form Validation Class Initialized
INFO - 2021-03-26 20:33:43 --> Controller Class Initialized
INFO - 2021-03-26 20:33:43 --> Model Class Initialized
INFO - 2021-03-26 20:33:43 --> Config Class Initialized
INFO - 2021-03-26 20:33:43 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:43 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:43 --> URI Class Initialized
INFO - 2021-03-26 20:33:43 --> Router Class Initialized
INFO - 2021-03-26 20:33:43 --> Output Class Initialized
INFO - 2021-03-26 20:33:43 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:43 --> Input Class Initialized
INFO - 2021-03-26 20:33:43 --> Language Class Initialized
INFO - 2021-03-26 20:33:43 --> Loader Class Initialized
INFO - 2021-03-26 20:33:43 --> Helper loaded: url_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: form_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: common_helper
INFO - 2021-03-26 20:33:43 --> Helper loaded: util_helper
INFO - 2021-03-26 20:33:43 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:33:43 --> Form Validation Class Initialized
INFO - 2021-03-26 20:33:43 --> Controller Class Initialized
INFO - 2021-03-26 20:33:43 --> Model Class Initialized
INFO - 2021-03-26 20:33:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:33:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:33:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-26 20:33:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:33:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:33:43 --> Final output sent to browser
DEBUG - 2021-03-26 20:33:43 --> Total execution time: 0.0357
INFO - 2021-03-26 20:33:43 --> Config Class Initialized
INFO - 2021-03-26 20:33:43 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:43 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:43 --> Config Class Initialized
INFO - 2021-03-26 20:33:43 --> Hooks Class Initialized
INFO - 2021-03-26 20:33:43 --> URI Class Initialized
DEBUG - 2021-03-26 20:33:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:43 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:43 --> Router Class Initialized
INFO - 2021-03-26 20:33:43 --> URI Class Initialized
INFO - 2021-03-26 20:33:43 --> Output Class Initialized
INFO - 2021-03-26 20:33:43 --> Security Class Initialized
INFO - 2021-03-26 20:33:43 --> Config Class Initialized
INFO - 2021-03-26 20:33:43 --> Router Class Initialized
INFO - 2021-03-26 20:33:43 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:43 --> Input Class Initialized
INFO - 2021-03-26 20:33:43 --> Output Class Initialized
INFO - 2021-03-26 20:33:43 --> Language Class Initialized
DEBUG - 2021-03-26 20:33:43 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:43 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:43 --> Security Class Initialized
INFO - 2021-03-26 20:33:43 --> URI Class Initialized
ERROR - 2021-03-26 20:33:43 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-26 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:43 --> Input Class Initialized
INFO - 2021-03-26 20:33:43 --> Language Class Initialized
INFO - 2021-03-26 20:33:43 --> Router Class Initialized
ERROR - 2021-03-26 20:33:43 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-26 20:33:43 --> Output Class Initialized
INFO - 2021-03-26 20:33:43 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:43 --> Input Class Initialized
INFO - 2021-03-26 20:33:43 --> Language Class Initialized
ERROR - 2021-03-26 20:33:43 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-26 20:33:44 --> Config Class Initialized
INFO - 2021-03-26 20:33:44 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:44 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:44 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:44 --> URI Class Initialized
INFO - 2021-03-26 20:33:44 --> Router Class Initialized
INFO - 2021-03-26 20:33:44 --> Output Class Initialized
INFO - 2021-03-26 20:33:44 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:44 --> Input Class Initialized
INFO - 2021-03-26 20:33:44 --> Language Class Initialized
ERROR - 2021-03-26 20:33:44 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-26 20:33:49 --> Config Class Initialized
INFO - 2021-03-26 20:33:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:49 --> URI Class Initialized
INFO - 2021-03-26 20:33:49 --> Router Class Initialized
INFO - 2021-03-26 20:33:49 --> Output Class Initialized
INFO - 2021-03-26 20:33:49 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:49 --> Input Class Initialized
INFO - 2021-03-26 20:33:49 --> Language Class Initialized
INFO - 2021-03-26 20:33:49 --> Loader Class Initialized
INFO - 2021-03-26 20:33:49 --> Helper loaded: url_helper
INFO - 2021-03-26 20:33:49 --> Helper loaded: form_helper
INFO - 2021-03-26 20:33:49 --> Helper loaded: common_helper
INFO - 2021-03-26 20:33:49 --> Helper loaded: util_helper
INFO - 2021-03-26 20:33:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:33:49 --> Form Validation Class Initialized
INFO - 2021-03-26 20:33:49 --> Controller Class Initialized
INFO - 2021-03-26 20:33:49 --> Model Class Initialized
INFO - 2021-03-26 20:33:49 --> Model Class Initialized
INFO - 2021-03-26 20:33:49 --> Model Class Initialized
INFO - 2021-03-26 20:33:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:33:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:33:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:33:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:33:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:33:49 --> Final output sent to browser
DEBUG - 2021-03-26 20:33:49 --> Total execution time: 0.0941
INFO - 2021-03-26 20:33:49 --> Config Class Initialized
INFO - 2021-03-26 20:33:49 --> Hooks Class Initialized
INFO - 2021-03-26 20:33:49 --> Config Class Initialized
INFO - 2021-03-26 20:33:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:49 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:49 --> URI Class Initialized
INFO - 2021-03-26 20:33:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:49 --> URI Class Initialized
INFO - 2021-03-26 20:33:49 --> Router Class Initialized
INFO - 2021-03-26 20:33:49 --> Router Class Initialized
INFO - 2021-03-26 20:33:49 --> Output Class Initialized
INFO - 2021-03-26 20:33:49 --> Security Class Initialized
INFO - 2021-03-26 20:33:49 --> Output Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:49 --> Security Class Initialized
INFO - 2021-03-26 20:33:49 --> Input Class Initialized
INFO - 2021-03-26 20:33:49 --> Language Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:49 --> Input Class Initialized
ERROR - 2021-03-26 20:33:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:33:49 --> Language Class Initialized
ERROR - 2021-03-26 20:33:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:33:49 --> Config Class Initialized
INFO - 2021-03-26 20:33:49 --> Hooks Class Initialized
INFO - 2021-03-26 20:33:49 --> Config Class Initialized
INFO - 2021-03-26 20:33:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:49 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:33:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:33:49 --> URI Class Initialized
INFO - 2021-03-26 20:33:49 --> URI Class Initialized
INFO - 2021-03-26 20:33:49 --> Router Class Initialized
INFO - 2021-03-26 20:33:49 --> Router Class Initialized
INFO - 2021-03-26 20:33:49 --> Output Class Initialized
INFO - 2021-03-26 20:33:49 --> Output Class Initialized
INFO - 2021-03-26 20:33:49 --> Security Class Initialized
INFO - 2021-03-26 20:33:49 --> Security Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:49 --> Input Class Initialized
DEBUG - 2021-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:33:49 --> Input Class Initialized
INFO - 2021-03-26 20:33:49 --> Language Class Initialized
INFO - 2021-03-26 20:33:49 --> Language Class Initialized
ERROR - 2021-03-26 20:33:49 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:33:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:37:24 --> Config Class Initialized
INFO - 2021-03-26 20:37:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:24 --> URI Class Initialized
INFO - 2021-03-26 20:37:24 --> Router Class Initialized
INFO - 2021-03-26 20:37:24 --> Output Class Initialized
INFO - 2021-03-26 20:37:24 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:24 --> Input Class Initialized
INFO - 2021-03-26 20:37:24 --> Language Class Initialized
INFO - 2021-03-26 20:37:24 --> Loader Class Initialized
INFO - 2021-03-26 20:37:24 --> Helper loaded: url_helper
INFO - 2021-03-26 20:37:24 --> Helper loaded: form_helper
INFO - 2021-03-26 20:37:24 --> Helper loaded: common_helper
INFO - 2021-03-26 20:37:24 --> Helper loaded: util_helper
INFO - 2021-03-26 20:37:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:37:24 --> Form Validation Class Initialized
INFO - 2021-03-26 20:37:24 --> Controller Class Initialized
INFO - 2021-03-26 20:37:24 --> Model Class Initialized
INFO - 2021-03-26 20:37:24 --> Model Class Initialized
INFO - 2021-03-26 20:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-26 20:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:37:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:37:24 --> Final output sent to browser
DEBUG - 2021-03-26 20:37:24 --> Total execution time: 0.0490
INFO - 2021-03-26 20:37:24 --> Config Class Initialized
INFO - 2021-03-26 20:37:24 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:24 --> Config Class Initialized
DEBUG - 2021-03-26 20:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:24 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:24 --> URI Class Initialized
INFO - 2021-03-26 20:37:24 --> Router Class Initialized
DEBUG - 2021-03-26 20:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:24 --> URI Class Initialized
INFO - 2021-03-26 20:37:24 --> Output Class Initialized
INFO - 2021-03-26 20:37:24 --> Security Class Initialized
INFO - 2021-03-26 20:37:24 --> Router Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:24 --> Input Class Initialized
INFO - 2021-03-26 20:37:24 --> Language Class Initialized
INFO - 2021-03-26 20:37:24 --> Output Class Initialized
ERROR - 2021-03-26 20:37:24 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:37:24 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:24 --> Input Class Initialized
INFO - 2021-03-26 20:37:24 --> Language Class Initialized
ERROR - 2021-03-26 20:37:24 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:37:24 --> Config Class Initialized
INFO - 2021-03-26 20:37:24 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:24 --> Config Class Initialized
INFO - 2021-03-26 20:37:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:24 --> URI Class Initialized
DEBUG - 2021-03-26 20:37:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:24 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:24 --> URI Class Initialized
INFO - 2021-03-26 20:37:24 --> Router Class Initialized
INFO - 2021-03-26 20:37:24 --> Output Class Initialized
INFO - 2021-03-26 20:37:24 --> Router Class Initialized
INFO - 2021-03-26 20:37:24 --> Security Class Initialized
INFO - 2021-03-26 20:37:24 --> Output Class Initialized
INFO - 2021-03-26 20:37:24 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:24 --> Input Class Initialized
DEBUG - 2021-03-26 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:24 --> Input Class Initialized
INFO - 2021-03-26 20:37:24 --> Language Class Initialized
INFO - 2021-03-26 20:37:24 --> Language Class Initialized
ERROR - 2021-03-26 20:37:24 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:37:24 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:37:30 --> Config Class Initialized
INFO - 2021-03-26 20:37:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:30 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:30 --> URI Class Initialized
INFO - 2021-03-26 20:37:30 --> Router Class Initialized
INFO - 2021-03-26 20:37:30 --> Output Class Initialized
INFO - 2021-03-26 20:37:30 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:30 --> Input Class Initialized
INFO - 2021-03-26 20:37:30 --> Language Class Initialized
INFO - 2021-03-26 20:37:30 --> Loader Class Initialized
INFO - 2021-03-26 20:37:30 --> Helper loaded: url_helper
INFO - 2021-03-26 20:37:30 --> Helper loaded: form_helper
INFO - 2021-03-26 20:37:30 --> Helper loaded: common_helper
INFO - 2021-03-26 20:37:30 --> Helper loaded: util_helper
INFO - 2021-03-26 20:37:30 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:37:30 --> Form Validation Class Initialized
INFO - 2021-03-26 20:37:30 --> Controller Class Initialized
INFO - 2021-03-26 20:37:30 --> Model Class Initialized
INFO - 2021-03-26 20:37:30 --> Model Class Initialized
INFO - 2021-03-26 20:37:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:37:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:37:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-26 20:37:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:37:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:37:30 --> Final output sent to browser
DEBUG - 2021-03-26 20:37:30 --> Total execution time: 0.0460
INFO - 2021-03-26 20:37:30 --> Config Class Initialized
INFO - 2021-03-26 20:37:30 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:30 --> Config Class Initialized
INFO - 2021-03-26 20:37:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:30 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:30 --> URI Class Initialized
INFO - 2021-03-26 20:37:30 --> Router Class Initialized
DEBUG - 2021-03-26 20:37:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:30 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:30 --> URI Class Initialized
INFO - 2021-03-26 20:37:30 --> Output Class Initialized
INFO - 2021-03-26 20:37:30 --> Router Class Initialized
INFO - 2021-03-26 20:37:30 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:30 --> Output Class Initialized
INFO - 2021-03-26 20:37:30 --> Input Class Initialized
INFO - 2021-03-26 20:37:30 --> Language Class Initialized
INFO - 2021-03-26 20:37:30 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-26 20:37:30 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:30 --> Input Class Initialized
INFO - 2021-03-26 20:37:30 --> Language Class Initialized
INFO - 2021-03-26 20:37:30 --> Config Class Initialized
INFO - 2021-03-26 20:37:30 --> Hooks Class Initialized
ERROR - 2021-03-26 20:37:30 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-26 20:37:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:30 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:30 --> URI Class Initialized
INFO - 2021-03-26 20:37:30 --> Router Class Initialized
INFO - 2021-03-26 20:37:30 --> Output Class Initialized
INFO - 2021-03-26 20:37:30 --> Config Class Initialized
INFO - 2021-03-26 20:37:30 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:30 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:30 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:30 --> Input Class Initialized
INFO - 2021-03-26 20:37:30 --> URI Class Initialized
INFO - 2021-03-26 20:37:30 --> Language Class Initialized
INFO - 2021-03-26 20:37:30 --> Router Class Initialized
ERROR - 2021-03-26 20:37:30 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:30 --> Output Class Initialized
INFO - 2021-03-26 20:37:30 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:30 --> Input Class Initialized
INFO - 2021-03-26 20:37:30 --> Language Class Initialized
ERROR - 2021-03-26 20:37:30 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
INFO - 2021-03-26 20:37:37 --> Loader Class Initialized
INFO - 2021-03-26 20:37:37 --> Helper loaded: url_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: form_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: common_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: util_helper
INFO - 2021-03-26 20:37:37 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:37:37 --> Form Validation Class Initialized
INFO - 2021-03-26 20:37:37 --> Controller Class Initialized
INFO - 2021-03-26 20:37:37 --> Model Class Initialized
INFO - 2021-03-26 20:37:37 --> Model Class Initialized
INFO - 2021-03-26 20:37:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
INFO - 2021-03-26 20:37:37 --> Loader Class Initialized
INFO - 2021-03-26 20:37:37 --> Helper loaded: url_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: form_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: common_helper
INFO - 2021-03-26 20:37:37 --> Helper loaded: util_helper
INFO - 2021-03-26 20:37:37 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:37:37 --> Form Validation Class Initialized
INFO - 2021-03-26 20:37:37 --> Controller Class Initialized
INFO - 2021-03-26 20:37:37 --> Model Class Initialized
INFO - 2021-03-26 20:37:37 --> Model Class Initialized
INFO - 2021-03-26 20:37:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:37:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:37:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-26 20:37:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:37:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:37:37 --> Final output sent to browser
DEBUG - 2021-03-26 20:37:37 --> Total execution time: 0.0693
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Config Class Initialized
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
DEBUG - 2021-03-26 20:37:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
INFO - 2021-03-26 20:37:37 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:37 --> URI Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
INFO - 2021-03-26 20:37:37 --> Router Class Initialized
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
ERROR - 2021-03-26 20:37:37 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
ERROR - 2021-03-26 20:37:37 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
INFO - 2021-03-26 20:37:37 --> Output Class Initialized
ERROR - 2021-03-26 20:37:37 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:37 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:37 --> Input Class Initialized
INFO - 2021-03-26 20:37:37 --> Language Class Initialized
ERROR - 2021-03-26 20:37:37 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-26 20:37:51 --> Config Class Initialized
INFO - 2021-03-26 20:37:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:37:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:51 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:51 --> URI Class Initialized
INFO - 2021-03-26 20:37:51 --> Router Class Initialized
INFO - 2021-03-26 20:37:51 --> Output Class Initialized
INFO - 2021-03-26 20:37:51 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:51 --> Input Class Initialized
INFO - 2021-03-26 20:37:51 --> Language Class Initialized
INFO - 2021-03-26 20:37:51 --> Loader Class Initialized
INFO - 2021-03-26 20:37:51 --> Helper loaded: url_helper
INFO - 2021-03-26 20:37:51 --> Helper loaded: form_helper
INFO - 2021-03-26 20:37:51 --> Helper loaded: common_helper
INFO - 2021-03-26 20:37:51 --> Helper loaded: util_helper
INFO - 2021-03-26 20:37:51 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:37:51 --> Form Validation Class Initialized
INFO - 2021-03-26 20:37:51 --> Controller Class Initialized
INFO - 2021-03-26 20:37:51 --> Model Class Initialized
INFO - 2021-03-26 20:37:51 --> Model Class Initialized
INFO - 2021-03-26 20:37:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:37:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:37:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-26 20:37:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:37:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:37:51 --> Final output sent to browser
DEBUG - 2021-03-26 20:37:51 --> Total execution time: 0.0430
INFO - 2021-03-26 20:37:52 --> Config Class Initialized
INFO - 2021-03-26 20:37:52 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:52 --> Config Class Initialized
DEBUG - 2021-03-26 20:37:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:52 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:52 --> URI Class Initialized
INFO - 2021-03-26 20:37:52 --> Router Class Initialized
INFO - 2021-03-26 20:37:52 --> Output Class Initialized
INFO - 2021-03-26 20:37:52 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:52 --> Input Class Initialized
INFO - 2021-03-26 20:37:52 --> Config Class Initialized
INFO - 2021-03-26 20:37:52 --> Language Class Initialized
INFO - 2021-03-26 20:37:52 --> Hooks Class Initialized
ERROR - 2021-03-26 20:37:52 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 20:37:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:52 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:52 --> URI Class Initialized
INFO - 2021-03-26 20:37:52 --> Router Class Initialized
INFO - 2021-03-26 20:37:52 --> Output Class Initialized
INFO - 2021-03-26 20:37:52 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:52 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:52 --> Config Class Initialized
INFO - 2021-03-26 20:37:52 --> Input Class Initialized
INFO - 2021-03-26 20:37:52 --> Hooks Class Initialized
INFO - 2021-03-26 20:37:52 --> Language Class Initialized
DEBUG - 2021-03-26 20:37:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:52 --> Utf8 Class Initialized
ERROR - 2021-03-26 20:37:52 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 20:37:52 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:37:52 --> Utf8 Class Initialized
INFO - 2021-03-26 20:37:52 --> URI Class Initialized
INFO - 2021-03-26 20:37:52 --> URI Class Initialized
INFO - 2021-03-26 20:37:52 --> Router Class Initialized
INFO - 2021-03-26 20:37:52 --> Router Class Initialized
INFO - 2021-03-26 20:37:52 --> Output Class Initialized
INFO - 2021-03-26 20:37:52 --> Output Class Initialized
INFO - 2021-03-26 20:37:52 --> Security Class Initialized
INFO - 2021-03-26 20:37:52 --> Security Class Initialized
DEBUG - 2021-03-26 20:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 20:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:37:52 --> Input Class Initialized
INFO - 2021-03-26 20:37:52 --> Input Class Initialized
INFO - 2021-03-26 20:37:52 --> Language Class Initialized
INFO - 2021-03-26 20:37:52 --> Language Class Initialized
ERROR - 2021-03-26 20:37:52 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:37:52 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:01 --> Config Class Initialized
INFO - 2021-03-26 20:38:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:01 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:01 --> URI Class Initialized
INFO - 2021-03-26 20:38:01 --> Router Class Initialized
INFO - 2021-03-26 20:38:01 --> Output Class Initialized
INFO - 2021-03-26 20:38:01 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:01 --> Input Class Initialized
INFO - 2021-03-26 20:38:01 --> Language Class Initialized
INFO - 2021-03-26 20:38:01 --> Loader Class Initialized
INFO - 2021-03-26 20:38:01 --> Helper loaded: url_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: form_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: common_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: util_helper
INFO - 2021-03-26 20:38:01 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:38:01 --> Form Validation Class Initialized
INFO - 2021-03-26 20:38:01 --> Controller Class Initialized
INFO - 2021-03-26 20:38:01 --> Model Class Initialized
INFO - 2021-03-26 20:38:01 --> Model Class Initialized
INFO - 2021-03-26 20:38:01 --> Config Class Initialized
INFO - 2021-03-26 20:38:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:01 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:01 --> URI Class Initialized
INFO - 2021-03-26 20:38:01 --> Router Class Initialized
INFO - 2021-03-26 20:38:01 --> Output Class Initialized
INFO - 2021-03-26 20:38:01 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:01 --> Input Class Initialized
INFO - 2021-03-26 20:38:01 --> Language Class Initialized
INFO - 2021-03-26 20:38:01 --> Loader Class Initialized
INFO - 2021-03-26 20:38:01 --> Helper loaded: url_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: form_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: common_helper
INFO - 2021-03-26 20:38:01 --> Helper loaded: util_helper
INFO - 2021-03-26 20:38:01 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:38:01 --> Form Validation Class Initialized
INFO - 2021-03-26 20:38:01 --> Controller Class Initialized
INFO - 2021-03-26 20:38:01 --> Model Class Initialized
INFO - 2021-03-26 20:38:01 --> Model Class Initialized
INFO - 2021-03-26 20:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-26 20:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:38:01 --> Final output sent to browser
DEBUG - 2021-03-26 20:38:01 --> Total execution time: 0.0497
INFO - 2021-03-26 20:38:01 --> Config Class Initialized
INFO - 2021-03-26 20:38:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:01 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:01 --> Config Class Initialized
INFO - 2021-03-26 20:38:01 --> Hooks Class Initialized
INFO - 2021-03-26 20:38:01 --> URI Class Initialized
INFO - 2021-03-26 20:38:02 --> Router Class Initialized
INFO - 2021-03-26 20:38:02 --> Output Class Initialized
INFO - 2021-03-26 20:38:02 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:02 --> Input Class Initialized
INFO - 2021-03-26 20:38:02 --> Language Class Initialized
DEBUG - 2021-03-26 20:38:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:02 --> Utf8 Class Initialized
ERROR - 2021-03-26 20:38:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:02 --> URI Class Initialized
INFO - 2021-03-26 20:38:02 --> Router Class Initialized
INFO - 2021-03-26 20:38:02 --> Output Class Initialized
INFO - 2021-03-26 20:38:02 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:02 --> Input Class Initialized
INFO - 2021-03-26 20:38:02 --> Language Class Initialized
ERROR - 2021-03-26 20:38:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:02 --> Config Class Initialized
INFO - 2021-03-26 20:38:02 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:02 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:02 --> URI Class Initialized
INFO - 2021-03-26 20:38:02 --> Router Class Initialized
INFO - 2021-03-26 20:38:02 --> Config Class Initialized
INFO - 2021-03-26 20:38:02 --> Hooks Class Initialized
INFO - 2021-03-26 20:38:02 --> Output Class Initialized
DEBUG - 2021-03-26 20:38:02 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:02 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:02 --> Security Class Initialized
INFO - 2021-03-26 20:38:02 --> URI Class Initialized
DEBUG - 2021-03-26 20:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:02 --> Input Class Initialized
INFO - 2021-03-26 20:38:02 --> Language Class Initialized
INFO - 2021-03-26 20:38:02 --> Router Class Initialized
ERROR - 2021-03-26 20:38:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:02 --> Output Class Initialized
INFO - 2021-03-26 20:38:02 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:02 --> Input Class Initialized
INFO - 2021-03-26 20:38:02 --> Language Class Initialized
ERROR - 2021-03-26 20:38:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:09 --> Config Class Initialized
INFO - 2021-03-26 20:38:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:09 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:09 --> URI Class Initialized
INFO - 2021-03-26 20:38:09 --> Router Class Initialized
INFO - 2021-03-26 20:38:09 --> Output Class Initialized
INFO - 2021-03-26 20:38:09 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:09 --> Input Class Initialized
INFO - 2021-03-26 20:38:09 --> Language Class Initialized
INFO - 2021-03-26 20:38:09 --> Loader Class Initialized
INFO - 2021-03-26 20:38:09 --> Helper loaded: url_helper
INFO - 2021-03-26 20:38:09 --> Helper loaded: form_helper
INFO - 2021-03-26 20:38:09 --> Helper loaded: common_helper
INFO - 2021-03-26 20:38:09 --> Helper loaded: util_helper
INFO - 2021-03-26 20:38:09 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:38:09 --> Form Validation Class Initialized
INFO - 2021-03-26 20:38:09 --> Controller Class Initialized
INFO - 2021-03-26 20:38:09 --> Model Class Initialized
INFO - 2021-03-26 20:38:09 --> Model Class Initialized
INFO - 2021-03-26 20:38:09 --> Model Class Initialized
INFO - 2021-03-26 20:38:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:38:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:38:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:38:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:38:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:38:09 --> Final output sent to browser
DEBUG - 2021-03-26 20:38:09 --> Total execution time: 0.0476
INFO - 2021-03-26 20:38:09 --> Config Class Initialized
INFO - 2021-03-26 20:38:09 --> Hooks Class Initialized
INFO - 2021-03-26 20:38:09 --> Config Class Initialized
INFO - 2021-03-26 20:38:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:09 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:09 --> URI Class Initialized
DEBUG - 2021-03-26 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:09 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:09 --> Router Class Initialized
INFO - 2021-03-26 20:38:09 --> Output Class Initialized
INFO - 2021-03-26 20:38:09 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:09 --> Input Class Initialized
INFO - 2021-03-26 20:38:09 --> Language Class Initialized
INFO - 2021-03-26 20:38:09 --> URI Class Initialized
ERROR - 2021-03-26 20:38:09 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:09 --> Router Class Initialized
INFO - 2021-03-26 20:38:09 --> Output Class Initialized
INFO - 2021-03-26 20:38:09 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:09 --> Input Class Initialized
INFO - 2021-03-26 20:38:09 --> Language Class Initialized
ERROR - 2021-03-26 20:38:09 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:38:09 --> Config Class Initialized
INFO - 2021-03-26 20:38:09 --> Hooks Class Initialized
INFO - 2021-03-26 20:38:09 --> Config Class Initialized
INFO - 2021-03-26 20:38:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:38:09 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 20:38:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:38:09 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:09 --> Utf8 Class Initialized
INFO - 2021-03-26 20:38:09 --> URI Class Initialized
INFO - 2021-03-26 20:38:09 --> URI Class Initialized
INFO - 2021-03-26 20:38:09 --> Router Class Initialized
INFO - 2021-03-26 20:38:09 --> Router Class Initialized
INFO - 2021-03-26 20:38:09 --> Output Class Initialized
INFO - 2021-03-26 20:38:09 --> Output Class Initialized
INFO - 2021-03-26 20:38:09 --> Security Class Initialized
INFO - 2021-03-26 20:38:09 --> Security Class Initialized
DEBUG - 2021-03-26 20:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:38:09 --> Input Class Initialized
INFO - 2021-03-26 20:38:09 --> Input Class Initialized
INFO - 2021-03-26 20:38:09 --> Language Class Initialized
INFO - 2021-03-26 20:38:09 --> Language Class Initialized
ERROR - 2021-03-26 20:38:09 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:38:09 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:25 --> Config Class Initialized
INFO - 2021-03-26 20:54:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:25 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:25 --> URI Class Initialized
INFO - 2021-03-26 20:54:25 --> Router Class Initialized
INFO - 2021-03-26 20:54:25 --> Output Class Initialized
INFO - 2021-03-26 20:54:25 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:25 --> Input Class Initialized
INFO - 2021-03-26 20:54:25 --> Language Class Initialized
INFO - 2021-03-26 20:54:25 --> Loader Class Initialized
INFO - 2021-03-26 20:54:25 --> Helper loaded: url_helper
INFO - 2021-03-26 20:54:25 --> Helper loaded: form_helper
INFO - 2021-03-26 20:54:25 --> Helper loaded: common_helper
INFO - 2021-03-26 20:54:25 --> Helper loaded: util_helper
INFO - 2021-03-26 20:54:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:54:25 --> Form Validation Class Initialized
INFO - 2021-03-26 20:54:25 --> Controller Class Initialized
INFO - 2021-03-26 20:54:25 --> Model Class Initialized
INFO - 2021-03-26 20:54:25 --> Model Class Initialized
INFO - 2021-03-26 20:54:25 --> Model Class Initialized
INFO - 2021-03-26 20:54:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:54:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:54:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:54:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:54:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:54:25 --> Final output sent to browser
DEBUG - 2021-03-26 20:54:25 --> Total execution time: 0.0515
INFO - 2021-03-26 20:54:25 --> Config Class Initialized
INFO - 2021-03-26 20:54:25 --> Config Class Initialized
INFO - 2021-03-26 20:54:25 --> Hooks Class Initialized
INFO - 2021-03-26 20:54:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:25 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 20:54:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:25 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:25 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:25 --> URI Class Initialized
INFO - 2021-03-26 20:54:25 --> URI Class Initialized
INFO - 2021-03-26 20:54:26 --> Router Class Initialized
INFO - 2021-03-26 20:54:26 --> Router Class Initialized
INFO - 2021-03-26 20:54:26 --> Output Class Initialized
INFO - 2021-03-26 20:54:26 --> Output Class Initialized
INFO - 2021-03-26 20:54:26 --> Security Class Initialized
INFO - 2021-03-26 20:54:26 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:26 --> Input Class Initialized
INFO - 2021-03-26 20:54:26 --> Language Class Initialized
DEBUG - 2021-03-26 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:26 --> Input Class Initialized
INFO - 2021-03-26 20:54:26 --> Language Class Initialized
ERROR - 2021-03-26 20:54:26 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:54:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:26 --> Config Class Initialized
INFO - 2021-03-26 20:54:26 --> Hooks Class Initialized
INFO - 2021-03-26 20:54:26 --> Config Class Initialized
INFO - 2021-03-26 20:54:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:26 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:54:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:26 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:26 --> URI Class Initialized
INFO - 2021-03-26 20:54:26 --> URI Class Initialized
INFO - 2021-03-26 20:54:26 --> Router Class Initialized
INFO - 2021-03-26 20:54:26 --> Router Class Initialized
INFO - 2021-03-26 20:54:26 --> Output Class Initialized
INFO - 2021-03-26 20:54:26 --> Output Class Initialized
INFO - 2021-03-26 20:54:26 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:26 --> Security Class Initialized
INFO - 2021-03-26 20:54:26 --> Input Class Initialized
INFO - 2021-03-26 20:54:26 --> Language Class Initialized
DEBUG - 2021-03-26 20:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:26 --> Input Class Initialized
ERROR - 2021-03-26 20:54:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:26 --> Language Class Initialized
ERROR - 2021-03-26 20:54:26 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:29 --> Config Class Initialized
INFO - 2021-03-26 20:54:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:29 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:29 --> URI Class Initialized
INFO - 2021-03-26 20:54:29 --> Router Class Initialized
INFO - 2021-03-26 20:54:29 --> Output Class Initialized
INFO - 2021-03-26 20:54:29 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:29 --> Input Class Initialized
INFO - 2021-03-26 20:54:29 --> Language Class Initialized
INFO - 2021-03-26 20:54:29 --> Loader Class Initialized
INFO - 2021-03-26 20:54:29 --> Helper loaded: url_helper
INFO - 2021-03-26 20:54:29 --> Helper loaded: form_helper
INFO - 2021-03-26 20:54:29 --> Helper loaded: common_helper
INFO - 2021-03-26 20:54:29 --> Helper loaded: util_helper
INFO - 2021-03-26 20:54:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:54:29 --> Form Validation Class Initialized
INFO - 2021-03-26 20:54:29 --> Controller Class Initialized
INFO - 2021-03-26 20:54:29 --> Model Class Initialized
INFO - 2021-03-26 20:54:29 --> Model Class Initialized
INFO - 2021-03-26 20:54:29 --> Model Class Initialized
INFO - 2021-03-26 20:54:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:54:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:54:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:54:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:54:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:54:29 --> Final output sent to browser
DEBUG - 2021-03-26 20:54:29 --> Total execution time: 0.0500
INFO - 2021-03-26 20:54:29 --> Config Class Initialized
INFO - 2021-03-26 20:54:29 --> Hooks Class Initialized
INFO - 2021-03-26 20:54:29 --> Config Class Initialized
INFO - 2021-03-26 20:54:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:29 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:54:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:29 --> URI Class Initialized
INFO - 2021-03-26 20:54:29 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:29 --> Router Class Initialized
INFO - 2021-03-26 20:54:29 --> URI Class Initialized
INFO - 2021-03-26 20:54:29 --> Output Class Initialized
INFO - 2021-03-26 20:54:29 --> Router Class Initialized
INFO - 2021-03-26 20:54:29 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:29 --> Input Class Initialized
INFO - 2021-03-26 20:54:29 --> Output Class Initialized
INFO - 2021-03-26 20:54:29 --> Language Class Initialized
INFO - 2021-03-26 20:54:29 --> Security Class Initialized
ERROR - 2021-03-26 20:54:29 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:29 --> Input Class Initialized
INFO - 2021-03-26 20:54:29 --> Language Class Initialized
ERROR - 2021-03-26 20:54:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:29 --> Config Class Initialized
INFO - 2021-03-26 20:54:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:54:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:29 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:29 --> URI Class Initialized
INFO - 2021-03-26 20:54:29 --> Config Class Initialized
INFO - 2021-03-26 20:54:29 --> Hooks Class Initialized
INFO - 2021-03-26 20:54:29 --> Router Class Initialized
DEBUG - 2021-03-26 20:54:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:54:29 --> Utf8 Class Initialized
INFO - 2021-03-26 20:54:29 --> Output Class Initialized
INFO - 2021-03-26 20:54:29 --> URI Class Initialized
INFO - 2021-03-26 20:54:29 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:29 --> Router Class Initialized
INFO - 2021-03-26 20:54:29 --> Input Class Initialized
INFO - 2021-03-26 20:54:29 --> Language Class Initialized
INFO - 2021-03-26 20:54:29 --> Output Class Initialized
ERROR - 2021-03-26 20:54:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:54:29 --> Security Class Initialized
DEBUG - 2021-03-26 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:54:29 --> Input Class Initialized
INFO - 2021-03-26 20:54:29 --> Language Class Initialized
ERROR - 2021-03-26 20:54:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:55:54 --> Config Class Initialized
INFO - 2021-03-26 20:55:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:55:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:54 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:54 --> URI Class Initialized
INFO - 2021-03-26 20:55:54 --> Router Class Initialized
INFO - 2021-03-26 20:55:54 --> Output Class Initialized
INFO - 2021-03-26 20:55:54 --> Security Class Initialized
DEBUG - 2021-03-26 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:54 --> Input Class Initialized
INFO - 2021-03-26 20:55:54 --> Language Class Initialized
INFO - 2021-03-26 20:55:54 --> Loader Class Initialized
INFO - 2021-03-26 20:55:54 --> Helper loaded: url_helper
INFO - 2021-03-26 20:55:54 --> Helper loaded: form_helper
INFO - 2021-03-26 20:55:54 --> Helper loaded: common_helper
INFO - 2021-03-26 20:55:54 --> Helper loaded: util_helper
INFO - 2021-03-26 20:55:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:55:54 --> Form Validation Class Initialized
INFO - 2021-03-26 20:55:54 --> Controller Class Initialized
INFO - 2021-03-26 20:55:54 --> Model Class Initialized
INFO - 2021-03-26 20:55:54 --> Model Class Initialized
INFO - 2021-03-26 20:55:54 --> Model Class Initialized
INFO - 2021-03-26 20:55:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:55:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:55:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:55:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:55:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:55:54 --> Final output sent to browser
DEBUG - 2021-03-26 20:55:54 --> Total execution time: 0.0462
INFO - 2021-03-26 20:55:54 --> Config Class Initialized
INFO - 2021-03-26 20:55:54 --> Hooks Class Initialized
INFO - 2021-03-26 20:55:54 --> Config Class Initialized
INFO - 2021-03-26 20:55:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:55:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:54 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:54 --> URI Class Initialized
DEBUG - 2021-03-26 20:55:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:54 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:54 --> Router Class Initialized
INFO - 2021-03-26 20:55:54 --> URI Class Initialized
INFO - 2021-03-26 20:55:54 --> Output Class Initialized
INFO - 2021-03-26 20:55:54 --> Security Class Initialized
INFO - 2021-03-26 20:55:54 --> Router Class Initialized
DEBUG - 2021-03-26 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:54 --> Input Class Initialized
INFO - 2021-03-26 20:55:54 --> Output Class Initialized
INFO - 2021-03-26 20:55:54 --> Language Class Initialized
INFO - 2021-03-26 20:55:54 --> Security Class Initialized
ERROR - 2021-03-26 20:55:54 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:54 --> Input Class Initialized
INFO - 2021-03-26 20:55:54 --> Language Class Initialized
ERROR - 2021-03-26 20:55:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:55:54 --> Config Class Initialized
INFO - 2021-03-26 20:55:54 --> Hooks Class Initialized
INFO - 2021-03-26 20:55:54 --> Config Class Initialized
INFO - 2021-03-26 20:55:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:55:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:54 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:54 --> URI Class Initialized
DEBUG - 2021-03-26 20:55:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:54 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:54 --> Router Class Initialized
INFO - 2021-03-26 20:55:54 --> URI Class Initialized
INFO - 2021-03-26 20:55:54 --> Output Class Initialized
INFO - 2021-03-26 20:55:54 --> Router Class Initialized
INFO - 2021-03-26 20:55:54 --> Security Class Initialized
INFO - 2021-03-26 20:55:54 --> Output Class Initialized
DEBUG - 2021-03-26 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:54 --> Security Class Initialized
INFO - 2021-03-26 20:55:54 --> Input Class Initialized
INFO - 2021-03-26 20:55:54 --> Language Class Initialized
DEBUG - 2021-03-26 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:54 --> Input Class Initialized
INFO - 2021-03-26 20:55:54 --> Language Class Initialized
ERROR - 2021-03-26 20:55:54 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:55:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:55:58 --> Config Class Initialized
INFO - 2021-03-26 20:55:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:55:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:58 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:58 --> URI Class Initialized
INFO - 2021-03-26 20:55:58 --> Router Class Initialized
INFO - 2021-03-26 20:55:58 --> Output Class Initialized
INFO - 2021-03-26 20:55:58 --> Security Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:58 --> Input Class Initialized
INFO - 2021-03-26 20:55:58 --> Language Class Initialized
INFO - 2021-03-26 20:55:58 --> Loader Class Initialized
INFO - 2021-03-26 20:55:58 --> Helper loaded: url_helper
INFO - 2021-03-26 20:55:58 --> Helper loaded: form_helper
INFO - 2021-03-26 20:55:58 --> Helper loaded: common_helper
INFO - 2021-03-26 20:55:58 --> Helper loaded: util_helper
INFO - 2021-03-26 20:55:58 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:55:58 --> Form Validation Class Initialized
INFO - 2021-03-26 20:55:58 --> Controller Class Initialized
INFO - 2021-03-26 20:55:58 --> Model Class Initialized
INFO - 2021-03-26 20:55:58 --> Model Class Initialized
INFO - 2021-03-26 20:55:58 --> Model Class Initialized
INFO - 2021-03-26 20:55:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:55:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:55:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/add.php
INFO - 2021-03-26 20:55:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:55:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:55:58 --> Final output sent to browser
DEBUG - 2021-03-26 20:55:58 --> Total execution time: 0.0384
INFO - 2021-03-26 20:55:58 --> Config Class Initialized
INFO - 2021-03-26 20:55:58 --> Config Class Initialized
INFO - 2021-03-26 20:55:58 --> Hooks Class Initialized
INFO - 2021-03-26 20:55:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:55:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:58 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:55:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:58 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:58 --> URI Class Initialized
INFO - 2021-03-26 20:55:58 --> URI Class Initialized
INFO - 2021-03-26 20:55:58 --> Router Class Initialized
INFO - 2021-03-26 20:55:58 --> Router Class Initialized
INFO - 2021-03-26 20:55:58 --> Output Class Initialized
INFO - 2021-03-26 20:55:58 --> Output Class Initialized
INFO - 2021-03-26 20:55:58 --> Security Class Initialized
INFO - 2021-03-26 20:55:58 --> Security Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:58 --> Input Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:58 --> Input Class Initialized
INFO - 2021-03-26 20:55:58 --> Language Class Initialized
INFO - 2021-03-26 20:55:58 --> Language Class Initialized
INFO - 2021-03-26 20:55:58 --> Config Class Initialized
INFO - 2021-03-26 20:55:58 --> Hooks Class Initialized
ERROR - 2021-03-26 20:55:58 --> 404 Page Not Found: administrator/User/dist
DEBUG - 2021-03-26 20:55:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:58 --> Utf8 Class Initialized
ERROR - 2021-03-26 20:55:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:55:58 --> URI Class Initialized
INFO - 2021-03-26 20:55:58 --> Router Class Initialized
INFO - 2021-03-26 20:55:58 --> Output Class Initialized
INFO - 2021-03-26 20:55:58 --> Security Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:58 --> Input Class Initialized
INFO - 2021-03-26 20:55:58 --> Config Class Initialized
INFO - 2021-03-26 20:55:58 --> Language Class Initialized
INFO - 2021-03-26 20:55:58 --> Hooks Class Initialized
ERROR - 2021-03-26 20:55:58 --> 404 Page Not Found: administrator/User/dist
DEBUG - 2021-03-26 20:55:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:55:58 --> Utf8 Class Initialized
INFO - 2021-03-26 20:55:58 --> URI Class Initialized
INFO - 2021-03-26 20:55:58 --> Router Class Initialized
INFO - 2021-03-26 20:55:58 --> Output Class Initialized
INFO - 2021-03-26 20:55:58 --> Security Class Initialized
DEBUG - 2021-03-26 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:55:58 --> Input Class Initialized
INFO - 2021-03-26 20:55:58 --> Language Class Initialized
ERROR - 2021-03-26 20:55:58 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:56:49 --> Config Class Initialized
INFO - 2021-03-26 20:56:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:56:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:56:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:49 --> URI Class Initialized
INFO - 2021-03-26 20:56:49 --> Router Class Initialized
INFO - 2021-03-26 20:56:49 --> Output Class Initialized
INFO - 2021-03-26 20:56:49 --> Security Class Initialized
DEBUG - 2021-03-26 20:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:49 --> Input Class Initialized
INFO - 2021-03-26 20:56:49 --> Language Class Initialized
INFO - 2021-03-26 20:56:49 --> Loader Class Initialized
INFO - 2021-03-26 20:56:49 --> Helper loaded: url_helper
INFO - 2021-03-26 20:56:49 --> Helper loaded: form_helper
INFO - 2021-03-26 20:56:49 --> Helper loaded: common_helper
INFO - 2021-03-26 20:56:49 --> Helper loaded: util_helper
INFO - 2021-03-26 20:56:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:56:49 --> Form Validation Class Initialized
INFO - 2021-03-26 20:56:49 --> Controller Class Initialized
INFO - 2021-03-26 20:56:49 --> Model Class Initialized
INFO - 2021-03-26 20:56:49 --> Model Class Initialized
INFO - 2021-03-26 20:56:49 --> Model Class Initialized
INFO - 2021-03-26 20:56:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-26 20:56:50 --> Config Class Initialized
INFO - 2021-03-26 20:56:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:56:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:56:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:50 --> URI Class Initialized
INFO - 2021-03-26 20:56:50 --> Router Class Initialized
INFO - 2021-03-26 20:56:50 --> Output Class Initialized
INFO - 2021-03-26 20:56:50 --> Security Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:50 --> Input Class Initialized
INFO - 2021-03-26 20:56:50 --> Language Class Initialized
INFO - 2021-03-26 20:56:50 --> Loader Class Initialized
INFO - 2021-03-26 20:56:50 --> Helper loaded: url_helper
INFO - 2021-03-26 20:56:50 --> Helper loaded: form_helper
INFO - 2021-03-26 20:56:50 --> Helper loaded: common_helper
INFO - 2021-03-26 20:56:50 --> Helper loaded: util_helper
INFO - 2021-03-26 20:56:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:56:50 --> Form Validation Class Initialized
INFO - 2021-03-26 20:56:50 --> Controller Class Initialized
INFO - 2021-03-26 20:56:50 --> Model Class Initialized
INFO - 2021-03-26 20:56:50 --> Model Class Initialized
INFO - 2021-03-26 20:56:50 --> Model Class Initialized
INFO - 2021-03-26 20:56:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:56:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:56:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/add.php
INFO - 2021-03-26 20:56:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:56:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:56:50 --> Final output sent to browser
DEBUG - 2021-03-26 20:56:50 --> Total execution time: 0.0425
INFO - 2021-03-26 20:56:50 --> Config Class Initialized
INFO - 2021-03-26 20:56:50 --> Config Class Initialized
INFO - 2021-03-26 20:56:50 --> Hooks Class Initialized
INFO - 2021-03-26 20:56:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 20:56:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:56:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:50 --> URI Class Initialized
INFO - 2021-03-26 20:56:50 --> URI Class Initialized
INFO - 2021-03-26 20:56:50 --> Router Class Initialized
INFO - 2021-03-26 20:56:50 --> Output Class Initialized
INFO - 2021-03-26 20:56:50 --> Router Class Initialized
INFO - 2021-03-26 20:56:50 --> Security Class Initialized
INFO - 2021-03-26 20:56:50 --> Output Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:50 --> Input Class Initialized
INFO - 2021-03-26 20:56:50 --> Security Class Initialized
INFO - 2021-03-26 20:56:50 --> Language Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:50 --> Input Class Initialized
INFO - 2021-03-26 20:56:50 --> Language Class Initialized
ERROR - 2021-03-26 20:56:50 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-03-26 20:56:50 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:56:50 --> Config Class Initialized
INFO - 2021-03-26 20:56:50 --> Hooks Class Initialized
INFO - 2021-03-26 20:56:50 --> Config Class Initialized
INFO - 2021-03-26 20:56:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:56:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:56:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:50 --> URI Class Initialized
DEBUG - 2021-03-26 20:56:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:56:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:56:50 --> URI Class Initialized
INFO - 2021-03-26 20:56:50 --> Router Class Initialized
INFO - 2021-03-26 20:56:50 --> Router Class Initialized
INFO - 2021-03-26 20:56:50 --> Output Class Initialized
INFO - 2021-03-26 20:56:50 --> Security Class Initialized
INFO - 2021-03-26 20:56:50 --> Output Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:50 --> Input Class Initialized
INFO - 2021-03-26 20:56:50 --> Security Class Initialized
INFO - 2021-03-26 20:56:50 --> Language Class Initialized
DEBUG - 2021-03-26 20:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:56:50 --> Input Class Initialized
INFO - 2021-03-26 20:56:50 --> Language Class Initialized
ERROR - 2021-03-26 20:56:50 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-03-26 20:56:50 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:57:11 --> Config Class Initialized
INFO - 2021-03-26 20:57:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:57:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:57:11 --> Utf8 Class Initialized
INFO - 2021-03-26 20:57:11 --> URI Class Initialized
INFO - 2021-03-26 20:57:11 --> Router Class Initialized
INFO - 2021-03-26 20:57:11 --> Output Class Initialized
INFO - 2021-03-26 20:57:11 --> Security Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:57:11 --> Input Class Initialized
INFO - 2021-03-26 20:57:11 --> Language Class Initialized
INFO - 2021-03-26 20:57:11 --> Loader Class Initialized
INFO - 2021-03-26 20:57:11 --> Helper loaded: url_helper
INFO - 2021-03-26 20:57:11 --> Helper loaded: form_helper
INFO - 2021-03-26 20:57:11 --> Helper loaded: common_helper
INFO - 2021-03-26 20:57:11 --> Helper loaded: util_helper
INFO - 2021-03-26 20:57:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:57:11 --> Form Validation Class Initialized
INFO - 2021-03-26 20:57:11 --> Controller Class Initialized
INFO - 2021-03-26 20:57:11 --> Model Class Initialized
INFO - 2021-03-26 20:57:11 --> Model Class Initialized
INFO - 2021-03-26 20:57:11 --> Model Class Initialized
INFO - 2021-03-26 20:57:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:57:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:57:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:57:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:57:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:57:11 --> Final output sent to browser
DEBUG - 2021-03-26 20:57:11 --> Total execution time: 0.0537
INFO - 2021-03-26 20:57:11 --> Config Class Initialized
INFO - 2021-03-26 20:57:11 --> Hooks Class Initialized
INFO - 2021-03-26 20:57:11 --> Config Class Initialized
INFO - 2021-03-26 20:57:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:57:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:57:11 --> Utf8 Class Initialized
INFO - 2021-03-26 20:57:11 --> Config Class Initialized
INFO - 2021-03-26 20:57:11 --> Hooks Class Initialized
INFO - 2021-03-26 20:57:11 --> Config Class Initialized
INFO - 2021-03-26 20:57:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:57:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:57:11 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:57:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:57:11 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:57:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:57:11 --> Utf8 Class Initialized
INFO - 2021-03-26 20:57:11 --> URI Class Initialized
INFO - 2021-03-26 20:57:11 --> URI Class Initialized
INFO - 2021-03-26 20:57:11 --> URI Class Initialized
INFO - 2021-03-26 20:57:11 --> URI Class Initialized
INFO - 2021-03-26 20:57:11 --> Router Class Initialized
INFO - 2021-03-26 20:57:11 --> Router Class Initialized
INFO - 2021-03-26 20:57:11 --> Router Class Initialized
INFO - 2021-03-26 20:57:11 --> Router Class Initialized
INFO - 2021-03-26 20:57:11 --> Output Class Initialized
INFO - 2021-03-26 20:57:11 --> Output Class Initialized
INFO - 2021-03-26 20:57:11 --> Output Class Initialized
INFO - 2021-03-26 20:57:11 --> Output Class Initialized
INFO - 2021-03-26 20:57:11 --> Security Class Initialized
INFO - 2021-03-26 20:57:11 --> Security Class Initialized
INFO - 2021-03-26 20:57:11 --> Security Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:57:11 --> Security Class Initialized
INFO - 2021-03-26 20:57:11 --> Input Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:57:11 --> Input Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:57:11 --> Input Class Initialized
INFO - 2021-03-26 20:57:11 --> Language Class Initialized
INFO - 2021-03-26 20:57:11 --> Language Class Initialized
DEBUG - 2021-03-26 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:57:11 --> Input Class Initialized
INFO - 2021-03-26 20:57:11 --> Language Class Initialized
INFO - 2021-03-26 20:57:11 --> Language Class Initialized
ERROR - 2021-03-26 20:57:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:57:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:57:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:57:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:58:27 --> Config Class Initialized
INFO - 2021-03-26 20:58:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:27 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:27 --> URI Class Initialized
INFO - 2021-03-26 20:58:27 --> Router Class Initialized
INFO - 2021-03-26 20:58:27 --> Output Class Initialized
INFO - 2021-03-26 20:58:27 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:27 --> Input Class Initialized
INFO - 2021-03-26 20:58:27 --> Language Class Initialized
INFO - 2021-03-26 20:58:27 --> Loader Class Initialized
INFO - 2021-03-26 20:58:27 --> Helper loaded: url_helper
INFO - 2021-03-26 20:58:27 --> Helper loaded: form_helper
INFO - 2021-03-26 20:58:27 --> Helper loaded: common_helper
INFO - 2021-03-26 20:58:27 --> Helper loaded: util_helper
INFO - 2021-03-26 20:58:27 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:58:27 --> Form Validation Class Initialized
INFO - 2021-03-26 20:58:27 --> Controller Class Initialized
INFO - 2021-03-26 20:58:27 --> Model Class Initialized
INFO - 2021-03-26 20:58:27 --> Model Class Initialized
INFO - 2021-03-26 20:58:27 --> Model Class Initialized
INFO - 2021-03-26 20:58:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:58:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:58:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-26 20:58:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:58:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:58:27 --> Final output sent to browser
DEBUG - 2021-03-26 20:58:27 --> Total execution time: 0.0438
INFO - 2021-03-26 20:58:27 --> Config Class Initialized
INFO - 2021-03-26 20:58:27 --> Config Class Initialized
INFO - 2021-03-26 20:58:27 --> Hooks Class Initialized
INFO - 2021-03-26 20:58:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 20:58:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:27 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:27 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:27 --> URI Class Initialized
INFO - 2021-03-26 20:58:27 --> URI Class Initialized
INFO - 2021-03-26 20:58:27 --> Router Class Initialized
INFO - 2021-03-26 20:58:27 --> Router Class Initialized
INFO - 2021-03-26 20:58:27 --> Output Class Initialized
INFO - 2021-03-26 20:58:27 --> Output Class Initialized
INFO - 2021-03-26 20:58:27 --> Security Class Initialized
INFO - 2021-03-26 20:58:27 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:27 --> Input Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:27 --> Input Class Initialized
INFO - 2021-03-26 20:58:27 --> Language Class Initialized
INFO - 2021-03-26 20:58:27 --> Language Class Initialized
ERROR - 2021-03-26 20:58:27 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 20:58:27 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:58:27 --> Config Class Initialized
INFO - 2021-03-26 20:58:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:27 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:27 --> URI Class Initialized
INFO - 2021-03-26 20:58:27 --> Router Class Initialized
INFO - 2021-03-26 20:58:27 --> Output Class Initialized
INFO - 2021-03-26 20:58:27 --> Security Class Initialized
INFO - 2021-03-26 20:58:27 --> Config Class Initialized
INFO - 2021-03-26 20:58:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:27 --> Input Class Initialized
INFO - 2021-03-26 20:58:27 --> Language Class Initialized
DEBUG - 2021-03-26 20:58:27 --> UTF-8 Support Enabled
ERROR - 2021-03-26 20:58:27 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:58:27 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:27 --> URI Class Initialized
INFO - 2021-03-26 20:58:27 --> Router Class Initialized
INFO - 2021-03-26 20:58:27 --> Output Class Initialized
INFO - 2021-03-26 20:58:27 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:27 --> Input Class Initialized
INFO - 2021-03-26 20:58:27 --> Language Class Initialized
ERROR - 2021-03-26 20:58:27 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:58:35 --> Config Class Initialized
INFO - 2021-03-26 20:58:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:35 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:35 --> URI Class Initialized
INFO - 2021-03-26 20:58:35 --> Router Class Initialized
INFO - 2021-03-26 20:58:35 --> Output Class Initialized
INFO - 2021-03-26 20:58:35 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:35 --> Input Class Initialized
INFO - 2021-03-26 20:58:35 --> Language Class Initialized
INFO - 2021-03-26 20:58:35 --> Loader Class Initialized
INFO - 2021-03-26 20:58:35 --> Helper loaded: url_helper
INFO - 2021-03-26 20:58:35 --> Helper loaded: form_helper
INFO - 2021-03-26 20:58:35 --> Helper loaded: common_helper
INFO - 2021-03-26 20:58:35 --> Helper loaded: util_helper
INFO - 2021-03-26 20:58:35 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:58:35 --> Form Validation Class Initialized
INFO - 2021-03-26 20:58:35 --> Controller Class Initialized
INFO - 2021-03-26 20:58:35 --> Model Class Initialized
INFO - 2021-03-26 20:58:35 --> Model Class Initialized
INFO - 2021-03-26 20:58:35 --> Model Class Initialized
INFO - 2021-03-26 20:58:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:58:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:58:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/add.php
INFO - 2021-03-26 20:58:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:58:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:58:35 --> Final output sent to browser
DEBUG - 2021-03-26 20:58:35 --> Total execution time: 0.0418
INFO - 2021-03-26 20:58:35 --> Config Class Initialized
INFO - 2021-03-26 20:58:35 --> Hooks Class Initialized
INFO - 2021-03-26 20:58:35 --> Config Class Initialized
INFO - 2021-03-26 20:58:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:35 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:58:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:35 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:35 --> URI Class Initialized
INFO - 2021-03-26 20:58:35 --> URI Class Initialized
INFO - 2021-03-26 20:58:35 --> Router Class Initialized
INFO - 2021-03-26 20:58:35 --> Router Class Initialized
INFO - 2021-03-26 20:58:36 --> Output Class Initialized
INFO - 2021-03-26 20:58:36 --> Output Class Initialized
INFO - 2021-03-26 20:58:36 --> Security Class Initialized
INFO - 2021-03-26 20:58:36 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 20:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:36 --> Input Class Initialized
INFO - 2021-03-26 20:58:36 --> Input Class Initialized
INFO - 2021-03-26 20:58:36 --> Language Class Initialized
INFO - 2021-03-26 20:58:36 --> Language Class Initialized
ERROR - 2021-03-26 20:58:36 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-03-26 20:58:36 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:58:36 --> Config Class Initialized
INFO - 2021-03-26 20:58:36 --> Config Class Initialized
INFO - 2021-03-26 20:58:36 --> Hooks Class Initialized
INFO - 2021-03-26 20:58:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 20:58:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:36 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:36 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:36 --> URI Class Initialized
INFO - 2021-03-26 20:58:36 --> URI Class Initialized
INFO - 2021-03-26 20:58:36 --> Router Class Initialized
INFO - 2021-03-26 20:58:36 --> Router Class Initialized
INFO - 2021-03-26 20:58:36 --> Output Class Initialized
INFO - 2021-03-26 20:58:36 --> Output Class Initialized
INFO - 2021-03-26 20:58:36 --> Security Class Initialized
INFO - 2021-03-26 20:58:36 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 20:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:36 --> Input Class Initialized
INFO - 2021-03-26 20:58:36 --> Input Class Initialized
INFO - 2021-03-26 20:58:36 --> Language Class Initialized
INFO - 2021-03-26 20:58:36 --> Language Class Initialized
ERROR - 2021-03-26 20:58:36 --> 404 Page Not Found: administrator/User/dist
ERROR - 2021-03-26 20:58:36 --> 404 Page Not Found: administrator/User/dist
INFO - 2021-03-26 20:58:48 --> Config Class Initialized
INFO - 2021-03-26 20:58:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:48 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:48 --> URI Class Initialized
DEBUG - 2021-03-26 20:58:48 --> No URI present. Default controller set.
INFO - 2021-03-26 20:58:48 --> Router Class Initialized
INFO - 2021-03-26 20:58:48 --> Output Class Initialized
INFO - 2021-03-26 20:58:48 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:48 --> Input Class Initialized
INFO - 2021-03-26 20:58:48 --> Language Class Initialized
INFO - 2021-03-26 20:58:48 --> Loader Class Initialized
INFO - 2021-03-26 20:58:48 --> Helper loaded: url_helper
INFO - 2021-03-26 20:58:48 --> Helper loaded: form_helper
INFO - 2021-03-26 20:58:48 --> Helper loaded: common_helper
INFO - 2021-03-26 20:58:48 --> Helper loaded: util_helper
INFO - 2021-03-26 20:58:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:58:48 --> Form Validation Class Initialized
INFO - 2021-03-26 20:58:48 --> Controller Class Initialized
INFO - 2021-03-26 20:58:48 --> Model Class Initialized
INFO - 2021-03-26 20:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-26 20:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-26 20:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-26 20:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-26 20:58:48 --> Final output sent to browser
DEBUG - 2021-03-26 20:58:48 --> Total execution time: 0.0391
INFO - 2021-03-26 20:58:49 --> Config Class Initialized
INFO - 2021-03-26 20:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:49 --> URI Class Initialized
INFO - 2021-03-26 20:58:49 --> Router Class Initialized
INFO - 2021-03-26 20:58:49 --> Output Class Initialized
INFO - 2021-03-26 20:58:49 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:49 --> Input Class Initialized
INFO - 2021-03-26 20:58:49 --> Language Class Initialized
ERROR - 2021-03-26 20:58:49 --> 404 Page Not Found: Assets/js
INFO - 2021-03-26 20:58:49 --> Config Class Initialized
INFO - 2021-03-26 20:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:49 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:49 --> URI Class Initialized
INFO - 2021-03-26 20:58:49 --> Router Class Initialized
INFO - 2021-03-26 20:58:49 --> Output Class Initialized
INFO - 2021-03-26 20:58:49 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:49 --> Input Class Initialized
INFO - 2021-03-26 20:58:49 --> Language Class Initialized
ERROR - 2021-03-26 20:58:49 --> 404 Page Not Found: Assets/js
INFO - 2021-03-26 20:58:50 --> Config Class Initialized
INFO - 2021-03-26 20:58:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:50 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:50 --> URI Class Initialized
DEBUG - 2021-03-26 20:58:50 --> No URI present. Default controller set.
INFO - 2021-03-26 20:58:50 --> Router Class Initialized
INFO - 2021-03-26 20:58:50 --> Output Class Initialized
INFO - 2021-03-26 20:58:50 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:50 --> Input Class Initialized
INFO - 2021-03-26 20:58:50 --> Language Class Initialized
INFO - 2021-03-26 20:58:50 --> Loader Class Initialized
INFO - 2021-03-26 20:58:50 --> Helper loaded: url_helper
INFO - 2021-03-26 20:58:50 --> Helper loaded: form_helper
INFO - 2021-03-26 20:58:50 --> Helper loaded: common_helper
INFO - 2021-03-26 20:58:50 --> Helper loaded: util_helper
INFO - 2021-03-26 20:58:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:58:50 --> Form Validation Class Initialized
INFO - 2021-03-26 20:58:50 --> Controller Class Initialized
INFO - 2021-03-26 20:58:50 --> Model Class Initialized
INFO - 2021-03-26 20:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/header.php
INFO - 2021-03-26 20:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/login.php
INFO - 2021-03-26 20:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/footer.php
INFO - 2021-03-26 20:58:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\submitter/layouts/index.php
INFO - 2021-03-26 20:58:50 --> Final output sent to browser
DEBUG - 2021-03-26 20:58:50 --> Total execution time: 0.0323
INFO - 2021-03-26 20:58:53 --> Config Class Initialized
INFO - 2021-03-26 20:58:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:58:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:58:53 --> Utf8 Class Initialized
INFO - 2021-03-26 20:58:53 --> URI Class Initialized
INFO - 2021-03-26 20:58:53 --> Router Class Initialized
INFO - 2021-03-26 20:58:53 --> Output Class Initialized
INFO - 2021-03-26 20:58:53 --> Security Class Initialized
DEBUG - 2021-03-26 20:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:58:53 --> Input Class Initialized
INFO - 2021-03-26 20:58:53 --> Language Class Initialized
INFO - 2021-03-26 20:58:53 --> Loader Class Initialized
INFO - 2021-03-26 20:58:53 --> Helper loaded: url_helper
INFO - 2021-03-26 20:58:53 --> Helper loaded: form_helper
INFO - 2021-03-26 20:58:53 --> Helper loaded: common_helper
INFO - 2021-03-26 20:58:53 --> Helper loaded: util_helper
INFO - 2021-03-26 20:58:53 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:58:53 --> Form Validation Class Initialized
INFO - 2021-03-26 20:58:53 --> Controller Class Initialized
INFO - 2021-03-26 20:58:53 --> Model Class Initialized
INFO - 2021-03-26 20:58:53 --> Model Class Initialized
INFO - 2021-03-26 20:58:53 --> Model Class Initialized
INFO - 2021-03-26 20:58:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:58:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:58:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/add.php
INFO - 2021-03-26 20:58:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:58:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:58:53 --> Final output sent to browser
DEBUG - 2021-03-26 20:58:53 --> Total execution time: 0.0431
INFO - 2021-03-26 20:59:16 --> Config Class Initialized
INFO - 2021-03-26 20:59:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:16 --> Utf8 Class Initialized
INFO - 2021-03-26 20:59:16 --> URI Class Initialized
INFO - 2021-03-26 20:59:16 --> Router Class Initialized
INFO - 2021-03-26 20:59:16 --> Output Class Initialized
INFO - 2021-03-26 20:59:16 --> Security Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:16 --> Input Class Initialized
INFO - 2021-03-26 20:59:16 --> Language Class Initialized
INFO - 2021-03-26 20:59:16 --> Loader Class Initialized
INFO - 2021-03-26 20:59:16 --> Helper loaded: url_helper
INFO - 2021-03-26 20:59:16 --> Helper loaded: form_helper
INFO - 2021-03-26 20:59:16 --> Helper loaded: common_helper
INFO - 2021-03-26 20:59:16 --> Helper loaded: util_helper
INFO - 2021-03-26 20:59:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:59:16 --> Form Validation Class Initialized
INFO - 2021-03-26 20:59:16 --> Controller Class Initialized
INFO - 2021-03-26 20:59:16 --> Model Class Initialized
INFO - 2021-03-26 20:59:16 --> Model Class Initialized
INFO - 2021-03-26 20:59:16 --> Model Class Initialized
INFO - 2021-03-26 20:59:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 20:59:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 20:59:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 20:59:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 20:59:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 20:59:16 --> Final output sent to browser
DEBUG - 2021-03-26 20:59:16 --> Total execution time: 0.0459
INFO - 2021-03-26 20:59:16 --> Config Class Initialized
INFO - 2021-03-26 20:59:16 --> Config Class Initialized
INFO - 2021-03-26 20:59:16 --> Hooks Class Initialized
INFO - 2021-03-26 20:59:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:16 --> Utf8 Class Initialized
INFO - 2021-03-26 20:59:16 --> URI Class Initialized
DEBUG - 2021-03-26 20:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:16 --> Utf8 Class Initialized
INFO - 2021-03-26 20:59:16 --> Router Class Initialized
INFO - 2021-03-26 20:59:16 --> Output Class Initialized
INFO - 2021-03-26 20:59:16 --> Security Class Initialized
INFO - 2021-03-26 20:59:16 --> URI Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:16 --> Input Class Initialized
INFO - 2021-03-26 20:59:16 --> Language Class Initialized
INFO - 2021-03-26 20:59:16 --> Router Class Initialized
ERROR - 2021-03-26 20:59:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:59:16 --> Output Class Initialized
INFO - 2021-03-26 20:59:16 --> Security Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:16 --> Input Class Initialized
INFO - 2021-03-26 20:59:16 --> Language Class Initialized
ERROR - 2021-03-26 20:59:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:59:16 --> Config Class Initialized
INFO - 2021-03-26 20:59:16 --> Hooks Class Initialized
INFO - 2021-03-26 20:59:16 --> Config Class Initialized
INFO - 2021-03-26 20:59:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:16 --> Utf8 Class Initialized
DEBUG - 2021-03-26 20:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:16 --> URI Class Initialized
INFO - 2021-03-26 20:59:16 --> Utf8 Class Initialized
INFO - 2021-03-26 20:59:16 --> URI Class Initialized
INFO - 2021-03-26 20:59:16 --> Router Class Initialized
INFO - 2021-03-26 20:59:16 --> Output Class Initialized
INFO - 2021-03-26 20:59:16 --> Security Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:16 --> Input Class Initialized
INFO - 2021-03-26 20:59:16 --> Language Class Initialized
ERROR - 2021-03-26 20:59:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:59:16 --> Router Class Initialized
INFO - 2021-03-26 20:59:16 --> Output Class Initialized
INFO - 2021-03-26 20:59:16 --> Security Class Initialized
DEBUG - 2021-03-26 20:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:16 --> Input Class Initialized
INFO - 2021-03-26 20:59:16 --> Language Class Initialized
ERROR - 2021-03-26 20:59:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 20:59:23 --> Config Class Initialized
INFO - 2021-03-26 20:59:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 20:59:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 20:59:23 --> Utf8 Class Initialized
INFO - 2021-03-26 20:59:23 --> URI Class Initialized
INFO - 2021-03-26 20:59:23 --> Router Class Initialized
INFO - 2021-03-26 20:59:23 --> Output Class Initialized
INFO - 2021-03-26 20:59:23 --> Security Class Initialized
DEBUG - 2021-03-26 20:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 20:59:23 --> Input Class Initialized
INFO - 2021-03-26 20:59:23 --> Language Class Initialized
INFO - 2021-03-26 20:59:23 --> Loader Class Initialized
INFO - 2021-03-26 20:59:23 --> Helper loaded: url_helper
INFO - 2021-03-26 20:59:23 --> Helper loaded: form_helper
INFO - 2021-03-26 20:59:23 --> Helper loaded: common_helper
INFO - 2021-03-26 20:59:23 --> Helper loaded: util_helper
INFO - 2021-03-26 20:59:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 20:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 20:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 20:59:23 --> Form Validation Class Initialized
INFO - 2021-03-26 20:59:23 --> Controller Class Initialized
INFO - 2021-03-26 20:59:23 --> Model Class Initialized
INFO - 2021-03-26 20:59:23 --> Model Class Initialized
INFO - 2021-03-26 20:59:23 --> Model Class Initialized
INFO - 2021-03-26 20:59:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 20:59:23 --> Final output sent to browser
DEBUG - 2021-03-26 20:59:23 --> Total execution time: 0.0369
INFO - 2021-03-26 21:20:49 --> Config Class Initialized
INFO - 2021-03-26 21:20:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:20:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:49 --> URI Class Initialized
INFO - 2021-03-26 21:20:49 --> Router Class Initialized
INFO - 2021-03-26 21:20:49 --> Output Class Initialized
INFO - 2021-03-26 21:20:49 --> Security Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:49 --> Input Class Initialized
INFO - 2021-03-26 21:20:49 --> Language Class Initialized
INFO - 2021-03-26 21:20:49 --> Loader Class Initialized
INFO - 2021-03-26 21:20:49 --> Helper loaded: url_helper
INFO - 2021-03-26 21:20:49 --> Helper loaded: form_helper
INFO - 2021-03-26 21:20:49 --> Helper loaded: common_helper
INFO - 2021-03-26 21:20:49 --> Helper loaded: util_helper
INFO - 2021-03-26 21:20:49 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:20:49 --> Form Validation Class Initialized
INFO - 2021-03-26 21:20:49 --> Controller Class Initialized
INFO - 2021-03-26 21:20:49 --> Model Class Initialized
INFO - 2021-03-26 21:20:49 --> Model Class Initialized
INFO - 2021-03-26 21:20:49 --> Model Class Initialized
INFO - 2021-03-26 21:20:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:20:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:20:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:20:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:20:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:20:49 --> Final output sent to browser
DEBUG - 2021-03-26 21:20:49 --> Total execution time: 0.0437
INFO - 2021-03-26 21:20:49 --> Config Class Initialized
INFO - 2021-03-26 21:20:49 --> Hooks Class Initialized
INFO - 2021-03-26 21:20:49 --> Config Class Initialized
INFO - 2021-03-26 21:20:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:20:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:49 --> URI Class Initialized
DEBUG - 2021-03-26 21:20:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:49 --> Router Class Initialized
INFO - 2021-03-26 21:20:49 --> URI Class Initialized
INFO - 2021-03-26 21:20:49 --> Output Class Initialized
INFO - 2021-03-26 21:20:49 --> Router Class Initialized
INFO - 2021-03-26 21:20:49 --> Security Class Initialized
INFO - 2021-03-26 21:20:49 --> Output Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:49 --> Input Class Initialized
INFO - 2021-03-26 21:20:49 --> Security Class Initialized
INFO - 2021-03-26 21:20:49 --> Language Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:49 --> Input Class Initialized
INFO - 2021-03-26 21:20:49 --> Language Class Initialized
ERROR - 2021-03-26 21:20:49 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 21:20:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:20:49 --> Config Class Initialized
INFO - 2021-03-26 21:20:49 --> Hooks Class Initialized
INFO - 2021-03-26 21:20:49 --> Config Class Initialized
INFO - 2021-03-26 21:20:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:20:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:49 --> URI Class Initialized
DEBUG - 2021-03-26 21:20:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:49 --> URI Class Initialized
INFO - 2021-03-26 21:20:49 --> Router Class Initialized
INFO - 2021-03-26 21:20:49 --> Output Class Initialized
INFO - 2021-03-26 21:20:49 --> Router Class Initialized
INFO - 2021-03-26 21:20:49 --> Security Class Initialized
INFO - 2021-03-26 21:20:49 --> Output Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:49 --> Input Class Initialized
INFO - 2021-03-26 21:20:49 --> Security Class Initialized
INFO - 2021-03-26 21:20:49 --> Language Class Initialized
DEBUG - 2021-03-26 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:49 --> Input Class Initialized
ERROR - 2021-03-26 21:20:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:20:49 --> Language Class Initialized
ERROR - 2021-03-26 21:20:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:20:55 --> Config Class Initialized
INFO - 2021-03-26 21:20:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:20:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:20:55 --> Utf8 Class Initialized
INFO - 2021-03-26 21:20:55 --> URI Class Initialized
INFO - 2021-03-26 21:20:55 --> Router Class Initialized
INFO - 2021-03-26 21:20:55 --> Output Class Initialized
INFO - 2021-03-26 21:20:55 --> Security Class Initialized
DEBUG - 2021-03-26 21:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:20:55 --> Input Class Initialized
INFO - 2021-03-26 21:20:55 --> Language Class Initialized
INFO - 2021-03-26 21:20:55 --> Loader Class Initialized
INFO - 2021-03-26 21:20:55 --> Helper loaded: url_helper
INFO - 2021-03-26 21:20:55 --> Helper loaded: form_helper
INFO - 2021-03-26 21:20:55 --> Helper loaded: common_helper
INFO - 2021-03-26 21:20:55 --> Helper loaded: util_helper
INFO - 2021-03-26 21:20:55 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:20:55 --> Form Validation Class Initialized
INFO - 2021-03-26 21:20:55 --> Controller Class Initialized
INFO - 2021-03-26 21:20:55 --> Model Class Initialized
INFO - 2021-03-26 21:20:55 --> Model Class Initialized
INFO - 2021-03-26 21:20:55 --> Model Class Initialized
INFO - 2021-03-26 21:20:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 21:20:55 --> Final output sent to browser
DEBUG - 2021-03-26 21:20:55 --> Total execution time: 0.0359
INFO - 2021-03-26 21:30:03 --> Config Class Initialized
INFO - 2021-03-26 21:30:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:03 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:03 --> URI Class Initialized
INFO - 2021-03-26 21:30:03 --> Router Class Initialized
INFO - 2021-03-26 21:30:03 --> Output Class Initialized
INFO - 2021-03-26 21:30:03 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:03 --> Input Class Initialized
INFO - 2021-03-26 21:30:03 --> Language Class Initialized
INFO - 2021-03-26 21:30:03 --> Loader Class Initialized
INFO - 2021-03-26 21:30:03 --> Helper loaded: url_helper
INFO - 2021-03-26 21:30:03 --> Helper loaded: form_helper
INFO - 2021-03-26 21:30:03 --> Helper loaded: common_helper
INFO - 2021-03-26 21:30:03 --> Helper loaded: util_helper
INFO - 2021-03-26 21:30:03 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:30:03 --> Form Validation Class Initialized
INFO - 2021-03-26 21:30:03 --> Controller Class Initialized
INFO - 2021-03-26 21:30:03 --> Model Class Initialized
INFO - 2021-03-26 21:30:03 --> Model Class Initialized
INFO - 2021-03-26 21:30:03 --> Model Class Initialized
INFO - 2021-03-26 21:30:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:30:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:30:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:30:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:30:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:30:03 --> Final output sent to browser
DEBUG - 2021-03-26 21:30:03 --> Total execution time: 0.2432
INFO - 2021-03-26 21:30:03 --> Config Class Initialized
INFO - 2021-03-26 21:30:03 --> Hooks Class Initialized
INFO - 2021-03-26 21:30:03 --> Config Class Initialized
INFO - 2021-03-26 21:30:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 21:30:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:03 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:03 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:03 --> URI Class Initialized
INFO - 2021-03-26 21:30:03 --> URI Class Initialized
INFO - 2021-03-26 21:30:03 --> Router Class Initialized
INFO - 2021-03-26 21:30:03 --> Output Class Initialized
INFO - 2021-03-26 21:30:03 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:03 --> Input Class Initialized
INFO - 2021-03-26 21:30:03 --> Language Class Initialized
INFO - 2021-03-26 21:30:03 --> Router Class Initialized
INFO - 2021-03-26 21:30:03 --> Output Class Initialized
INFO - 2021-03-26 21:30:03 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:03 --> Input Class Initialized
INFO - 2021-03-26 21:30:03 --> Language Class Initialized
ERROR - 2021-03-26 21:30:03 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 21:30:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:30:03 --> Config Class Initialized
INFO - 2021-03-26 21:30:03 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:03 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:03 --> URI Class Initialized
INFO - 2021-03-26 21:30:03 --> Router Class Initialized
INFO - 2021-03-26 21:30:03 --> Config Class Initialized
INFO - 2021-03-26 21:30:03 --> Hooks Class Initialized
INFO - 2021-03-26 21:30:03 --> Output Class Initialized
DEBUG - 2021-03-26 21:30:03 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:03 --> Security Class Initialized
INFO - 2021-03-26 21:30:03 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:03 --> URI Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:03 --> Input Class Initialized
INFO - 2021-03-26 21:30:03 --> Language Class Initialized
INFO - 2021-03-26 21:30:03 --> Router Class Initialized
ERROR - 2021-03-26 21:30:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:30:03 --> Output Class Initialized
INFO - 2021-03-26 21:30:03 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:03 --> Input Class Initialized
INFO - 2021-03-26 21:30:03 --> Language Class Initialized
ERROR - 2021-03-26 21:30:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:30:16 --> Config Class Initialized
INFO - 2021-03-26 21:30:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:16 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:16 --> URI Class Initialized
INFO - 2021-03-26 21:30:16 --> Router Class Initialized
INFO - 2021-03-26 21:30:16 --> Output Class Initialized
INFO - 2021-03-26 21:30:16 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:16 --> Input Class Initialized
INFO - 2021-03-26 21:30:16 --> Language Class Initialized
INFO - 2021-03-26 21:30:16 --> Loader Class Initialized
INFO - 2021-03-26 21:30:16 --> Helper loaded: url_helper
INFO - 2021-03-26 21:30:16 --> Helper loaded: form_helper
INFO - 2021-03-26 21:30:16 --> Helper loaded: common_helper
INFO - 2021-03-26 21:30:16 --> Helper loaded: util_helper
INFO - 2021-03-26 21:30:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:30:16 --> Form Validation Class Initialized
INFO - 2021-03-26 21:30:16 --> Controller Class Initialized
INFO - 2021-03-26 21:30:16 --> Model Class Initialized
INFO - 2021-03-26 21:30:16 --> Model Class Initialized
INFO - 2021-03-26 21:30:16 --> Model Class Initialized
INFO - 2021-03-26 21:30:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:30:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:30:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:30:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:30:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:30:16 --> Final output sent to browser
DEBUG - 2021-03-26 21:30:16 --> Total execution time: 0.0415
INFO - 2021-03-26 21:30:16 --> Config Class Initialized
INFO - 2021-03-26 21:30:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:16 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:16 --> URI Class Initialized
INFO - 2021-03-26 21:30:16 --> Router Class Initialized
INFO - 2021-03-26 21:30:16 --> Output Class Initialized
INFO - 2021-03-26 21:30:16 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:16 --> Input Class Initialized
INFO - 2021-03-26 21:30:16 --> Config Class Initialized
INFO - 2021-03-26 21:30:16 --> Language Class Initialized
INFO - 2021-03-26 21:30:16 --> Hooks Class Initialized
ERROR - 2021-03-26 21:30:16 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 21:30:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:16 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:16 --> URI Class Initialized
INFO - 2021-03-26 21:30:16 --> Router Class Initialized
INFO - 2021-03-26 21:30:16 --> Output Class Initialized
INFO - 2021-03-26 21:30:16 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:16 --> Input Class Initialized
INFO - 2021-03-26 21:30:16 --> Language Class Initialized
ERROR - 2021-03-26 21:30:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:30:16 --> Config Class Initialized
INFO - 2021-03-26 21:30:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:16 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:16 --> Config Class Initialized
INFO - 2021-03-26 21:30:16 --> Hooks Class Initialized
INFO - 2021-03-26 21:30:16 --> URI Class Initialized
DEBUG - 2021-03-26 21:30:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:16 --> Router Class Initialized
INFO - 2021-03-26 21:30:16 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:16 --> URI Class Initialized
INFO - 2021-03-26 21:30:16 --> Output Class Initialized
INFO - 2021-03-26 21:30:16 --> Router Class Initialized
INFO - 2021-03-26 21:30:16 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:16 --> Output Class Initialized
INFO - 2021-03-26 21:30:16 --> Input Class Initialized
INFO - 2021-03-26 21:30:16 --> Language Class Initialized
INFO - 2021-03-26 21:30:16 --> Security Class Initialized
ERROR - 2021-03-26 21:30:16 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 21:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:16 --> Input Class Initialized
INFO - 2021-03-26 21:30:16 --> Language Class Initialized
ERROR - 2021-03-26 21:30:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:30:23 --> Config Class Initialized
INFO - 2021-03-26 21:30:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:30:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:30:23 --> Utf8 Class Initialized
INFO - 2021-03-26 21:30:23 --> URI Class Initialized
INFO - 2021-03-26 21:30:23 --> Router Class Initialized
INFO - 2021-03-26 21:30:23 --> Output Class Initialized
INFO - 2021-03-26 21:30:23 --> Security Class Initialized
DEBUG - 2021-03-26 21:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:30:23 --> Input Class Initialized
INFO - 2021-03-26 21:30:23 --> Language Class Initialized
INFO - 2021-03-26 21:30:23 --> Loader Class Initialized
INFO - 2021-03-26 21:30:23 --> Helper loaded: url_helper
INFO - 2021-03-26 21:30:23 --> Helper loaded: form_helper
INFO - 2021-03-26 21:30:23 --> Helper loaded: common_helper
INFO - 2021-03-26 21:30:23 --> Helper loaded: util_helper
INFO - 2021-03-26 21:30:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:30:23 --> Form Validation Class Initialized
INFO - 2021-03-26 21:30:23 --> Controller Class Initialized
INFO - 2021-03-26 21:30:23 --> Model Class Initialized
INFO - 2021-03-26 21:30:23 --> Model Class Initialized
INFO - 2021-03-26 21:30:23 --> Model Class Initialized
INFO - 2021-03-26 21:30:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 21:30:23 --> Final output sent to browser
DEBUG - 2021-03-26 21:30:23 --> Total execution time: 0.0757
INFO - 2021-03-26 21:32:08 --> Config Class Initialized
INFO - 2021-03-26 21:32:08 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:32:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:08 --> Utf8 Class Initialized
INFO - 2021-03-26 21:32:08 --> URI Class Initialized
INFO - 2021-03-26 21:32:08 --> Router Class Initialized
INFO - 2021-03-26 21:32:08 --> Output Class Initialized
INFO - 2021-03-26 21:32:08 --> Security Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:08 --> Input Class Initialized
INFO - 2021-03-26 21:32:08 --> Language Class Initialized
INFO - 2021-03-26 21:32:08 --> Loader Class Initialized
INFO - 2021-03-26 21:32:08 --> Helper loaded: url_helper
INFO - 2021-03-26 21:32:08 --> Helper loaded: form_helper
INFO - 2021-03-26 21:32:08 --> Helper loaded: common_helper
INFO - 2021-03-26 21:32:08 --> Helper loaded: util_helper
INFO - 2021-03-26 21:32:08 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:32:08 --> Form Validation Class Initialized
INFO - 2021-03-26 21:32:08 --> Controller Class Initialized
INFO - 2021-03-26 21:32:08 --> Model Class Initialized
INFO - 2021-03-26 21:32:08 --> Model Class Initialized
INFO - 2021-03-26 21:32:08 --> Model Class Initialized
INFO - 2021-03-26 21:32:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:32:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:32:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:32:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:32:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:32:08 --> Final output sent to browser
DEBUG - 2021-03-26 21:32:08 --> Total execution time: 0.0526
INFO - 2021-03-26 21:32:08 --> Config Class Initialized
INFO - 2021-03-26 21:32:08 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:32:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:08 --> Utf8 Class Initialized
INFO - 2021-03-26 21:32:08 --> URI Class Initialized
INFO - 2021-03-26 21:32:08 --> Config Class Initialized
INFO - 2021-03-26 21:32:08 --> Hooks Class Initialized
INFO - 2021-03-26 21:32:08 --> Router Class Initialized
INFO - 2021-03-26 21:32:08 --> Output Class Initialized
DEBUG - 2021-03-26 21:32:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:08 --> Utf8 Class Initialized
INFO - 2021-03-26 21:32:08 --> Security Class Initialized
INFO - 2021-03-26 21:32:08 --> URI Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:08 --> Input Class Initialized
INFO - 2021-03-26 21:32:08 --> Router Class Initialized
INFO - 2021-03-26 21:32:08 --> Language Class Initialized
INFO - 2021-03-26 21:32:08 --> Output Class Initialized
ERROR - 2021-03-26 21:32:08 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:32:08 --> Security Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:08 --> Input Class Initialized
INFO - 2021-03-26 21:32:08 --> Language Class Initialized
ERROR - 2021-03-26 21:32:08 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:32:08 --> Config Class Initialized
INFO - 2021-03-26 21:32:08 --> Hooks Class Initialized
INFO - 2021-03-26 21:32:08 --> Config Class Initialized
INFO - 2021-03-26 21:32:08 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:32:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:08 --> Utf8 Class Initialized
DEBUG - 2021-03-26 21:32:08 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:08 --> Utf8 Class Initialized
INFO - 2021-03-26 21:32:08 --> URI Class Initialized
INFO - 2021-03-26 21:32:08 --> URI Class Initialized
INFO - 2021-03-26 21:32:08 --> Router Class Initialized
INFO - 2021-03-26 21:32:08 --> Router Class Initialized
INFO - 2021-03-26 21:32:08 --> Output Class Initialized
INFO - 2021-03-26 21:32:08 --> Output Class Initialized
INFO - 2021-03-26 21:32:08 --> Security Class Initialized
INFO - 2021-03-26 21:32:08 --> Security Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:08 --> Input Class Initialized
DEBUG - 2021-03-26 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:08 --> Language Class Initialized
INFO - 2021-03-26 21:32:08 --> Input Class Initialized
INFO - 2021-03-26 21:32:08 --> Language Class Initialized
ERROR - 2021-03-26 21:32:08 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 21:32:08 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:32:12 --> Config Class Initialized
INFO - 2021-03-26 21:32:12 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:32:12 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:32:12 --> Utf8 Class Initialized
INFO - 2021-03-26 21:32:12 --> URI Class Initialized
INFO - 2021-03-26 21:32:12 --> Router Class Initialized
INFO - 2021-03-26 21:32:12 --> Output Class Initialized
INFO - 2021-03-26 21:32:12 --> Security Class Initialized
DEBUG - 2021-03-26 21:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:32:12 --> Input Class Initialized
INFO - 2021-03-26 21:32:12 --> Language Class Initialized
INFO - 2021-03-26 21:32:12 --> Loader Class Initialized
INFO - 2021-03-26 21:32:12 --> Helper loaded: url_helper
INFO - 2021-03-26 21:32:12 --> Helper loaded: form_helper
INFO - 2021-03-26 21:32:12 --> Helper loaded: common_helper
INFO - 2021-03-26 21:32:12 --> Helper loaded: util_helper
INFO - 2021-03-26 21:32:12 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:32:12 --> Form Validation Class Initialized
INFO - 2021-03-26 21:32:12 --> Controller Class Initialized
INFO - 2021-03-26 21:32:12 --> Model Class Initialized
INFO - 2021-03-26 21:32:12 --> Model Class Initialized
INFO - 2021-03-26 21:32:12 --> Model Class Initialized
INFO - 2021-03-26 21:32:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 21:32:12 --> Final output sent to browser
DEBUG - 2021-03-26 21:32:12 --> Total execution time: 0.0462
INFO - 2021-03-26 21:33:04 --> Config Class Initialized
INFO - 2021-03-26 21:33:04 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:33:04 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:33:04 --> Utf8 Class Initialized
INFO - 2021-03-26 21:33:04 --> URI Class Initialized
INFO - 2021-03-26 21:33:04 --> Router Class Initialized
INFO - 2021-03-26 21:33:04 --> Output Class Initialized
INFO - 2021-03-26 21:33:04 --> Security Class Initialized
DEBUG - 2021-03-26 21:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:33:04 --> Input Class Initialized
INFO - 2021-03-26 21:33:04 --> Language Class Initialized
INFO - 2021-03-26 21:33:04 --> Loader Class Initialized
INFO - 2021-03-26 21:33:04 --> Helper loaded: url_helper
INFO - 2021-03-26 21:33:04 --> Helper loaded: form_helper
INFO - 2021-03-26 21:33:04 --> Helper loaded: common_helper
INFO - 2021-03-26 21:33:04 --> Helper loaded: util_helper
INFO - 2021-03-26 21:33:04 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:33:04 --> Form Validation Class Initialized
INFO - 2021-03-26 21:33:04 --> Controller Class Initialized
INFO - 2021-03-26 21:33:04 --> Model Class Initialized
INFO - 2021-03-26 21:33:04 --> Model Class Initialized
INFO - 2021-03-26 21:33:04 --> Model Class Initialized
INFO - 2021-03-26 21:33:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:33:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:33:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:33:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:33:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:33:04 --> Final output sent to browser
DEBUG - 2021-03-26 21:33:04 --> Total execution time: 0.0479
INFO - 2021-03-26 21:48:36 --> Config Class Initialized
INFO - 2021-03-26 21:48:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:48:36 --> Utf8 Class Initialized
INFO - 2021-03-26 21:48:36 --> URI Class Initialized
INFO - 2021-03-26 21:48:36 --> Router Class Initialized
INFO - 2021-03-26 21:48:36 --> Output Class Initialized
INFO - 2021-03-26 21:48:36 --> Security Class Initialized
DEBUG - 2021-03-26 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:48:36 --> Input Class Initialized
INFO - 2021-03-26 21:48:36 --> Language Class Initialized
INFO - 2021-03-26 21:48:36 --> Loader Class Initialized
INFO - 2021-03-26 21:48:36 --> Helper loaded: url_helper
INFO - 2021-03-26 21:48:36 --> Helper loaded: form_helper
INFO - 2021-03-26 21:48:36 --> Helper loaded: common_helper
INFO - 2021-03-26 21:48:36 --> Helper loaded: util_helper
INFO - 2021-03-26 21:48:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:48:36 --> Form Validation Class Initialized
INFO - 2021-03-26 21:48:36 --> Controller Class Initialized
INFO - 2021-03-26 21:48:36 --> Model Class Initialized
INFO - 2021-03-26 21:48:36 --> Model Class Initialized
INFO - 2021-03-26 21:48:36 --> Model Class Initialized
INFO - 2021-03-26 21:48:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:48:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:48:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:48:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:48:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:48:36 --> Final output sent to browser
DEBUG - 2021-03-26 21:48:36 --> Total execution time: 0.0472
INFO - 2021-03-26 21:48:36 --> Config Class Initialized
INFO - 2021-03-26 21:48:36 --> Hooks Class Initialized
INFO - 2021-03-26 21:48:36 --> Config Class Initialized
INFO - 2021-03-26 21:48:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:48:36 --> Utf8 Class Initialized
DEBUG - 2021-03-26 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:48:36 --> Utf8 Class Initialized
INFO - 2021-03-26 21:48:36 --> URI Class Initialized
INFO - 2021-03-26 21:48:36 --> URI Class Initialized
INFO - 2021-03-26 21:48:36 --> Router Class Initialized
INFO - 2021-03-26 21:48:36 --> Output Class Initialized
INFO - 2021-03-26 21:48:36 --> Router Class Initialized
INFO - 2021-03-26 21:48:36 --> Security Class Initialized
INFO - 2021-03-26 21:48:36 --> Output Class Initialized
DEBUG - 2021-03-26 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:48:36 --> Input Class Initialized
INFO - 2021-03-26 21:48:36 --> Language Class Initialized
INFO - 2021-03-26 21:48:36 --> Security Class Initialized
ERROR - 2021-03-26 21:48:36 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:48:36 --> Input Class Initialized
INFO - 2021-03-26 21:48:36 --> Language Class Initialized
ERROR - 2021-03-26 21:48:36 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:48:36 --> Config Class Initialized
INFO - 2021-03-26 21:48:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:48:36 --> Utf8 Class Initialized
INFO - 2021-03-26 21:48:36 --> URI Class Initialized
INFO - 2021-03-26 21:48:36 --> Router Class Initialized
INFO - 2021-03-26 21:48:36 --> Output Class Initialized
INFO - 2021-03-26 21:48:36 --> Security Class Initialized
DEBUG - 2021-03-26 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:48:36 --> Input Class Initialized
INFO - 2021-03-26 21:48:36 --> Language Class Initialized
INFO - 2021-03-26 21:48:36 --> Config Class Initialized
INFO - 2021-03-26 21:48:36 --> Hooks Class Initialized
ERROR - 2021-03-26 21:48:36 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:48:36 --> Utf8 Class Initialized
INFO - 2021-03-26 21:48:36 --> URI Class Initialized
INFO - 2021-03-26 21:48:36 --> Router Class Initialized
INFO - 2021-03-26 21:48:36 --> Output Class Initialized
INFO - 2021-03-26 21:48:36 --> Security Class Initialized
DEBUG - 2021-03-26 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:48:36 --> Input Class Initialized
INFO - 2021-03-26 21:48:36 --> Language Class Initialized
ERROR - 2021-03-26 21:48:36 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:49:01 --> Config Class Initialized
INFO - 2021-03-26 21:49:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:49:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:49:01 --> Utf8 Class Initialized
INFO - 2021-03-26 21:49:01 --> URI Class Initialized
INFO - 2021-03-26 21:49:01 --> Router Class Initialized
INFO - 2021-03-26 21:49:01 --> Output Class Initialized
INFO - 2021-03-26 21:49:01 --> Security Class Initialized
DEBUG - 2021-03-26 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:49:01 --> Input Class Initialized
INFO - 2021-03-26 21:49:01 --> Language Class Initialized
INFO - 2021-03-26 21:49:01 --> Loader Class Initialized
INFO - 2021-03-26 21:49:01 --> Helper loaded: url_helper
INFO - 2021-03-26 21:49:01 --> Helper loaded: form_helper
INFO - 2021-03-26 21:49:01 --> Helper loaded: common_helper
INFO - 2021-03-26 21:49:01 --> Helper loaded: util_helper
INFO - 2021-03-26 21:49:01 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:49:01 --> Form Validation Class Initialized
INFO - 2021-03-26 21:49:01 --> Controller Class Initialized
INFO - 2021-03-26 21:49:01 --> Model Class Initialized
INFO - 2021-03-26 21:49:01 --> Model Class Initialized
INFO - 2021-03-26 21:49:01 --> Model Class Initialized
ERROR - 2021-03-26 21:49:01 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\robust\php\application\views\admin\permission\list.php 96
INFO - 2021-03-26 21:49:35 --> Config Class Initialized
INFO - 2021-03-26 21:49:35 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:49:35 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:49:35 --> Utf8 Class Initialized
INFO - 2021-03-26 21:49:35 --> URI Class Initialized
INFO - 2021-03-26 21:49:35 --> Router Class Initialized
INFO - 2021-03-26 21:49:35 --> Output Class Initialized
INFO - 2021-03-26 21:49:35 --> Security Class Initialized
DEBUG - 2021-03-26 21:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:49:35 --> Input Class Initialized
INFO - 2021-03-26 21:49:35 --> Language Class Initialized
INFO - 2021-03-26 21:49:35 --> Loader Class Initialized
INFO - 2021-03-26 21:49:35 --> Helper loaded: url_helper
INFO - 2021-03-26 21:49:35 --> Helper loaded: form_helper
INFO - 2021-03-26 21:49:35 --> Helper loaded: common_helper
INFO - 2021-03-26 21:49:35 --> Helper loaded: util_helper
INFO - 2021-03-26 21:49:35 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:49:35 --> Form Validation Class Initialized
INFO - 2021-03-26 21:49:35 --> Controller Class Initialized
INFO - 2021-03-26 21:49:35 --> Model Class Initialized
INFO - 2021-03-26 21:49:35 --> Model Class Initialized
INFO - 2021-03-26 21:49:35 --> Model Class Initialized
ERROR - 2021-03-26 21:49:35 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\robust\php\application\views\admin\permission\list.php 96
INFO - 2021-03-26 21:50:13 --> Config Class Initialized
INFO - 2021-03-26 21:50:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:50:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:13 --> Utf8 Class Initialized
INFO - 2021-03-26 21:50:13 --> URI Class Initialized
INFO - 2021-03-26 21:50:13 --> Router Class Initialized
INFO - 2021-03-26 21:50:13 --> Output Class Initialized
INFO - 2021-03-26 21:50:13 --> Security Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:13 --> Input Class Initialized
INFO - 2021-03-26 21:50:13 --> Language Class Initialized
INFO - 2021-03-26 21:50:13 --> Loader Class Initialized
INFO - 2021-03-26 21:50:13 --> Helper loaded: url_helper
INFO - 2021-03-26 21:50:13 --> Helper loaded: form_helper
INFO - 2021-03-26 21:50:13 --> Helper loaded: common_helper
INFO - 2021-03-26 21:50:13 --> Helper loaded: util_helper
INFO - 2021-03-26 21:50:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:50:13 --> Form Validation Class Initialized
INFO - 2021-03-26 21:50:13 --> Controller Class Initialized
INFO - 2021-03-26 21:50:13 --> Model Class Initialized
INFO - 2021-03-26 21:50:13 --> Model Class Initialized
INFO - 2021-03-26 21:50:13 --> Model Class Initialized
INFO - 2021-03-26 21:50:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:50:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:50:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:50:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:50:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:50:13 --> Final output sent to browser
DEBUG - 2021-03-26 21:50:13 --> Total execution time: 0.0580
INFO - 2021-03-26 21:50:13 --> Config Class Initialized
INFO - 2021-03-26 21:50:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:50:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:13 --> Utf8 Class Initialized
INFO - 2021-03-26 21:50:13 --> URI Class Initialized
INFO - 2021-03-26 21:50:13 --> Config Class Initialized
INFO - 2021-03-26 21:50:13 --> Hooks Class Initialized
INFO - 2021-03-26 21:50:13 --> Router Class Initialized
DEBUG - 2021-03-26 21:50:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:13 --> Output Class Initialized
INFO - 2021-03-26 21:50:13 --> Utf8 Class Initialized
INFO - 2021-03-26 21:50:13 --> Security Class Initialized
INFO - 2021-03-26 21:50:13 --> URI Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:13 --> Input Class Initialized
INFO - 2021-03-26 21:50:13 --> Router Class Initialized
INFO - 2021-03-26 21:50:13 --> Language Class Initialized
ERROR - 2021-03-26 21:50:13 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:50:13 --> Output Class Initialized
INFO - 2021-03-26 21:50:13 --> Security Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:13 --> Input Class Initialized
INFO - 2021-03-26 21:50:13 --> Language Class Initialized
ERROR - 2021-03-26 21:50:13 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:50:13 --> Config Class Initialized
INFO - 2021-03-26 21:50:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:50:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:13 --> Utf8 Class Initialized
INFO - 2021-03-26 21:50:13 --> URI Class Initialized
INFO - 2021-03-26 21:50:13 --> Router Class Initialized
INFO - 2021-03-26 21:50:13 --> Output Class Initialized
INFO - 2021-03-26 21:50:13 --> Security Class Initialized
INFO - 2021-03-26 21:50:13 --> Config Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:13 --> Hooks Class Initialized
INFO - 2021-03-26 21:50:13 --> Input Class Initialized
INFO - 2021-03-26 21:50:13 --> Language Class Initialized
DEBUG - 2021-03-26 21:50:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:13 --> Utf8 Class Initialized
ERROR - 2021-03-26 21:50:13 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:50:13 --> URI Class Initialized
INFO - 2021-03-26 21:50:13 --> Router Class Initialized
INFO - 2021-03-26 21:50:13 --> Output Class Initialized
INFO - 2021-03-26 21:50:13 --> Security Class Initialized
DEBUG - 2021-03-26 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:13 --> Input Class Initialized
INFO - 2021-03-26 21:50:13 --> Language Class Initialized
ERROR - 2021-03-26 21:50:13 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:50:27 --> Config Class Initialized
INFO - 2021-03-26 21:50:27 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:50:27 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:50:27 --> Utf8 Class Initialized
INFO - 2021-03-26 21:50:27 --> URI Class Initialized
INFO - 2021-03-26 21:50:27 --> Router Class Initialized
INFO - 2021-03-26 21:50:27 --> Output Class Initialized
INFO - 2021-03-26 21:50:27 --> Security Class Initialized
DEBUG - 2021-03-26 21:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:50:27 --> Input Class Initialized
INFO - 2021-03-26 21:50:27 --> Language Class Initialized
INFO - 2021-03-26 21:50:27 --> Loader Class Initialized
INFO - 2021-03-26 21:50:27 --> Helper loaded: url_helper
INFO - 2021-03-26 21:50:27 --> Helper loaded: form_helper
INFO - 2021-03-26 21:50:27 --> Helper loaded: common_helper
INFO - 2021-03-26 21:50:27 --> Helper loaded: util_helper
INFO - 2021-03-26 21:50:27 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:50:27 --> Form Validation Class Initialized
INFO - 2021-03-26 21:50:27 --> Controller Class Initialized
INFO - 2021-03-26 21:50:27 --> Model Class Initialized
INFO - 2021-03-26 21:50:27 --> Model Class Initialized
INFO - 2021-03-26 21:50:27 --> Model Class Initialized
ERROR - 2021-03-26 21:50:27 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\robust\php\application\views\admin\permission\list.php 96
INFO - 2021-03-26 21:53:30 --> Config Class Initialized
INFO - 2021-03-26 21:53:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:53:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:53:30 --> Utf8 Class Initialized
INFO - 2021-03-26 21:53:30 --> URI Class Initialized
INFO - 2021-03-26 21:53:30 --> Router Class Initialized
INFO - 2021-03-26 21:53:30 --> Output Class Initialized
INFO - 2021-03-26 21:53:30 --> Security Class Initialized
DEBUG - 2021-03-26 21:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:53:30 --> Input Class Initialized
INFO - 2021-03-26 21:53:30 --> Language Class Initialized
INFO - 2021-03-26 21:53:30 --> Loader Class Initialized
INFO - 2021-03-26 21:53:30 --> Helper loaded: url_helper
INFO - 2021-03-26 21:53:30 --> Helper loaded: form_helper
INFO - 2021-03-26 21:53:30 --> Helper loaded: common_helper
INFO - 2021-03-26 21:53:30 --> Helper loaded: util_helper
INFO - 2021-03-26 21:53:30 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:53:30 --> Form Validation Class Initialized
INFO - 2021-03-26 21:53:30 --> Controller Class Initialized
INFO - 2021-03-26 21:53:30 --> Model Class Initialized
INFO - 2021-03-26 21:53:30 --> Model Class Initialized
INFO - 2021-03-26 21:53:30 --> Model Class Initialized
ERROR - 2021-03-26 21:53:30 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\robust\php\application\views\admin\permission\list.php 96
INFO - 2021-03-26 21:55:17 --> Config Class Initialized
INFO - 2021-03-26 21:55:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:17 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:17 --> URI Class Initialized
INFO - 2021-03-26 21:55:17 --> Router Class Initialized
INFO - 2021-03-26 21:55:17 --> Output Class Initialized
INFO - 2021-03-26 21:55:17 --> Security Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:17 --> Input Class Initialized
INFO - 2021-03-26 21:55:17 --> Language Class Initialized
INFO - 2021-03-26 21:55:17 --> Loader Class Initialized
INFO - 2021-03-26 21:55:17 --> Helper loaded: url_helper
INFO - 2021-03-26 21:55:17 --> Helper loaded: form_helper
INFO - 2021-03-26 21:55:17 --> Helper loaded: common_helper
INFO - 2021-03-26 21:55:17 --> Helper loaded: util_helper
INFO - 2021-03-26 21:55:17 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:55:17 --> Form Validation Class Initialized
INFO - 2021-03-26 21:55:17 --> Controller Class Initialized
INFO - 2021-03-26 21:55:17 --> Model Class Initialized
INFO - 2021-03-26 21:55:17 --> Model Class Initialized
INFO - 2021-03-26 21:55:17 --> Model Class Initialized
INFO - 2021-03-26 21:55:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:55:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:55:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:55:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:55:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:55:17 --> Final output sent to browser
DEBUG - 2021-03-26 21:55:17 --> Total execution time: 0.0564
INFO - 2021-03-26 21:55:17 --> Config Class Initialized
INFO - 2021-03-26 21:55:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:17 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:17 --> URI Class Initialized
INFO - 2021-03-26 21:55:17 --> Router Class Initialized
INFO - 2021-03-26 21:55:17 --> Output Class Initialized
INFO - 2021-03-26 21:55:17 --> Security Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:17 --> Input Class Initialized
INFO - 2021-03-26 21:55:17 --> Language Class Initialized
INFO - 2021-03-26 21:55:17 --> Config Class Initialized
INFO - 2021-03-26 21:55:17 --> Hooks Class Initialized
ERROR - 2021-03-26 21:55:17 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:17 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:17 --> URI Class Initialized
INFO - 2021-03-26 21:55:17 --> Router Class Initialized
INFO - 2021-03-26 21:55:17 --> Output Class Initialized
INFO - 2021-03-26 21:55:17 --> Security Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:17 --> Input Class Initialized
INFO - 2021-03-26 21:55:17 --> Language Class Initialized
ERROR - 2021-03-26 21:55:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:55:17 --> Config Class Initialized
INFO - 2021-03-26 21:55:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:17 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:17 --> Config Class Initialized
INFO - 2021-03-26 21:55:17 --> Hooks Class Initialized
INFO - 2021-03-26 21:55:17 --> URI Class Initialized
DEBUG - 2021-03-26 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:17 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:17 --> Router Class Initialized
INFO - 2021-03-26 21:55:17 --> URI Class Initialized
INFO - 2021-03-26 21:55:17 --> Output Class Initialized
INFO - 2021-03-26 21:55:17 --> Router Class Initialized
INFO - 2021-03-26 21:55:17 --> Security Class Initialized
INFO - 2021-03-26 21:55:17 --> Output Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:17 --> Input Class Initialized
INFO - 2021-03-26 21:55:17 --> Security Class Initialized
INFO - 2021-03-26 21:55:17 --> Language Class Initialized
DEBUG - 2021-03-26 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:17 --> Input Class Initialized
INFO - 2021-03-26 21:55:17 --> Language Class Initialized
ERROR - 2021-03-26 21:55:17 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 21:55:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:55:22 --> Config Class Initialized
INFO - 2021-03-26 21:55:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:55:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:55:22 --> Utf8 Class Initialized
INFO - 2021-03-26 21:55:22 --> URI Class Initialized
INFO - 2021-03-26 21:55:22 --> Router Class Initialized
INFO - 2021-03-26 21:55:22 --> Output Class Initialized
INFO - 2021-03-26 21:55:22 --> Security Class Initialized
DEBUG - 2021-03-26 21:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:55:22 --> Input Class Initialized
INFO - 2021-03-26 21:55:22 --> Language Class Initialized
INFO - 2021-03-26 21:55:22 --> Loader Class Initialized
INFO - 2021-03-26 21:55:22 --> Helper loaded: url_helper
INFO - 2021-03-26 21:55:22 --> Helper loaded: form_helper
INFO - 2021-03-26 21:55:22 --> Helper loaded: common_helper
INFO - 2021-03-26 21:55:22 --> Helper loaded: util_helper
INFO - 2021-03-26 21:55:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:55:22 --> Form Validation Class Initialized
INFO - 2021-03-26 21:55:22 --> Controller Class Initialized
INFO - 2021-03-26 21:55:22 --> Model Class Initialized
INFO - 2021-03-26 21:55:22 --> Model Class Initialized
INFO - 2021-03-26 21:55:22 --> Model Class Initialized
INFO - 2021-03-26 21:55:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 21:55:22 --> Final output sent to browser
DEBUG - 2021-03-26 21:55:22 --> Total execution time: 0.0474
INFO - 2021-03-26 21:58:48 --> Config Class Initialized
INFO - 2021-03-26 21:58:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:48 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:48 --> URI Class Initialized
INFO - 2021-03-26 21:58:48 --> Router Class Initialized
INFO - 2021-03-26 21:58:48 --> Output Class Initialized
INFO - 2021-03-26 21:58:48 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:48 --> Input Class Initialized
INFO - 2021-03-26 21:58:48 --> Language Class Initialized
INFO - 2021-03-26 21:58:48 --> Loader Class Initialized
INFO - 2021-03-26 21:58:48 --> Helper loaded: url_helper
INFO - 2021-03-26 21:58:48 --> Helper loaded: form_helper
INFO - 2021-03-26 21:58:48 --> Helper loaded: common_helper
INFO - 2021-03-26 21:58:48 --> Helper loaded: util_helper
INFO - 2021-03-26 21:58:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:58:48 --> Form Validation Class Initialized
INFO - 2021-03-26 21:58:48 --> Controller Class Initialized
INFO - 2021-03-26 21:58:48 --> Model Class Initialized
INFO - 2021-03-26 21:58:48 --> Model Class Initialized
INFO - 2021-03-26 21:58:48 --> Model Class Initialized
INFO - 2021-03-26 21:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 21:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 21:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 21:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 21:58:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 21:58:48 --> Final output sent to browser
DEBUG - 2021-03-26 21:58:48 --> Total execution time: 0.0593
INFO - 2021-03-26 21:58:48 --> Config Class Initialized
INFO - 2021-03-26 21:58:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:48 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:48 --> URI Class Initialized
INFO - 2021-03-26 21:58:48 --> Router Class Initialized
INFO - 2021-03-26 21:58:48 --> Output Class Initialized
INFO - 2021-03-26 21:58:48 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:48 --> Input Class Initialized
INFO - 2021-03-26 21:58:48 --> Language Class Initialized
ERROR - 2021-03-26 21:58:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:58:48 --> Config Class Initialized
INFO - 2021-03-26 21:58:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:48 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:48 --> URI Class Initialized
INFO - 2021-03-26 21:58:48 --> Router Class Initialized
INFO - 2021-03-26 21:58:48 --> Output Class Initialized
INFO - 2021-03-26 21:58:48 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:48 --> Input Class Initialized
INFO - 2021-03-26 21:58:48 --> Language Class Initialized
ERROR - 2021-03-26 21:58:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:58:48 --> Config Class Initialized
INFO - 2021-03-26 21:58:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:48 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:48 --> URI Class Initialized
INFO - 2021-03-26 21:58:48 --> Router Class Initialized
INFO - 2021-03-26 21:58:48 --> Output Class Initialized
INFO - 2021-03-26 21:58:48 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:48 --> Input Class Initialized
INFO - 2021-03-26 21:58:48 --> Language Class Initialized
ERROR - 2021-03-26 21:58:48 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:58:49 --> Config Class Initialized
INFO - 2021-03-26 21:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:49 --> URI Class Initialized
INFO - 2021-03-26 21:58:49 --> Router Class Initialized
INFO - 2021-03-26 21:58:49 --> Output Class Initialized
INFO - 2021-03-26 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:49 --> Input Class Initialized
INFO - 2021-03-26 21:58:49 --> Language Class Initialized
ERROR - 2021-03-26 21:58:49 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 21:58:51 --> Config Class Initialized
INFO - 2021-03-26 21:58:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 21:58:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 21:58:51 --> Utf8 Class Initialized
INFO - 2021-03-26 21:58:51 --> URI Class Initialized
INFO - 2021-03-26 21:58:51 --> Router Class Initialized
INFO - 2021-03-26 21:58:51 --> Output Class Initialized
INFO - 2021-03-26 21:58:51 --> Security Class Initialized
DEBUG - 2021-03-26 21:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 21:58:51 --> Input Class Initialized
INFO - 2021-03-26 21:58:51 --> Language Class Initialized
INFO - 2021-03-26 21:58:51 --> Loader Class Initialized
INFO - 2021-03-26 21:58:51 --> Helper loaded: url_helper
INFO - 2021-03-26 21:58:51 --> Helper loaded: form_helper
INFO - 2021-03-26 21:58:51 --> Helper loaded: common_helper
INFO - 2021-03-26 21:58:51 --> Helper loaded: util_helper
INFO - 2021-03-26 21:58:51 --> Database Driver Class Initialized
DEBUG - 2021-03-26 21:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 21:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 21:58:51 --> Form Validation Class Initialized
INFO - 2021-03-26 21:58:51 --> Controller Class Initialized
INFO - 2021-03-26 21:58:51 --> Model Class Initialized
INFO - 2021-03-26 21:58:51 --> Model Class Initialized
INFO - 2021-03-26 21:58:51 --> Model Class Initialized
INFO - 2021-03-26 21:58:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 21:58:51 --> Final output sent to browser
DEBUG - 2021-03-26 21:58:51 --> Total execution time: 0.0506
INFO - 2021-03-26 22:10:10 --> Config Class Initialized
INFO - 2021-03-26 22:10:10 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:10:10 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:10 --> URI Class Initialized
INFO - 2021-03-26 22:10:10 --> Router Class Initialized
INFO - 2021-03-26 22:10:10 --> Output Class Initialized
INFO - 2021-03-26 22:10:10 --> Security Class Initialized
DEBUG - 2021-03-26 22:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:10:10 --> Input Class Initialized
INFO - 2021-03-26 22:10:10 --> Language Class Initialized
INFO - 2021-03-26 22:10:10 --> Loader Class Initialized
INFO - 2021-03-26 22:10:10 --> Helper loaded: url_helper
INFO - 2021-03-26 22:10:10 --> Helper loaded: form_helper
INFO - 2021-03-26 22:10:10 --> Helper loaded: common_helper
INFO - 2021-03-26 22:10:10 --> Helper loaded: util_helper
INFO - 2021-03-26 22:10:10 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:10:10 --> Form Validation Class Initialized
INFO - 2021-03-26 22:10:10 --> Controller Class Initialized
INFO - 2021-03-26 22:10:10 --> Model Class Initialized
INFO - 2021-03-26 22:10:10 --> Model Class Initialized
INFO - 2021-03-26 22:10:10 --> Model Class Initialized
INFO - 2021-03-26 22:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:10:10 --> Final output sent to browser
DEBUG - 2021-03-26 22:10:10 --> Total execution time: 0.0549
INFO - 2021-03-26 22:10:11 --> Config Class Initialized
INFO - 2021-03-26 22:10:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:11 --> Config Class Initialized
INFO - 2021-03-26 22:10:11 --> Hooks Class Initialized
INFO - 2021-03-26 22:10:11 --> URI Class Initialized
INFO - 2021-03-26 22:10:11 --> Router Class Initialized
DEBUG - 2021-03-26 22:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:11 --> URI Class Initialized
INFO - 2021-03-26 22:10:11 --> Router Class Initialized
INFO - 2021-03-26 22:10:11 --> Output Class Initialized
INFO - 2021-03-26 22:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 22:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:10:11 --> Input Class Initialized
INFO - 2021-03-26 22:10:11 --> Language Class Initialized
ERROR - 2021-03-26 22:10:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:10:11 --> Output Class Initialized
INFO - 2021-03-26 22:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 22:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:10:11 --> Input Class Initialized
INFO - 2021-03-26 22:10:11 --> Language Class Initialized
ERROR - 2021-03-26 22:10:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:10:11 --> Config Class Initialized
INFO - 2021-03-26 22:10:11 --> Config Class Initialized
INFO - 2021-03-26 22:10:11 --> Hooks Class Initialized
INFO - 2021-03-26 22:10:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:10:11 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 22:10:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:11 --> URI Class Initialized
INFO - 2021-03-26 22:10:11 --> URI Class Initialized
INFO - 2021-03-26 22:10:11 --> Router Class Initialized
INFO - 2021-03-26 22:10:11 --> Router Class Initialized
INFO - 2021-03-26 22:10:11 --> Output Class Initialized
INFO - 2021-03-26 22:10:11 --> Output Class Initialized
INFO - 2021-03-26 22:10:11 --> Security Class Initialized
INFO - 2021-03-26 22:10:11 --> Security Class Initialized
DEBUG - 2021-03-26 22:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:10:11 --> Input Class Initialized
INFO - 2021-03-26 22:10:11 --> Input Class Initialized
INFO - 2021-03-26 22:10:11 --> Language Class Initialized
INFO - 2021-03-26 22:10:11 --> Language Class Initialized
ERROR - 2021-03-26 22:10:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:10:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:10:14 --> Config Class Initialized
INFO - 2021-03-26 22:10:14 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:10:14 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:10:14 --> Utf8 Class Initialized
INFO - 2021-03-26 22:10:14 --> URI Class Initialized
INFO - 2021-03-26 22:10:14 --> Router Class Initialized
INFO - 2021-03-26 22:10:14 --> Output Class Initialized
INFO - 2021-03-26 22:10:14 --> Security Class Initialized
DEBUG - 2021-03-26 22:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:10:14 --> Input Class Initialized
INFO - 2021-03-26 22:10:14 --> Language Class Initialized
INFO - 2021-03-26 22:10:14 --> Loader Class Initialized
INFO - 2021-03-26 22:10:14 --> Helper loaded: url_helper
INFO - 2021-03-26 22:10:14 --> Helper loaded: form_helper
INFO - 2021-03-26 22:10:14 --> Helper loaded: common_helper
INFO - 2021-03-26 22:10:14 --> Helper loaded: util_helper
INFO - 2021-03-26 22:10:14 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:10:14 --> Form Validation Class Initialized
INFO - 2021-03-26 22:10:14 --> Controller Class Initialized
INFO - 2021-03-26 22:10:14 --> Model Class Initialized
INFO - 2021-03-26 22:10:14 --> Model Class Initialized
INFO - 2021-03-26 22:10:14 --> Model Class Initialized
INFO - 2021-03-26 22:10:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:10:14 --> Final output sent to browser
DEBUG - 2021-03-26 22:10:14 --> Total execution time: 0.0490
INFO - 2021-03-26 22:11:51 --> Config Class Initialized
INFO - 2021-03-26 22:11:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:11:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:51 --> Utf8 Class Initialized
INFO - 2021-03-26 22:11:51 --> URI Class Initialized
INFO - 2021-03-26 22:11:51 --> Router Class Initialized
INFO - 2021-03-26 22:11:51 --> Output Class Initialized
INFO - 2021-03-26 22:11:51 --> Security Class Initialized
DEBUG - 2021-03-26 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:51 --> Input Class Initialized
INFO - 2021-03-26 22:11:51 --> Language Class Initialized
INFO - 2021-03-26 22:11:51 --> Loader Class Initialized
INFO - 2021-03-26 22:11:51 --> Helper loaded: url_helper
INFO - 2021-03-26 22:11:51 --> Helper loaded: form_helper
INFO - 2021-03-26 22:11:51 --> Helper loaded: common_helper
INFO - 2021-03-26 22:11:51 --> Helper loaded: util_helper
INFO - 2021-03-26 22:11:51 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:11:51 --> Form Validation Class Initialized
INFO - 2021-03-26 22:11:51 --> Controller Class Initialized
INFO - 2021-03-26 22:11:51 --> Model Class Initialized
INFO - 2021-03-26 22:11:51 --> Model Class Initialized
INFO - 2021-03-26 22:11:51 --> Model Class Initialized
INFO - 2021-03-26 22:11:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:11:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:11:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:11:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:11:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:11:51 --> Final output sent to browser
DEBUG - 2021-03-26 22:11:51 --> Total execution time: 0.0543
INFO - 2021-03-26 22:11:51 --> Config Class Initialized
INFO - 2021-03-26 22:11:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:11:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:51 --> Utf8 Class Initialized
INFO - 2021-03-26 22:11:51 --> URI Class Initialized
INFO - 2021-03-26 22:11:51 --> Config Class Initialized
INFO - 2021-03-26 22:11:51 --> Hooks Class Initialized
INFO - 2021-03-26 22:11:51 --> Router Class Initialized
DEBUG - 2021-03-26 22:11:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:51 --> Utf8 Class Initialized
INFO - 2021-03-26 22:11:51 --> Output Class Initialized
INFO - 2021-03-26 22:11:51 --> URI Class Initialized
INFO - 2021-03-26 22:11:51 --> Security Class Initialized
INFO - 2021-03-26 22:11:51 --> Router Class Initialized
DEBUG - 2021-03-26 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:51 --> Input Class Initialized
INFO - 2021-03-26 22:11:51 --> Output Class Initialized
INFO - 2021-03-26 22:11:51 --> Language Class Initialized
INFO - 2021-03-26 22:11:51 --> Security Class Initialized
ERROR - 2021-03-26 22:11:51 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:51 --> Input Class Initialized
INFO - 2021-03-26 22:11:51 --> Language Class Initialized
ERROR - 2021-03-26 22:11:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:11:51 --> Config Class Initialized
INFO - 2021-03-26 22:11:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:11:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:51 --> Utf8 Class Initialized
INFO - 2021-03-26 22:11:51 --> URI Class Initialized
INFO - 2021-03-26 22:11:51 --> Router Class Initialized
INFO - 2021-03-26 22:11:51 --> Output Class Initialized
INFO - 2021-03-26 22:11:51 --> Config Class Initialized
INFO - 2021-03-26 22:11:51 --> Security Class Initialized
INFO - 2021-03-26 22:11:51 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:51 --> Input Class Initialized
INFO - 2021-03-26 22:11:51 --> Language Class Initialized
DEBUG - 2021-03-26 22:11:51 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:51 --> Utf8 Class Initialized
ERROR - 2021-03-26 22:11:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:11:51 --> URI Class Initialized
INFO - 2021-03-26 22:11:51 --> Router Class Initialized
INFO - 2021-03-26 22:11:51 --> Output Class Initialized
INFO - 2021-03-26 22:11:51 --> Security Class Initialized
DEBUG - 2021-03-26 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:51 --> Input Class Initialized
INFO - 2021-03-26 22:11:51 --> Language Class Initialized
ERROR - 2021-03-26 22:11:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:11:55 --> Config Class Initialized
INFO - 2021-03-26 22:11:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:11:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:11:55 --> Utf8 Class Initialized
INFO - 2021-03-26 22:11:55 --> URI Class Initialized
INFO - 2021-03-26 22:11:55 --> Router Class Initialized
INFO - 2021-03-26 22:11:55 --> Output Class Initialized
INFO - 2021-03-26 22:11:55 --> Security Class Initialized
DEBUG - 2021-03-26 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:11:55 --> Input Class Initialized
INFO - 2021-03-26 22:11:55 --> Language Class Initialized
INFO - 2021-03-26 22:11:55 --> Loader Class Initialized
INFO - 2021-03-26 22:11:55 --> Helper loaded: url_helper
INFO - 2021-03-26 22:11:55 --> Helper loaded: form_helper
INFO - 2021-03-26 22:11:55 --> Helper loaded: common_helper
INFO - 2021-03-26 22:11:55 --> Helper loaded: util_helper
INFO - 2021-03-26 22:11:55 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:11:55 --> Form Validation Class Initialized
INFO - 2021-03-26 22:11:55 --> Controller Class Initialized
INFO - 2021-03-26 22:11:55 --> Model Class Initialized
INFO - 2021-03-26 22:11:55 --> Model Class Initialized
INFO - 2021-03-26 22:11:55 --> Model Class Initialized
INFO - 2021-03-26 22:11:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:11:55 --> Final output sent to browser
DEBUG - 2021-03-26 22:11:55 --> Total execution time: 0.0506
INFO - 2021-03-26 22:13:31 --> Config Class Initialized
INFO - 2021-03-26 22:13:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:13:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:31 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:31 --> URI Class Initialized
INFO - 2021-03-26 22:13:31 --> Router Class Initialized
INFO - 2021-03-26 22:13:31 --> Output Class Initialized
INFO - 2021-03-26 22:13:31 --> Security Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:31 --> Input Class Initialized
INFO - 2021-03-26 22:13:31 --> Language Class Initialized
INFO - 2021-03-26 22:13:31 --> Loader Class Initialized
INFO - 2021-03-26 22:13:31 --> Helper loaded: url_helper
INFO - 2021-03-26 22:13:31 --> Helper loaded: form_helper
INFO - 2021-03-26 22:13:31 --> Helper loaded: common_helper
INFO - 2021-03-26 22:13:31 --> Helper loaded: util_helper
INFO - 2021-03-26 22:13:31 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:13:31 --> Form Validation Class Initialized
INFO - 2021-03-26 22:13:31 --> Controller Class Initialized
INFO - 2021-03-26 22:13:31 --> Model Class Initialized
INFO - 2021-03-26 22:13:31 --> Model Class Initialized
INFO - 2021-03-26 22:13:31 --> Model Class Initialized
INFO - 2021-03-26 22:13:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:13:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:13:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:13:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:13:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:13:31 --> Final output sent to browser
DEBUG - 2021-03-26 22:13:31 --> Total execution time: 0.0498
INFO - 2021-03-26 22:13:31 --> Config Class Initialized
INFO - 2021-03-26 22:13:31 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:13:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:31 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:31 --> Config Class Initialized
INFO - 2021-03-26 22:13:31 --> Hooks Class Initialized
INFO - 2021-03-26 22:13:31 --> URI Class Initialized
DEBUG - 2021-03-26 22:13:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:31 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:31 --> URI Class Initialized
INFO - 2021-03-26 22:13:31 --> Router Class Initialized
INFO - 2021-03-26 22:13:31 --> Router Class Initialized
INFO - 2021-03-26 22:13:31 --> Output Class Initialized
INFO - 2021-03-26 22:13:31 --> Output Class Initialized
INFO - 2021-03-26 22:13:31 --> Security Class Initialized
INFO - 2021-03-26 22:13:31 --> Security Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:31 --> Input Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:31 --> Input Class Initialized
INFO - 2021-03-26 22:13:31 --> Language Class Initialized
INFO - 2021-03-26 22:13:31 --> Language Class Initialized
ERROR - 2021-03-26 22:13:31 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:13:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:13:31 --> Config Class Initialized
INFO - 2021-03-26 22:13:31 --> Hooks Class Initialized
INFO - 2021-03-26 22:13:31 --> Config Class Initialized
DEBUG - 2021-03-26 22:13:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:31 --> Hooks Class Initialized
INFO - 2021-03-26 22:13:31 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:31 --> URI Class Initialized
INFO - 2021-03-26 22:13:31 --> Router Class Initialized
DEBUG - 2021-03-26 22:13:31 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:31 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:31 --> Output Class Initialized
INFO - 2021-03-26 22:13:31 --> URI Class Initialized
INFO - 2021-03-26 22:13:31 --> Security Class Initialized
INFO - 2021-03-26 22:13:31 --> Router Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:31 --> Input Class Initialized
INFO - 2021-03-26 22:13:31 --> Output Class Initialized
INFO - 2021-03-26 22:13:31 --> Language Class Initialized
ERROR - 2021-03-26 22:13:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:13:31 --> Security Class Initialized
DEBUG - 2021-03-26 22:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:31 --> Input Class Initialized
INFO - 2021-03-26 22:13:31 --> Language Class Initialized
ERROR - 2021-03-26 22:13:31 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:13:37 --> Config Class Initialized
INFO - 2021-03-26 22:13:37 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:13:37 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:13:37 --> Utf8 Class Initialized
INFO - 2021-03-26 22:13:37 --> URI Class Initialized
INFO - 2021-03-26 22:13:37 --> Router Class Initialized
INFO - 2021-03-26 22:13:37 --> Output Class Initialized
INFO - 2021-03-26 22:13:37 --> Security Class Initialized
DEBUG - 2021-03-26 22:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:13:37 --> Input Class Initialized
INFO - 2021-03-26 22:13:37 --> Language Class Initialized
INFO - 2021-03-26 22:13:37 --> Loader Class Initialized
INFO - 2021-03-26 22:13:37 --> Helper loaded: url_helper
INFO - 2021-03-26 22:13:37 --> Helper loaded: form_helper
INFO - 2021-03-26 22:13:37 --> Helper loaded: common_helper
INFO - 2021-03-26 22:13:37 --> Helper loaded: util_helper
INFO - 2021-03-26 22:13:37 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:13:37 --> Form Validation Class Initialized
INFO - 2021-03-26 22:13:37 --> Controller Class Initialized
INFO - 2021-03-26 22:13:37 --> Model Class Initialized
INFO - 2021-03-26 22:13:37 --> Model Class Initialized
INFO - 2021-03-26 22:13:37 --> Model Class Initialized
INFO - 2021-03-26 22:13:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:13:37 --> Final output sent to browser
DEBUG - 2021-03-26 22:13:37 --> Total execution time: 0.0502
INFO - 2021-03-26 22:19:47 --> Config Class Initialized
INFO - 2021-03-26 22:19:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:19:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:19:47 --> URI Class Initialized
INFO - 2021-03-26 22:19:47 --> Router Class Initialized
INFO - 2021-03-26 22:19:47 --> Output Class Initialized
INFO - 2021-03-26 22:19:47 --> Security Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:19:47 --> Input Class Initialized
INFO - 2021-03-26 22:19:47 --> Language Class Initialized
INFO - 2021-03-26 22:19:47 --> Loader Class Initialized
INFO - 2021-03-26 22:19:47 --> Helper loaded: url_helper
INFO - 2021-03-26 22:19:47 --> Helper loaded: form_helper
INFO - 2021-03-26 22:19:47 --> Helper loaded: common_helper
INFO - 2021-03-26 22:19:47 --> Helper loaded: util_helper
INFO - 2021-03-26 22:19:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:19:47 --> Form Validation Class Initialized
INFO - 2021-03-26 22:19:47 --> Controller Class Initialized
INFO - 2021-03-26 22:19:47 --> Model Class Initialized
INFO - 2021-03-26 22:19:47 --> Model Class Initialized
INFO - 2021-03-26 22:19:47 --> Model Class Initialized
INFO - 2021-03-26 22:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:19:47 --> Final output sent to browser
DEBUG - 2021-03-26 22:19:47 --> Total execution time: 0.0476
INFO - 2021-03-26 22:19:47 --> Config Class Initialized
INFO - 2021-03-26 22:19:47 --> Hooks Class Initialized
INFO - 2021-03-26 22:19:47 --> Config Class Initialized
DEBUG - 2021-03-26 22:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:19:47 --> Hooks Class Initialized
INFO - 2021-03-26 22:19:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:19:47 --> URI Class Initialized
DEBUG - 2021-03-26 22:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:19:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:19:47 --> Router Class Initialized
INFO - 2021-03-26 22:19:47 --> URI Class Initialized
INFO - 2021-03-26 22:19:47 --> Output Class Initialized
INFO - 2021-03-26 22:19:47 --> Router Class Initialized
INFO - 2021-03-26 22:19:47 --> Security Class Initialized
INFO - 2021-03-26 22:19:47 --> Output Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:19:47 --> Input Class Initialized
INFO - 2021-03-26 22:19:47 --> Security Class Initialized
INFO - 2021-03-26 22:19:47 --> Language Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:19:47 --> Input Class Initialized
ERROR - 2021-03-26 22:19:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:19:47 --> Language Class Initialized
ERROR - 2021-03-26 22:19:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:19:47 --> Config Class Initialized
INFO - 2021-03-26 22:19:47 --> Config Class Initialized
INFO - 2021-03-26 22:19:47 --> Hooks Class Initialized
INFO - 2021-03-26 22:19:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:19:47 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:19:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:19:47 --> URI Class Initialized
INFO - 2021-03-26 22:19:47 --> URI Class Initialized
INFO - 2021-03-26 22:19:47 --> Router Class Initialized
INFO - 2021-03-26 22:19:47 --> Router Class Initialized
INFO - 2021-03-26 22:19:47 --> Output Class Initialized
INFO - 2021-03-26 22:19:47 --> Output Class Initialized
INFO - 2021-03-26 22:19:47 --> Security Class Initialized
INFO - 2021-03-26 22:19:47 --> Security Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:19:47 --> Input Class Initialized
DEBUG - 2021-03-26 22:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:19:47 --> Input Class Initialized
INFO - 2021-03-26 22:19:47 --> Language Class Initialized
INFO - 2021-03-26 22:19:47 --> Language Class Initialized
ERROR - 2021-03-26 22:19:47 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:19:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:22:18 --> Config Class Initialized
INFO - 2021-03-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:18 --> Utf8 Class Initialized
INFO - 2021-03-26 22:22:18 --> URI Class Initialized
INFO - 2021-03-26 22:22:18 --> Router Class Initialized
INFO - 2021-03-26 22:22:18 --> Output Class Initialized
INFO - 2021-03-26 22:22:18 --> Security Class Initialized
DEBUG - 2021-03-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:18 --> Input Class Initialized
INFO - 2021-03-26 22:22:18 --> Language Class Initialized
INFO - 2021-03-26 22:22:18 --> Loader Class Initialized
INFO - 2021-03-26 22:22:18 --> Helper loaded: url_helper
INFO - 2021-03-26 22:22:18 --> Helper loaded: form_helper
INFO - 2021-03-26 22:22:18 --> Helper loaded: common_helper
INFO - 2021-03-26 22:22:18 --> Helper loaded: util_helper
INFO - 2021-03-26 22:22:18 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:22:18 --> Form Validation Class Initialized
INFO - 2021-03-26 22:22:18 --> Controller Class Initialized
INFO - 2021-03-26 22:22:18 --> Model Class Initialized
INFO - 2021-03-26 22:22:18 --> Model Class Initialized
INFO - 2021-03-26 22:22:18 --> Model Class Initialized
INFO - 2021-03-26 22:22:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:22:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:22:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:22:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:22:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:22:18 --> Final output sent to browser
DEBUG - 2021-03-26 22:22:18 --> Total execution time: 0.0483
INFO - 2021-03-26 22:22:18 --> Config Class Initialized
INFO - 2021-03-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:18 --> Config Class Initialized
INFO - 2021-03-26 22:22:18 --> Utf8 Class Initialized
INFO - 2021-03-26 22:22:18 --> Hooks Class Initialized
INFO - 2021-03-26 22:22:18 --> URI Class Initialized
DEBUG - 2021-03-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:18 --> Utf8 Class Initialized
INFO - 2021-03-26 22:22:18 --> Router Class Initialized
INFO - 2021-03-26 22:22:18 --> URI Class Initialized
INFO - 2021-03-26 22:22:18 --> Output Class Initialized
INFO - 2021-03-26 22:22:18 --> Security Class Initialized
INFO - 2021-03-26 22:22:18 --> Router Class Initialized
DEBUG - 2021-03-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:18 --> Input Class Initialized
INFO - 2021-03-26 22:22:18 --> Output Class Initialized
INFO - 2021-03-26 22:22:18 --> Language Class Initialized
INFO - 2021-03-26 22:22:18 --> Security Class Initialized
ERROR - 2021-03-26 22:22:18 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:18 --> Input Class Initialized
INFO - 2021-03-26 22:22:18 --> Language Class Initialized
ERROR - 2021-03-26 22:22:18 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:22:18 --> Config Class Initialized
INFO - 2021-03-26 22:22:18 --> Hooks Class Initialized
INFO - 2021-03-26 22:22:18 --> Config Class Initialized
INFO - 2021-03-26 22:22:18 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:18 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:18 --> Utf8 Class Initialized
INFO - 2021-03-26 22:22:18 --> URI Class Initialized
INFO - 2021-03-26 22:22:18 --> URI Class Initialized
INFO - 2021-03-26 22:22:18 --> Router Class Initialized
INFO - 2021-03-26 22:22:18 --> Router Class Initialized
INFO - 2021-03-26 22:22:18 --> Output Class Initialized
INFO - 2021-03-26 22:22:18 --> Output Class Initialized
INFO - 2021-03-26 22:22:18 --> Security Class Initialized
INFO - 2021-03-26 22:22:18 --> Security Class Initialized
DEBUG - 2021-03-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:18 --> Input Class Initialized
INFO - 2021-03-26 22:22:18 --> Language Class Initialized
DEBUG - 2021-03-26 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:18 --> Input Class Initialized
INFO - 2021-03-26 22:22:18 --> Language Class Initialized
ERROR - 2021-03-26 22:22:18 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:22:18 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:22:21 --> Config Class Initialized
INFO - 2021-03-26 22:22:21 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:22:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:22:21 --> Utf8 Class Initialized
INFO - 2021-03-26 22:22:21 --> URI Class Initialized
INFO - 2021-03-26 22:22:21 --> Router Class Initialized
INFO - 2021-03-26 22:22:21 --> Output Class Initialized
INFO - 2021-03-26 22:22:21 --> Security Class Initialized
DEBUG - 2021-03-26 22:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:22:21 --> Input Class Initialized
INFO - 2021-03-26 22:22:21 --> Language Class Initialized
INFO - 2021-03-26 22:22:21 --> Loader Class Initialized
INFO - 2021-03-26 22:22:21 --> Helper loaded: url_helper
INFO - 2021-03-26 22:22:21 --> Helper loaded: form_helper
INFO - 2021-03-26 22:22:21 --> Helper loaded: common_helper
INFO - 2021-03-26 22:22:21 --> Helper loaded: util_helper
INFO - 2021-03-26 22:22:21 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:22:21 --> Form Validation Class Initialized
INFO - 2021-03-26 22:22:21 --> Controller Class Initialized
INFO - 2021-03-26 22:22:21 --> Model Class Initialized
INFO - 2021-03-26 22:22:21 --> Model Class Initialized
INFO - 2021-03-26 22:22:21 --> Model Class Initialized
INFO - 2021-03-26 22:22:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:22:21 --> Final output sent to browser
DEBUG - 2021-03-26 22:22:21 --> Total execution time: 0.0453
INFO - 2021-03-26 22:25:16 --> Config Class Initialized
INFO - 2021-03-26 22:25:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:16 --> URI Class Initialized
INFO - 2021-03-26 22:25:16 --> Router Class Initialized
INFO - 2021-03-26 22:25:16 --> Output Class Initialized
INFO - 2021-03-26 22:25:16 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:16 --> Input Class Initialized
INFO - 2021-03-26 22:25:16 --> Language Class Initialized
INFO - 2021-03-26 22:25:16 --> Loader Class Initialized
INFO - 2021-03-26 22:25:16 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:16 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:16 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:16 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:16 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:16 --> Controller Class Initialized
INFO - 2021-03-26 22:25:16 --> Model Class Initialized
INFO - 2021-03-26 22:25:16 --> Model Class Initialized
INFO - 2021-03-26 22:25:16 --> Model Class Initialized
INFO - 2021-03-26 22:25:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:25:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:25:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:25:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:25:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:25:16 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:16 --> Total execution time: 0.0630
INFO - 2021-03-26 22:25:17 --> Config Class Initialized
INFO - 2021-03-26 22:25:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:17 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:17 --> Config Class Initialized
INFO - 2021-03-26 22:25:17 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:17 --> URI Class Initialized
DEBUG - 2021-03-26 22:25:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:17 --> Router Class Initialized
INFO - 2021-03-26 22:25:17 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:17 --> URI Class Initialized
INFO - 2021-03-26 22:25:17 --> Output Class Initialized
INFO - 2021-03-26 22:25:17 --> Router Class Initialized
INFO - 2021-03-26 22:25:17 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:17 --> Input Class Initialized
INFO - 2021-03-26 22:25:17 --> Output Class Initialized
INFO - 2021-03-26 22:25:17 --> Language Class Initialized
INFO - 2021-03-26 22:25:17 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-26 22:25:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:17 --> Input Class Initialized
INFO - 2021-03-26 22:25:17 --> Language Class Initialized
ERROR - 2021-03-26 22:25:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:17 --> Config Class Initialized
INFO - 2021-03-26 22:25:17 --> Config Class Initialized
INFO - 2021-03-26 22:25:17 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 22:25:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:17 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:17 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:17 --> URI Class Initialized
INFO - 2021-03-26 22:25:17 --> URI Class Initialized
INFO - 2021-03-26 22:25:17 --> Router Class Initialized
INFO - 2021-03-26 22:25:17 --> Router Class Initialized
INFO - 2021-03-26 22:25:17 --> Output Class Initialized
INFO - 2021-03-26 22:25:17 --> Output Class Initialized
INFO - 2021-03-26 22:25:17 --> Security Class Initialized
INFO - 2021-03-26 22:25:17 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:17 --> Input Class Initialized
INFO - 2021-03-26 22:25:17 --> Input Class Initialized
INFO - 2021-03-26 22:25:17 --> Language Class Initialized
INFO - 2021-03-26 22:25:17 --> Language Class Initialized
ERROR - 2021-03-26 22:25:17 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:25:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:19 --> Config Class Initialized
INFO - 2021-03-26 22:25:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:19 --> URI Class Initialized
INFO - 2021-03-26 22:25:19 --> Router Class Initialized
INFO - 2021-03-26 22:25:19 --> Output Class Initialized
INFO - 2021-03-26 22:25:19 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:19 --> Input Class Initialized
INFO - 2021-03-26 22:25:19 --> Language Class Initialized
INFO - 2021-03-26 22:25:19 --> Loader Class Initialized
INFO - 2021-03-26 22:25:19 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:19 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:19 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:19 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:19 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:19 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:19 --> Controller Class Initialized
INFO - 2021-03-26 22:25:19 --> Model Class Initialized
INFO - 2021-03-26 22:25:19 --> Model Class Initialized
INFO - 2021-03-26 22:25:19 --> Model Class Initialized
INFO - 2021-03-26 22:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:25:19 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:19 --> Total execution time: 0.0448
INFO - 2021-03-26 22:25:24 --> Config Class Initialized
INFO - 2021-03-26 22:25:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:24 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:24 --> URI Class Initialized
INFO - 2021-03-26 22:25:24 --> Router Class Initialized
INFO - 2021-03-26 22:25:24 --> Output Class Initialized
INFO - 2021-03-26 22:25:24 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:24 --> Input Class Initialized
INFO - 2021-03-26 22:25:24 --> Language Class Initialized
INFO - 2021-03-26 22:25:24 --> Loader Class Initialized
INFO - 2021-03-26 22:25:24 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:24 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:24 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:24 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:24 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:24 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:24 --> Controller Class Initialized
INFO - 2021-03-26 22:25:24 --> Model Class Initialized
INFO - 2021-03-26 22:25:24 --> Model Class Initialized
INFO - 2021-03-26 22:25:24 --> Model Class Initialized
INFO - 2021-03-26 22:25:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:25:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:25:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:25:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:25:24 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:25:24 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:24 --> Total execution time: 0.0505
INFO - 2021-03-26 22:25:24 --> Config Class Initialized
INFO - 2021-03-26 22:25:24 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:24 --> Config Class Initialized
INFO - 2021-03-26 22:25:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:24 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:24 --> URI Class Initialized
DEBUG - 2021-03-26 22:25:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:24 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:24 --> Router Class Initialized
INFO - 2021-03-26 22:25:24 --> URI Class Initialized
INFO - 2021-03-26 22:25:24 --> Router Class Initialized
INFO - 2021-03-26 22:25:24 --> Output Class Initialized
INFO - 2021-03-26 22:25:24 --> Output Class Initialized
INFO - 2021-03-26 22:25:24 --> Security Class Initialized
INFO - 2021-03-26 22:25:24 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:24 --> Input Class Initialized
INFO - 2021-03-26 22:25:24 --> Input Class Initialized
INFO - 2021-03-26 22:25:24 --> Language Class Initialized
INFO - 2021-03-26 22:25:24 --> Language Class Initialized
ERROR - 2021-03-26 22:25:24 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:25:24 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:24 --> Config Class Initialized
INFO - 2021-03-26 22:25:24 --> Config Class Initialized
INFO - 2021-03-26 22:25:24 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:24 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 22:25:24 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:24 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:24 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:24 --> URI Class Initialized
INFO - 2021-03-26 22:25:24 --> URI Class Initialized
INFO - 2021-03-26 22:25:24 --> Router Class Initialized
INFO - 2021-03-26 22:25:24 --> Router Class Initialized
INFO - 2021-03-26 22:25:24 --> Output Class Initialized
INFO - 2021-03-26 22:25:24 --> Output Class Initialized
INFO - 2021-03-26 22:25:24 --> Security Class Initialized
INFO - 2021-03-26 22:25:24 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:24 --> Input Class Initialized
INFO - 2021-03-26 22:25:24 --> Input Class Initialized
INFO - 2021-03-26 22:25:24 --> Language Class Initialized
INFO - 2021-03-26 22:25:24 --> Language Class Initialized
ERROR - 2021-03-26 22:25:24 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:25:24 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:29 --> Config Class Initialized
INFO - 2021-03-26 22:25:29 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:29 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:29 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:29 --> URI Class Initialized
INFO - 2021-03-26 22:25:29 --> Router Class Initialized
INFO - 2021-03-26 22:25:29 --> Output Class Initialized
INFO - 2021-03-26 22:25:29 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:29 --> Input Class Initialized
INFO - 2021-03-26 22:25:29 --> Language Class Initialized
INFO - 2021-03-26 22:25:29 --> Loader Class Initialized
INFO - 2021-03-26 22:25:29 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:29 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:29 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:29 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:29 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:29 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:29 --> Controller Class Initialized
INFO - 2021-03-26 22:25:29 --> Model Class Initialized
INFO - 2021-03-26 22:25:29 --> Model Class Initialized
INFO - 2021-03-26 22:25:29 --> Model Class Initialized
INFO - 2021-03-26 22:25:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:25:29 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:29 --> Total execution time: 0.0472
INFO - 2021-03-26 22:25:45 --> Config Class Initialized
INFO - 2021-03-26 22:25:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:45 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:45 --> URI Class Initialized
INFO - 2021-03-26 22:25:45 --> Router Class Initialized
INFO - 2021-03-26 22:25:45 --> Output Class Initialized
INFO - 2021-03-26 22:25:45 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:45 --> Input Class Initialized
INFO - 2021-03-26 22:25:45 --> Language Class Initialized
INFO - 2021-03-26 22:25:45 --> Loader Class Initialized
INFO - 2021-03-26 22:25:45 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:45 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:45 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:45 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:45 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:45 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:45 --> Controller Class Initialized
INFO - 2021-03-26 22:25:45 --> Model Class Initialized
INFO - 2021-03-26 22:25:45 --> Model Class Initialized
INFO - 2021-03-26 22:25:45 --> Model Class Initialized
INFO - 2021-03-26 22:25:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:25:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:25:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:25:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:25:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:25:45 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:45 --> Total execution time: 0.0541
INFO - 2021-03-26 22:25:45 --> Config Class Initialized
INFO - 2021-03-26 22:25:45 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:45 --> Config Class Initialized
INFO - 2021-03-26 22:25:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:45 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:25:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:45 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:45 --> URI Class Initialized
INFO - 2021-03-26 22:25:45 --> URI Class Initialized
INFO - 2021-03-26 22:25:45 --> Router Class Initialized
INFO - 2021-03-26 22:25:45 --> Router Class Initialized
INFO - 2021-03-26 22:25:45 --> Output Class Initialized
INFO - 2021-03-26 22:25:45 --> Output Class Initialized
INFO - 2021-03-26 22:25:45 --> Security Class Initialized
INFO - 2021-03-26 22:25:45 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:45 --> Input Class Initialized
INFO - 2021-03-26 22:25:45 --> Input Class Initialized
INFO - 2021-03-26 22:25:45 --> Language Class Initialized
INFO - 2021-03-26 22:25:45 --> Language Class Initialized
ERROR - 2021-03-26 22:25:45 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:25:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:45 --> Config Class Initialized
INFO - 2021-03-26 22:25:45 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:45 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:45 --> Config Class Initialized
INFO - 2021-03-26 22:25:45 --> Hooks Class Initialized
INFO - 2021-03-26 22:25:45 --> URI Class Initialized
INFO - 2021-03-26 22:25:45 --> Router Class Initialized
DEBUG - 2021-03-26 22:25:45 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:45 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:45 --> Output Class Initialized
INFO - 2021-03-26 22:25:45 --> URI Class Initialized
INFO - 2021-03-26 22:25:45 --> Security Class Initialized
INFO - 2021-03-26 22:25:45 --> Router Class Initialized
DEBUG - 2021-03-26 22:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:45 --> Input Class Initialized
INFO - 2021-03-26 22:25:45 --> Output Class Initialized
INFO - 2021-03-26 22:25:45 --> Language Class Initialized
INFO - 2021-03-26 22:25:45 --> Security Class Initialized
ERROR - 2021-03-26 22:25:45 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 22:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:45 --> Input Class Initialized
INFO - 2021-03-26 22:25:45 --> Language Class Initialized
ERROR - 2021-03-26 22:25:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:25:48 --> Config Class Initialized
INFO - 2021-03-26 22:25:48 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:25:48 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:25:48 --> Utf8 Class Initialized
INFO - 2021-03-26 22:25:48 --> URI Class Initialized
INFO - 2021-03-26 22:25:48 --> Router Class Initialized
INFO - 2021-03-26 22:25:48 --> Output Class Initialized
INFO - 2021-03-26 22:25:48 --> Security Class Initialized
DEBUG - 2021-03-26 22:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:25:48 --> Input Class Initialized
INFO - 2021-03-26 22:25:48 --> Language Class Initialized
INFO - 2021-03-26 22:25:48 --> Loader Class Initialized
INFO - 2021-03-26 22:25:48 --> Helper loaded: url_helper
INFO - 2021-03-26 22:25:48 --> Helper loaded: form_helper
INFO - 2021-03-26 22:25:48 --> Helper loaded: common_helper
INFO - 2021-03-26 22:25:48 --> Helper loaded: util_helper
INFO - 2021-03-26 22:25:48 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:25:48 --> Form Validation Class Initialized
INFO - 2021-03-26 22:25:48 --> Controller Class Initialized
INFO - 2021-03-26 22:25:48 --> Model Class Initialized
INFO - 2021-03-26 22:25:48 --> Model Class Initialized
INFO - 2021-03-26 22:25:48 --> Model Class Initialized
INFO - 2021-03-26 22:25:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:25:48 --> Final output sent to browser
DEBUG - 2021-03-26 22:25:48 --> Total execution time: 0.0479
INFO - 2021-03-26 22:26:47 --> Config Class Initialized
INFO - 2021-03-26 22:26:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:26:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:26:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:26:47 --> URI Class Initialized
INFO - 2021-03-26 22:26:47 --> Router Class Initialized
INFO - 2021-03-26 22:26:47 --> Output Class Initialized
INFO - 2021-03-26 22:26:47 --> Security Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:26:47 --> Input Class Initialized
INFO - 2021-03-26 22:26:47 --> Language Class Initialized
INFO - 2021-03-26 22:26:47 --> Loader Class Initialized
INFO - 2021-03-26 22:26:47 --> Helper loaded: url_helper
INFO - 2021-03-26 22:26:47 --> Helper loaded: form_helper
INFO - 2021-03-26 22:26:47 --> Helper loaded: common_helper
INFO - 2021-03-26 22:26:47 --> Helper loaded: util_helper
INFO - 2021-03-26 22:26:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:26:47 --> Form Validation Class Initialized
INFO - 2021-03-26 22:26:47 --> Controller Class Initialized
INFO - 2021-03-26 22:26:47 --> Model Class Initialized
INFO - 2021-03-26 22:26:47 --> Model Class Initialized
INFO - 2021-03-26 22:26:47 --> Model Class Initialized
INFO - 2021-03-26 22:26:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:26:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:26:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:26:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:26:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:26:47 --> Final output sent to browser
DEBUG - 2021-03-26 22:26:47 --> Total execution time: 0.0467
INFO - 2021-03-26 22:26:47 --> Config Class Initialized
INFO - 2021-03-26 22:26:47 --> Hooks Class Initialized
INFO - 2021-03-26 22:26:47 --> Config Class Initialized
INFO - 2021-03-26 22:26:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:26:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:26:47 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:26:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:26:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:26:47 --> URI Class Initialized
INFO - 2021-03-26 22:26:47 --> URI Class Initialized
INFO - 2021-03-26 22:26:47 --> Router Class Initialized
INFO - 2021-03-26 22:26:47 --> Router Class Initialized
INFO - 2021-03-26 22:26:47 --> Output Class Initialized
INFO - 2021-03-26 22:26:47 --> Output Class Initialized
INFO - 2021-03-26 22:26:47 --> Security Class Initialized
INFO - 2021-03-26 22:26:47 --> Security Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:26:47 --> Input Class Initialized
INFO - 2021-03-26 22:26:47 --> Language Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:26:47 --> Input Class Initialized
INFO - 2021-03-26 22:26:47 --> Language Class Initialized
ERROR - 2021-03-26 22:26:47 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:26:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:26:47 --> Config Class Initialized
INFO - 2021-03-26 22:26:47 --> Hooks Class Initialized
INFO - 2021-03-26 22:26:47 --> Config Class Initialized
INFO - 2021-03-26 22:26:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:26:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:26:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:26:47 --> URI Class Initialized
DEBUG - 2021-03-26 22:26:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:26:47 --> Utf8 Class Initialized
INFO - 2021-03-26 22:26:47 --> Router Class Initialized
INFO - 2021-03-26 22:26:47 --> URI Class Initialized
INFO - 2021-03-26 22:26:47 --> Output Class Initialized
INFO - 2021-03-26 22:26:47 --> Security Class Initialized
INFO - 2021-03-26 22:26:47 --> Router Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:26:47 --> Input Class Initialized
INFO - 2021-03-26 22:26:47 --> Language Class Initialized
INFO - 2021-03-26 22:26:47 --> Output Class Initialized
ERROR - 2021-03-26 22:26:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:26:47 --> Security Class Initialized
DEBUG - 2021-03-26 22:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:26:47 --> Input Class Initialized
INFO - 2021-03-26 22:26:47 --> Language Class Initialized
ERROR - 2021-03-26 22:26:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:27:23 --> Config Class Initialized
INFO - 2021-03-26 22:27:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:27:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:27:23 --> Utf8 Class Initialized
INFO - 2021-03-26 22:27:23 --> URI Class Initialized
INFO - 2021-03-26 22:27:23 --> Router Class Initialized
INFO - 2021-03-26 22:27:23 --> Output Class Initialized
INFO - 2021-03-26 22:27:23 --> Security Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:27:23 --> Input Class Initialized
INFO - 2021-03-26 22:27:23 --> Language Class Initialized
INFO - 2021-03-26 22:27:23 --> Loader Class Initialized
INFO - 2021-03-26 22:27:23 --> Helper loaded: url_helper
INFO - 2021-03-26 22:27:23 --> Helper loaded: form_helper
INFO - 2021-03-26 22:27:23 --> Helper loaded: common_helper
INFO - 2021-03-26 22:27:23 --> Helper loaded: util_helper
INFO - 2021-03-26 22:27:23 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:27:23 --> Form Validation Class Initialized
INFO - 2021-03-26 22:27:23 --> Controller Class Initialized
INFO - 2021-03-26 22:27:23 --> Model Class Initialized
INFO - 2021-03-26 22:27:23 --> Model Class Initialized
INFO - 2021-03-26 22:27:23 --> Model Class Initialized
INFO - 2021-03-26 22:27:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:27:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:27:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:27:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:27:23 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:27:23 --> Final output sent to browser
DEBUG - 2021-03-26 22:27:23 --> Total execution time: 0.0437
INFO - 2021-03-26 22:27:23 --> Config Class Initialized
INFO - 2021-03-26 22:27:23 --> Hooks Class Initialized
INFO - 2021-03-26 22:27:23 --> Config Class Initialized
INFO - 2021-03-26 22:27:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:27:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:27:23 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:27:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:27:23 --> Utf8 Class Initialized
INFO - 2021-03-26 22:27:23 --> URI Class Initialized
INFO - 2021-03-26 22:27:23 --> URI Class Initialized
INFO - 2021-03-26 22:27:23 --> Router Class Initialized
INFO - 2021-03-26 22:27:23 --> Router Class Initialized
INFO - 2021-03-26 22:27:23 --> Output Class Initialized
INFO - 2021-03-26 22:27:23 --> Output Class Initialized
INFO - 2021-03-26 22:27:23 --> Security Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:27:23 --> Security Class Initialized
INFO - 2021-03-26 22:27:23 --> Input Class Initialized
INFO - 2021-03-26 22:27:23 --> Language Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:27:23 --> Input Class Initialized
ERROR - 2021-03-26 22:27:23 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:27:23 --> Language Class Initialized
ERROR - 2021-03-26 22:27:23 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:27:23 --> Config Class Initialized
INFO - 2021-03-26 22:27:23 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:27:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:27:23 --> Config Class Initialized
INFO - 2021-03-26 22:27:23 --> Utf8 Class Initialized
INFO - 2021-03-26 22:27:23 --> Hooks Class Initialized
INFO - 2021-03-26 22:27:23 --> URI Class Initialized
DEBUG - 2021-03-26 22:27:23 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:27:23 --> Utf8 Class Initialized
INFO - 2021-03-26 22:27:23 --> Router Class Initialized
INFO - 2021-03-26 22:27:23 --> URI Class Initialized
INFO - 2021-03-26 22:27:23 --> Output Class Initialized
INFO - 2021-03-26 22:27:23 --> Router Class Initialized
INFO - 2021-03-26 22:27:23 --> Security Class Initialized
INFO - 2021-03-26 22:27:23 --> Output Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:27:23 --> Input Class Initialized
INFO - 2021-03-26 22:27:23 --> Security Class Initialized
INFO - 2021-03-26 22:27:23 --> Language Class Initialized
DEBUG - 2021-03-26 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:27:23 --> Input Class Initialized
ERROR - 2021-03-26 22:27:23 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:27:23 --> Language Class Initialized
ERROR - 2021-03-26 22:27:23 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:28:53 --> Config Class Initialized
INFO - 2021-03-26 22:28:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:28:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:28:53 --> Utf8 Class Initialized
INFO - 2021-03-26 22:28:53 --> URI Class Initialized
INFO - 2021-03-26 22:28:53 --> Router Class Initialized
INFO - 2021-03-26 22:28:53 --> Output Class Initialized
INFO - 2021-03-26 22:28:53 --> Security Class Initialized
DEBUG - 2021-03-26 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:28:53 --> Input Class Initialized
INFO - 2021-03-26 22:28:53 --> Language Class Initialized
INFO - 2021-03-26 22:28:53 --> Loader Class Initialized
INFO - 2021-03-26 22:28:53 --> Helper loaded: url_helper
INFO - 2021-03-26 22:28:53 --> Helper loaded: form_helper
INFO - 2021-03-26 22:28:53 --> Helper loaded: common_helper
INFO - 2021-03-26 22:28:53 --> Helper loaded: util_helper
INFO - 2021-03-26 22:28:53 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:28:53 --> Form Validation Class Initialized
INFO - 2021-03-26 22:28:53 --> Controller Class Initialized
INFO - 2021-03-26 22:28:53 --> Model Class Initialized
INFO - 2021-03-26 22:28:53 --> Model Class Initialized
INFO - 2021-03-26 22:28:53 --> Model Class Initialized
INFO - 2021-03-26 22:28:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:28:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:28:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:28:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:28:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:28:53 --> Final output sent to browser
DEBUG - 2021-03-26 22:28:53 --> Total execution time: 0.0372
INFO - 2021-03-26 22:28:53 --> Config Class Initialized
INFO - 2021-03-26 22:28:53 --> Config Class Initialized
INFO - 2021-03-26 22:28:53 --> Hooks Class Initialized
INFO - 2021-03-26 22:28:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:28:53 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 22:28:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:28:53 --> Utf8 Class Initialized
INFO - 2021-03-26 22:28:53 --> Utf8 Class Initialized
INFO - 2021-03-26 22:28:53 --> URI Class Initialized
INFO - 2021-03-26 22:28:53 --> URI Class Initialized
INFO - 2021-03-26 22:28:53 --> Router Class Initialized
INFO - 2021-03-26 22:28:53 --> Router Class Initialized
INFO - 2021-03-26 22:28:53 --> Output Class Initialized
INFO - 2021-03-26 22:28:53 --> Output Class Initialized
INFO - 2021-03-26 22:28:53 --> Security Class Initialized
DEBUG - 2021-03-26 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:28:53 --> Security Class Initialized
INFO - 2021-03-26 22:28:53 --> Input Class Initialized
INFO - 2021-03-26 22:28:53 --> Language Class Initialized
DEBUG - 2021-03-26 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:28:53 --> Input Class Initialized
ERROR - 2021-03-26 22:28:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:28:53 --> Language Class Initialized
ERROR - 2021-03-26 22:28:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:28:53 --> Config Class Initialized
INFO - 2021-03-26 22:28:53 --> Hooks Class Initialized
INFO - 2021-03-26 22:28:53 --> Config Class Initialized
INFO - 2021-03-26 22:28:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:28:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:28:53 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:28:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:28:53 --> Utf8 Class Initialized
INFO - 2021-03-26 22:28:53 --> URI Class Initialized
INFO - 2021-03-26 22:28:53 --> URI Class Initialized
INFO - 2021-03-26 22:28:53 --> Router Class Initialized
INFO - 2021-03-26 22:28:53 --> Router Class Initialized
INFO - 2021-03-26 22:28:53 --> Output Class Initialized
INFO - 2021-03-26 22:28:53 --> Output Class Initialized
INFO - 2021-03-26 22:28:53 --> Security Class Initialized
INFO - 2021-03-26 22:28:53 --> Security Class Initialized
DEBUG - 2021-03-26 22:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:28:53 --> Input Class Initialized
INFO - 2021-03-26 22:28:53 --> Input Class Initialized
INFO - 2021-03-26 22:28:53 --> Language Class Initialized
INFO - 2021-03-26 22:28:53 --> Language Class Initialized
ERROR - 2021-03-26 22:28:53 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:28:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:28:55 --> Config Class Initialized
INFO - 2021-03-26 22:28:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:28:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:28:55 --> Utf8 Class Initialized
INFO - 2021-03-26 22:28:55 --> URI Class Initialized
INFO - 2021-03-26 22:28:55 --> Router Class Initialized
INFO - 2021-03-26 22:28:55 --> Output Class Initialized
INFO - 2021-03-26 22:28:55 --> Security Class Initialized
DEBUG - 2021-03-26 22:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:28:55 --> Input Class Initialized
INFO - 2021-03-26 22:28:55 --> Language Class Initialized
INFO - 2021-03-26 22:28:55 --> Loader Class Initialized
INFO - 2021-03-26 22:28:55 --> Helper loaded: url_helper
INFO - 2021-03-26 22:28:55 --> Helper loaded: form_helper
INFO - 2021-03-26 22:28:55 --> Helper loaded: common_helper
INFO - 2021-03-26 22:28:55 --> Helper loaded: util_helper
INFO - 2021-03-26 22:28:55 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:28:55 --> Form Validation Class Initialized
INFO - 2021-03-26 22:28:55 --> Controller Class Initialized
INFO - 2021-03-26 22:28:55 --> Model Class Initialized
INFO - 2021-03-26 22:28:55 --> Model Class Initialized
INFO - 2021-03-26 22:28:55 --> Model Class Initialized
INFO - 2021-03-26 22:28:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:28:55 --> Final output sent to browser
DEBUG - 2021-03-26 22:28:55 --> Total execution time: 0.0450
INFO - 2021-03-26 22:30:54 --> Config Class Initialized
INFO - 2021-03-26 22:30:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:54 --> Utf8 Class Initialized
INFO - 2021-03-26 22:30:54 --> URI Class Initialized
INFO - 2021-03-26 22:30:54 --> Router Class Initialized
INFO - 2021-03-26 22:30:54 --> Output Class Initialized
INFO - 2021-03-26 22:30:54 --> Security Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:54 --> Input Class Initialized
INFO - 2021-03-26 22:30:54 --> Language Class Initialized
INFO - 2021-03-26 22:30:54 --> Loader Class Initialized
INFO - 2021-03-26 22:30:54 --> Helper loaded: url_helper
INFO - 2021-03-26 22:30:54 --> Helper loaded: form_helper
INFO - 2021-03-26 22:30:54 --> Helper loaded: common_helper
INFO - 2021-03-26 22:30:54 --> Helper loaded: util_helper
INFO - 2021-03-26 22:30:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:30:54 --> Form Validation Class Initialized
INFO - 2021-03-26 22:30:54 --> Controller Class Initialized
INFO - 2021-03-26 22:30:54 --> Model Class Initialized
INFO - 2021-03-26 22:30:54 --> Model Class Initialized
INFO - 2021-03-26 22:30:54 --> Model Class Initialized
INFO - 2021-03-26 22:30:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:30:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:30:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:30:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:30:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:30:54 --> Final output sent to browser
DEBUG - 2021-03-26 22:30:54 --> Total execution time: 0.0401
INFO - 2021-03-26 22:30:54 --> Config Class Initialized
INFO - 2021-03-26 22:30:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:54 --> Utf8 Class Initialized
INFO - 2021-03-26 22:30:54 --> Config Class Initialized
INFO - 2021-03-26 22:30:54 --> Hooks Class Initialized
INFO - 2021-03-26 22:30:54 --> URI Class Initialized
DEBUG - 2021-03-26 22:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:54 --> Utf8 Class Initialized
INFO - 2021-03-26 22:30:54 --> Router Class Initialized
INFO - 2021-03-26 22:30:54 --> URI Class Initialized
INFO - 2021-03-26 22:30:54 --> Output Class Initialized
INFO - 2021-03-26 22:30:54 --> Router Class Initialized
INFO - 2021-03-26 22:30:54 --> Security Class Initialized
INFO - 2021-03-26 22:30:54 --> Output Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:54 --> Input Class Initialized
INFO - 2021-03-26 22:30:54 --> Security Class Initialized
INFO - 2021-03-26 22:30:54 --> Language Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:54 --> Input Class Initialized
INFO - 2021-03-26 22:30:54 --> Language Class Initialized
ERROR - 2021-03-26 22:30:54 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:30:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:30:54 --> Config Class Initialized
INFO - 2021-03-26 22:30:54 --> Hooks Class Initialized
INFO - 2021-03-26 22:30:54 --> Config Class Initialized
INFO - 2021-03-26 22:30:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:54 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:54 --> URI Class Initialized
INFO - 2021-03-26 22:30:54 --> Utf8 Class Initialized
INFO - 2021-03-26 22:30:54 --> URI Class Initialized
INFO - 2021-03-26 22:30:54 --> Router Class Initialized
INFO - 2021-03-26 22:30:54 --> Output Class Initialized
INFO - 2021-03-26 22:30:54 --> Router Class Initialized
INFO - 2021-03-26 22:30:54 --> Security Class Initialized
INFO - 2021-03-26 22:30:54 --> Output Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:54 --> Input Class Initialized
INFO - 2021-03-26 22:30:54 --> Language Class Initialized
INFO - 2021-03-26 22:30:54 --> Security Class Initialized
DEBUG - 2021-03-26 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:54 --> Input Class Initialized
ERROR - 2021-03-26 22:30:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:30:54 --> Language Class Initialized
ERROR - 2021-03-26 22:30:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:30:57 --> Config Class Initialized
INFO - 2021-03-26 22:30:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:30:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:30:57 --> Utf8 Class Initialized
INFO - 2021-03-26 22:30:57 --> URI Class Initialized
INFO - 2021-03-26 22:30:57 --> Router Class Initialized
INFO - 2021-03-26 22:30:57 --> Output Class Initialized
INFO - 2021-03-26 22:30:57 --> Security Class Initialized
DEBUG - 2021-03-26 22:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:30:57 --> Input Class Initialized
INFO - 2021-03-26 22:30:57 --> Language Class Initialized
INFO - 2021-03-26 22:30:57 --> Loader Class Initialized
INFO - 2021-03-26 22:30:57 --> Helper loaded: url_helper
INFO - 2021-03-26 22:30:57 --> Helper loaded: form_helper
INFO - 2021-03-26 22:30:57 --> Helper loaded: common_helper
INFO - 2021-03-26 22:30:57 --> Helper loaded: util_helper
INFO - 2021-03-26 22:30:57 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:30:57 --> Form Validation Class Initialized
INFO - 2021-03-26 22:30:57 --> Controller Class Initialized
INFO - 2021-03-26 22:30:57 --> Model Class Initialized
INFO - 2021-03-26 22:30:57 --> Model Class Initialized
INFO - 2021-03-26 22:30:57 --> Model Class Initialized
INFO - 2021-03-26 22:30:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:31:27 --> Final output sent to browser
DEBUG - 2021-03-26 22:31:27 --> Total execution time: 30.0517
INFO - 2021-03-26 22:32:11 --> Config Class Initialized
INFO - 2021-03-26 22:32:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:32:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:32:11 --> URI Class Initialized
INFO - 2021-03-26 22:32:11 --> Router Class Initialized
INFO - 2021-03-26 22:32:11 --> Output Class Initialized
INFO - 2021-03-26 22:32:11 --> Security Class Initialized
DEBUG - 2021-03-26 22:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:32:11 --> Input Class Initialized
INFO - 2021-03-26 22:32:11 --> Language Class Initialized
INFO - 2021-03-26 22:32:11 --> Loader Class Initialized
INFO - 2021-03-26 22:32:11 --> Helper loaded: url_helper
INFO - 2021-03-26 22:32:11 --> Helper loaded: form_helper
INFO - 2021-03-26 22:32:11 --> Helper loaded: common_helper
INFO - 2021-03-26 22:32:11 --> Helper loaded: util_helper
INFO - 2021-03-26 22:32:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:32:11 --> Form Validation Class Initialized
INFO - 2021-03-26 22:32:11 --> Controller Class Initialized
INFO - 2021-03-26 22:32:11 --> Model Class Initialized
INFO - 2021-03-26 22:32:11 --> Model Class Initialized
INFO - 2021-03-26 22:32:11 --> Model Class Initialized
INFO - 2021-03-26 22:32:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:32:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:32:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:32:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:32:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:32:11 --> Final output sent to browser
DEBUG - 2021-03-26 22:32:11 --> Total execution time: 0.0503
INFO - 2021-03-26 22:32:11 --> Config Class Initialized
INFO - 2021-03-26 22:32:11 --> Hooks Class Initialized
INFO - 2021-03-26 22:32:11 --> Config Class Initialized
INFO - 2021-03-26 22:32:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:32:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:11 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:32:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:32:11 --> URI Class Initialized
INFO - 2021-03-26 22:32:11 --> URI Class Initialized
INFO - 2021-03-26 22:32:11 --> Router Class Initialized
INFO - 2021-03-26 22:32:11 --> Output Class Initialized
INFO - 2021-03-26 22:32:11 --> Router Class Initialized
INFO - 2021-03-26 22:32:11 --> Security Class Initialized
INFO - 2021-03-26 22:32:11 --> Output Class Initialized
DEBUG - 2021-03-26 22:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:32:11 --> Input Class Initialized
INFO - 2021-03-26 22:32:11 --> Language Class Initialized
INFO - 2021-03-26 22:32:11 --> Security Class Initialized
DEBUG - 2021-03-26 22:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-26 22:32:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:32:11 --> Input Class Initialized
INFO - 2021-03-26 22:32:11 --> Language Class Initialized
ERROR - 2021-03-26 22:32:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:32:11 --> Config Class Initialized
INFO - 2021-03-26 22:32:11 --> Hooks Class Initialized
INFO - 2021-03-26 22:32:11 --> Config Class Initialized
INFO - 2021-03-26 22:32:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:32:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:11 --> Utf8 Class Initialized
DEBUG - 2021-03-26 22:32:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:11 --> Utf8 Class Initialized
INFO - 2021-03-26 22:32:11 --> URI Class Initialized
INFO - 2021-03-26 22:32:11 --> URI Class Initialized
INFO - 2021-03-26 22:32:11 --> Router Class Initialized
INFO - 2021-03-26 22:32:11 --> Router Class Initialized
INFO - 2021-03-26 22:32:12 --> Output Class Initialized
INFO - 2021-03-26 22:32:12 --> Output Class Initialized
INFO - 2021-03-26 22:32:12 --> Security Class Initialized
INFO - 2021-03-26 22:32:12 --> Security Class Initialized
DEBUG - 2021-03-26 22:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 22:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:32:12 --> Input Class Initialized
INFO - 2021-03-26 22:32:12 --> Input Class Initialized
INFO - 2021-03-26 22:32:12 --> Language Class Initialized
INFO - 2021-03-26 22:32:12 --> Language Class Initialized
ERROR - 2021-03-26 22:32:12 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:32:12 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:32:15 --> Config Class Initialized
INFO - 2021-03-26 22:32:15 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:32:15 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:32:15 --> Utf8 Class Initialized
INFO - 2021-03-26 22:32:15 --> URI Class Initialized
INFO - 2021-03-26 22:32:15 --> Router Class Initialized
INFO - 2021-03-26 22:32:15 --> Output Class Initialized
INFO - 2021-03-26 22:32:15 --> Security Class Initialized
DEBUG - 2021-03-26 22:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:32:15 --> Input Class Initialized
INFO - 2021-03-26 22:32:15 --> Language Class Initialized
INFO - 2021-03-26 22:32:15 --> Loader Class Initialized
INFO - 2021-03-26 22:32:15 --> Helper loaded: url_helper
INFO - 2021-03-26 22:32:15 --> Helper loaded: form_helper
INFO - 2021-03-26 22:32:15 --> Helper loaded: common_helper
INFO - 2021-03-26 22:32:15 --> Helper loaded: util_helper
INFO - 2021-03-26 22:32:15 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:32:15 --> Form Validation Class Initialized
INFO - 2021-03-26 22:32:15 --> Controller Class Initialized
INFO - 2021-03-26 22:32:15 --> Model Class Initialized
INFO - 2021-03-26 22:32:15 --> Model Class Initialized
INFO - 2021-03-26 22:32:15 --> Model Class Initialized
INFO - 2021-03-26 22:32:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:32:45 --> Final output sent to browser
DEBUG - 2021-03-26 22:32:45 --> Total execution time: 30.0533
INFO - 2021-03-26 22:33:30 --> Config Class Initialized
INFO - 2021-03-26 22:33:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:33:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:33:30 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:30 --> URI Class Initialized
INFO - 2021-03-26 22:33:30 --> Router Class Initialized
INFO - 2021-03-26 22:33:30 --> Output Class Initialized
INFO - 2021-03-26 22:33:30 --> Security Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:30 --> Input Class Initialized
INFO - 2021-03-26 22:33:30 --> Language Class Initialized
INFO - 2021-03-26 22:33:30 --> Loader Class Initialized
INFO - 2021-03-26 22:33:30 --> Helper loaded: url_helper
INFO - 2021-03-26 22:33:30 --> Helper loaded: form_helper
INFO - 2021-03-26 22:33:30 --> Helper loaded: common_helper
INFO - 2021-03-26 22:33:30 --> Helper loaded: util_helper
INFO - 2021-03-26 22:33:30 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:33:30 --> Form Validation Class Initialized
INFO - 2021-03-26 22:33:30 --> Controller Class Initialized
INFO - 2021-03-26 22:33:30 --> Model Class Initialized
INFO - 2021-03-26 22:33:30 --> Model Class Initialized
INFO - 2021-03-26 22:33:30 --> Model Class Initialized
INFO - 2021-03-26 22:33:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:33:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:33:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:33:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:33:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:33:30 --> Final output sent to browser
DEBUG - 2021-03-26 22:33:30 --> Total execution time: 0.0421
INFO - 2021-03-26 22:33:30 --> Config Class Initialized
INFO - 2021-03-26 22:33:30 --> Hooks Class Initialized
INFO - 2021-03-26 22:33:30 --> Config Class Initialized
DEBUG - 2021-03-26 22:33:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:33:30 --> Hooks Class Initialized
INFO - 2021-03-26 22:33:30 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:30 --> URI Class Initialized
DEBUG - 2021-03-26 22:33:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:33:30 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:30 --> Router Class Initialized
INFO - 2021-03-26 22:33:30 --> URI Class Initialized
INFO - 2021-03-26 22:33:30 --> Output Class Initialized
INFO - 2021-03-26 22:33:30 --> Router Class Initialized
INFO - 2021-03-26 22:33:30 --> Security Class Initialized
INFO - 2021-03-26 22:33:30 --> Output Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:30 --> Input Class Initialized
INFO - 2021-03-26 22:33:30 --> Security Class Initialized
INFO - 2021-03-26 22:33:30 --> Language Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:30 --> Input Class Initialized
ERROR - 2021-03-26 22:33:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:33:30 --> Language Class Initialized
ERROR - 2021-03-26 22:33:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:33:30 --> Config Class Initialized
INFO - 2021-03-26 22:33:30 --> Config Class Initialized
INFO - 2021-03-26 22:33:30 --> Hooks Class Initialized
INFO - 2021-03-26 22:33:30 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 22:33:30 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:33:30 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:30 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:30 --> URI Class Initialized
INFO - 2021-03-26 22:33:30 --> URI Class Initialized
INFO - 2021-03-26 22:33:30 --> Router Class Initialized
INFO - 2021-03-26 22:33:30 --> Router Class Initialized
INFO - 2021-03-26 22:33:30 --> Output Class Initialized
INFO - 2021-03-26 22:33:30 --> Output Class Initialized
INFO - 2021-03-26 22:33:30 --> Security Class Initialized
INFO - 2021-03-26 22:33:30 --> Security Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:30 --> Input Class Initialized
DEBUG - 2021-03-26 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:30 --> Input Class Initialized
INFO - 2021-03-26 22:33:30 --> Language Class Initialized
INFO - 2021-03-26 22:33:30 --> Language Class Initialized
ERROR - 2021-03-26 22:33:30 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:33:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:33:32 --> Config Class Initialized
INFO - 2021-03-26 22:33:32 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:33:32 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:33:32 --> Utf8 Class Initialized
INFO - 2021-03-26 22:33:32 --> URI Class Initialized
INFO - 2021-03-26 22:33:32 --> Router Class Initialized
INFO - 2021-03-26 22:33:32 --> Output Class Initialized
INFO - 2021-03-26 22:33:32 --> Security Class Initialized
DEBUG - 2021-03-26 22:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:33:32 --> Input Class Initialized
INFO - 2021-03-26 22:33:32 --> Language Class Initialized
INFO - 2021-03-26 22:33:32 --> Loader Class Initialized
INFO - 2021-03-26 22:33:32 --> Helper loaded: url_helper
INFO - 2021-03-26 22:33:32 --> Helper loaded: form_helper
INFO - 2021-03-26 22:33:32 --> Helper loaded: common_helper
INFO - 2021-03-26 22:33:32 --> Helper loaded: util_helper
INFO - 2021-03-26 22:33:32 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:33:32 --> Form Validation Class Initialized
INFO - 2021-03-26 22:33:32 --> Controller Class Initialized
INFO - 2021-03-26 22:33:32 --> Model Class Initialized
INFO - 2021-03-26 22:33:32 --> Model Class Initialized
INFO - 2021-03-26 22:33:32 --> Model Class Initialized
INFO - 2021-03-26 22:33:32 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:34:02 --> Final output sent to browser
DEBUG - 2021-03-26 22:34:02 --> Total execution time: 30.0437
INFO - 2021-03-26 22:35:16 --> Config Class Initialized
INFO - 2021-03-26 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:16 --> URI Class Initialized
INFO - 2021-03-26 22:35:16 --> Router Class Initialized
INFO - 2021-03-26 22:35:16 --> Output Class Initialized
INFO - 2021-03-26 22:35:16 --> Security Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:16 --> Input Class Initialized
INFO - 2021-03-26 22:35:16 --> Language Class Initialized
INFO - 2021-03-26 22:35:16 --> Loader Class Initialized
INFO - 2021-03-26 22:35:16 --> Helper loaded: url_helper
INFO - 2021-03-26 22:35:16 --> Helper loaded: form_helper
INFO - 2021-03-26 22:35:16 --> Helper loaded: common_helper
INFO - 2021-03-26 22:35:16 --> Helper loaded: util_helper
INFO - 2021-03-26 22:35:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:35:16 --> Form Validation Class Initialized
INFO - 2021-03-26 22:35:16 --> Controller Class Initialized
INFO - 2021-03-26 22:35:16 --> Model Class Initialized
INFO - 2021-03-26 22:35:16 --> Model Class Initialized
INFO - 2021-03-26 22:35:16 --> Model Class Initialized
INFO - 2021-03-26 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 22:35:16 --> Final output sent to browser
DEBUG - 2021-03-26 22:35:16 --> Total execution time: 0.0505
INFO - 2021-03-26 22:35:16 --> Config Class Initialized
INFO - 2021-03-26 22:35:16 --> Hooks Class Initialized
INFO - 2021-03-26 22:35:16 --> Config Class Initialized
INFO - 2021-03-26 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:16 --> URI Class Initialized
DEBUG - 2021-03-26 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:16 --> URI Class Initialized
INFO - 2021-03-26 22:35:16 --> Router Class Initialized
INFO - 2021-03-26 22:35:16 --> Router Class Initialized
INFO - 2021-03-26 22:35:16 --> Output Class Initialized
INFO - 2021-03-26 22:35:16 --> Output Class Initialized
INFO - 2021-03-26 22:35:16 --> Security Class Initialized
INFO - 2021-03-26 22:35:16 --> Security Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:16 --> Input Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:16 --> Input Class Initialized
INFO - 2021-03-26 22:35:16 --> Language Class Initialized
INFO - 2021-03-26 22:35:16 --> Language Class Initialized
ERROR - 2021-03-26 22:35:16 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:35:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:35:16 --> Config Class Initialized
INFO - 2021-03-26 22:35:16 --> Hooks Class Initialized
INFO - 2021-03-26 22:35:16 --> Config Class Initialized
INFO - 2021-03-26 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:16 --> URI Class Initialized
DEBUG - 2021-03-26 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:16 --> URI Class Initialized
INFO - 2021-03-26 22:35:16 --> Router Class Initialized
INFO - 2021-03-26 22:35:16 --> Router Class Initialized
INFO - 2021-03-26 22:35:16 --> Output Class Initialized
INFO - 2021-03-26 22:35:16 --> Output Class Initialized
INFO - 2021-03-26 22:35:16 --> Security Class Initialized
INFO - 2021-03-26 22:35:16 --> Security Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:16 --> Input Class Initialized
DEBUG - 2021-03-26 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:16 --> Input Class Initialized
INFO - 2021-03-26 22:35:16 --> Language Class Initialized
INFO - 2021-03-26 22:35:16 --> Language Class Initialized
ERROR - 2021-03-26 22:35:16 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 22:35:16 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 22:35:25 --> Config Class Initialized
INFO - 2021-03-26 22:35:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 22:35:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 22:35:25 --> Utf8 Class Initialized
INFO - 2021-03-26 22:35:25 --> URI Class Initialized
INFO - 2021-03-26 22:35:25 --> Router Class Initialized
INFO - 2021-03-26 22:35:25 --> Output Class Initialized
INFO - 2021-03-26 22:35:25 --> Security Class Initialized
DEBUG - 2021-03-26 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 22:35:25 --> Input Class Initialized
INFO - 2021-03-26 22:35:25 --> Language Class Initialized
INFO - 2021-03-26 22:35:25 --> Loader Class Initialized
INFO - 2021-03-26 22:35:25 --> Helper loaded: url_helper
INFO - 2021-03-26 22:35:25 --> Helper loaded: form_helper
INFO - 2021-03-26 22:35:25 --> Helper loaded: common_helper
INFO - 2021-03-26 22:35:25 --> Helper loaded: util_helper
INFO - 2021-03-26 22:35:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 22:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 22:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 22:35:25 --> Form Validation Class Initialized
INFO - 2021-03-26 22:35:25 --> Controller Class Initialized
INFO - 2021-03-26 22:35:25 --> Model Class Initialized
INFO - 2021-03-26 22:35:25 --> Model Class Initialized
INFO - 2021-03-26 22:35:25 --> Model Class Initialized
INFO - 2021-03-26 22:35:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 22:35:55 --> Final output sent to browser
DEBUG - 2021-03-26 22:35:55 --> Total execution time: 30.0495
INFO - 2021-03-26 23:14:40 --> Config Class Initialized
INFO - 2021-03-26 23:14:40 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:14:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:40 --> URI Class Initialized
INFO - 2021-03-26 23:14:40 --> Router Class Initialized
INFO - 2021-03-26 23:14:40 --> Output Class Initialized
INFO - 2021-03-26 23:14:40 --> Security Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:40 --> Input Class Initialized
INFO - 2021-03-26 23:14:40 --> Language Class Initialized
INFO - 2021-03-26 23:14:40 --> Loader Class Initialized
INFO - 2021-03-26 23:14:40 --> Helper loaded: url_helper
INFO - 2021-03-26 23:14:40 --> Helper loaded: form_helper
INFO - 2021-03-26 23:14:40 --> Helper loaded: common_helper
INFO - 2021-03-26 23:14:40 --> Helper loaded: util_helper
INFO - 2021-03-26 23:14:40 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:14:40 --> Form Validation Class Initialized
INFO - 2021-03-26 23:14:40 --> Controller Class Initialized
INFO - 2021-03-26 23:14:40 --> Model Class Initialized
INFO - 2021-03-26 23:14:40 --> Model Class Initialized
INFO - 2021-03-26 23:14:40 --> Model Class Initialized
INFO - 2021-03-26 23:14:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:14:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:14:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:14:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:14:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:14:40 --> Final output sent to browser
DEBUG - 2021-03-26 23:14:40 --> Total execution time: 0.0375
INFO - 2021-03-26 23:14:40 --> Config Class Initialized
INFO - 2021-03-26 23:14:40 --> Hooks Class Initialized
INFO - 2021-03-26 23:14:40 --> Config Class Initialized
INFO - 2021-03-26 23:14:40 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:14:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:40 --> URI Class Initialized
DEBUG - 2021-03-26 23:14:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:40 --> Router Class Initialized
INFO - 2021-03-26 23:14:40 --> URI Class Initialized
INFO - 2021-03-26 23:14:40 --> Output Class Initialized
INFO - 2021-03-26 23:14:40 --> Router Class Initialized
INFO - 2021-03-26 23:14:40 --> Security Class Initialized
INFO - 2021-03-26 23:14:40 --> Output Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:40 --> Input Class Initialized
INFO - 2021-03-26 23:14:40 --> Language Class Initialized
INFO - 2021-03-26 23:14:40 --> Security Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:40 --> Input Class Initialized
INFO - 2021-03-26 23:14:40 --> Language Class Initialized
ERROR - 2021-03-26 23:14:40 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:14:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:14:40 --> Config Class Initialized
INFO - 2021-03-26 23:14:40 --> Hooks Class Initialized
INFO - 2021-03-26 23:14:40 --> Config Class Initialized
DEBUG - 2021-03-26 23:14:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:40 --> Hooks Class Initialized
INFO - 2021-03-26 23:14:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:40 --> URI Class Initialized
DEBUG - 2021-03-26 23:14:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:40 --> Router Class Initialized
INFO - 2021-03-26 23:14:40 --> URI Class Initialized
INFO - 2021-03-26 23:14:40 --> Output Class Initialized
INFO - 2021-03-26 23:14:40 --> Router Class Initialized
INFO - 2021-03-26 23:14:40 --> Security Class Initialized
INFO - 2021-03-26 23:14:40 --> Output Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:40 --> Input Class Initialized
INFO - 2021-03-26 23:14:40 --> Language Class Initialized
INFO - 2021-03-26 23:14:40 --> Security Class Initialized
DEBUG - 2021-03-26 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:40 --> Input Class Initialized
ERROR - 2021-03-26 23:14:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:14:40 --> Language Class Initialized
ERROR - 2021-03-26 23:14:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:14:46 --> Config Class Initialized
INFO - 2021-03-26 23:14:46 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:14:46 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:46 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:46 --> URI Class Initialized
INFO - 2021-03-26 23:14:46 --> Router Class Initialized
INFO - 2021-03-26 23:14:46 --> Output Class Initialized
INFO - 2021-03-26 23:14:46 --> Security Class Initialized
DEBUG - 2021-03-26 23:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:46 --> Input Class Initialized
INFO - 2021-03-26 23:14:46 --> Language Class Initialized
INFO - 2021-03-26 23:14:46 --> Loader Class Initialized
INFO - 2021-03-26 23:14:46 --> Helper loaded: url_helper
INFO - 2021-03-26 23:14:46 --> Helper loaded: form_helper
INFO - 2021-03-26 23:14:46 --> Helper loaded: common_helper
INFO - 2021-03-26 23:14:46 --> Helper loaded: util_helper
INFO - 2021-03-26 23:14:46 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:14:46 --> Form Validation Class Initialized
INFO - 2021-03-26 23:14:46 --> Controller Class Initialized
INFO - 2021-03-26 23:14:46 --> Model Class Initialized
INFO - 2021-03-26 23:14:46 --> Model Class Initialized
INFO - 2021-03-26 23:14:46 --> Model Class Initialized
INFO - 2021-03-26 23:14:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:14:46 --> Final output sent to browser
DEBUG - 2021-03-26 23:14:46 --> Total execution time: 0.0507
INFO - 2021-03-26 23:14:59 --> Config Class Initialized
INFO - 2021-03-26 23:14:59 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:14:59 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:14:59 --> Utf8 Class Initialized
INFO - 2021-03-26 23:14:59 --> URI Class Initialized
INFO - 2021-03-26 23:14:59 --> Router Class Initialized
INFO - 2021-03-26 23:14:59 --> Output Class Initialized
INFO - 2021-03-26 23:14:59 --> Security Class Initialized
DEBUG - 2021-03-26 23:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:14:59 --> Input Class Initialized
INFO - 2021-03-26 23:14:59 --> Language Class Initialized
INFO - 2021-03-26 23:14:59 --> Loader Class Initialized
INFO - 2021-03-26 23:14:59 --> Helper loaded: url_helper
INFO - 2021-03-26 23:14:59 --> Helper loaded: form_helper
INFO - 2021-03-26 23:14:59 --> Helper loaded: common_helper
INFO - 2021-03-26 23:14:59 --> Helper loaded: util_helper
INFO - 2021-03-26 23:14:59 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:14:59 --> Form Validation Class Initialized
INFO - 2021-03-26 23:14:59 --> Controller Class Initialized
INFO - 2021-03-26 23:14:59 --> Model Class Initialized
INFO - 2021-03-26 23:14:59 --> Model Class Initialized
INFO - 2021-03-26 23:14:59 --> Model Class Initialized
ERROR - 2021-03-26 23:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 50
INFO - 2021-03-26 23:14:59 --> Final output sent to browser
DEBUG - 2021-03-26 23:14:59 --> Total execution time: 0.0750
INFO - 2021-03-26 23:17:10 --> Config Class Initialized
INFO - 2021-03-26 23:17:10 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:17:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:10 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:10 --> URI Class Initialized
INFO - 2021-03-26 23:17:10 --> Router Class Initialized
INFO - 2021-03-26 23:17:10 --> Output Class Initialized
INFO - 2021-03-26 23:17:10 --> Security Class Initialized
DEBUG - 2021-03-26 23:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:10 --> Input Class Initialized
INFO - 2021-03-26 23:17:10 --> Language Class Initialized
INFO - 2021-03-26 23:17:10 --> Loader Class Initialized
INFO - 2021-03-26 23:17:10 --> Helper loaded: url_helper
INFO - 2021-03-26 23:17:10 --> Helper loaded: form_helper
INFO - 2021-03-26 23:17:10 --> Helper loaded: common_helper
INFO - 2021-03-26 23:17:10 --> Helper loaded: util_helper
INFO - 2021-03-26 23:17:10 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:17:10 --> Form Validation Class Initialized
INFO - 2021-03-26 23:17:10 --> Controller Class Initialized
INFO - 2021-03-26 23:17:10 --> Model Class Initialized
INFO - 2021-03-26 23:17:10 --> Model Class Initialized
INFO - 2021-03-26 23:17:10 --> Model Class Initialized
INFO - 2021-03-26 23:17:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:17:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:17:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:17:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:17:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:17:10 --> Final output sent to browser
DEBUG - 2021-03-26 23:17:10 --> Total execution time: 0.0413
INFO - 2021-03-26 23:17:10 --> Config Class Initialized
INFO - 2021-03-26 23:17:10 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:17:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:10 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:10 --> URI Class Initialized
INFO - 2021-03-26 23:17:10 --> Config Class Initialized
INFO - 2021-03-26 23:17:10 --> Hooks Class Initialized
INFO - 2021-03-26 23:17:10 --> Router Class Initialized
INFO - 2021-03-26 23:17:10 --> Output Class Initialized
DEBUG - 2021-03-26 23:17:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:10 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:10 --> Security Class Initialized
INFO - 2021-03-26 23:17:10 --> URI Class Initialized
DEBUG - 2021-03-26 23:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:10 --> Input Class Initialized
INFO - 2021-03-26 23:17:10 --> Language Class Initialized
INFO - 2021-03-26 23:17:10 --> Router Class Initialized
ERROR - 2021-03-26 23:17:10 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:17:10 --> Output Class Initialized
INFO - 2021-03-26 23:17:10 --> Security Class Initialized
DEBUG - 2021-03-26 23:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:10 --> Input Class Initialized
INFO - 2021-03-26 23:17:10 --> Language Class Initialized
ERROR - 2021-03-26 23:17:10 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:17:10 --> Config Class Initialized
INFO - 2021-03-26 23:17:10 --> Hooks Class Initialized
INFO - 2021-03-26 23:17:10 --> Config Class Initialized
INFO - 2021-03-26 23:17:10 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:17:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:10 --> Utf8 Class Initialized
DEBUG - 2021-03-26 23:17:10 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:10 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:10 --> URI Class Initialized
INFO - 2021-03-26 23:17:10 --> URI Class Initialized
INFO - 2021-03-26 23:17:10 --> Router Class Initialized
INFO - 2021-03-26 23:17:10 --> Router Class Initialized
INFO - 2021-03-26 23:17:10 --> Output Class Initialized
INFO - 2021-03-26 23:17:10 --> Output Class Initialized
INFO - 2021-03-26 23:17:10 --> Security Class Initialized
INFO - 2021-03-26 23:17:10 --> Security Class Initialized
DEBUG - 2021-03-26 23:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:10 --> Input Class Initialized
INFO - 2021-03-26 23:17:10 --> Input Class Initialized
INFO - 2021-03-26 23:17:10 --> Language Class Initialized
INFO - 2021-03-26 23:17:10 --> Language Class Initialized
ERROR - 2021-03-26 23:17:10 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:17:10 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:17:13 --> Config Class Initialized
INFO - 2021-03-26 23:17:13 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:17:13 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:13 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:13 --> URI Class Initialized
INFO - 2021-03-26 23:17:13 --> Router Class Initialized
INFO - 2021-03-26 23:17:13 --> Output Class Initialized
INFO - 2021-03-26 23:17:13 --> Security Class Initialized
DEBUG - 2021-03-26 23:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:13 --> Input Class Initialized
INFO - 2021-03-26 23:17:13 --> Language Class Initialized
INFO - 2021-03-26 23:17:13 --> Loader Class Initialized
INFO - 2021-03-26 23:17:13 --> Helper loaded: url_helper
INFO - 2021-03-26 23:17:13 --> Helper loaded: form_helper
INFO - 2021-03-26 23:17:13 --> Helper loaded: common_helper
INFO - 2021-03-26 23:17:13 --> Helper loaded: util_helper
INFO - 2021-03-26 23:17:13 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:17:13 --> Form Validation Class Initialized
INFO - 2021-03-26 23:17:13 --> Controller Class Initialized
INFO - 2021-03-26 23:17:13 --> Model Class Initialized
INFO - 2021-03-26 23:17:13 --> Model Class Initialized
INFO - 2021-03-26 23:17:13 --> Model Class Initialized
INFO - 2021-03-26 23:17:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:17:13 --> Final output sent to browser
DEBUG - 2021-03-26 23:17:13 --> Total execution time: 0.0506
INFO - 2021-03-26 23:17:33 --> Config Class Initialized
INFO - 2021-03-26 23:17:33 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:17:33 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:17:33 --> Utf8 Class Initialized
INFO - 2021-03-26 23:17:33 --> URI Class Initialized
INFO - 2021-03-26 23:17:33 --> Router Class Initialized
INFO - 2021-03-26 23:17:33 --> Output Class Initialized
INFO - 2021-03-26 23:17:33 --> Security Class Initialized
DEBUG - 2021-03-26 23:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:17:33 --> Input Class Initialized
INFO - 2021-03-26 23:17:33 --> Language Class Initialized
INFO - 2021-03-26 23:17:33 --> Loader Class Initialized
INFO - 2021-03-26 23:17:33 --> Helper loaded: url_helper
INFO - 2021-03-26 23:17:33 --> Helper loaded: form_helper
INFO - 2021-03-26 23:17:33 --> Helper loaded: common_helper
INFO - 2021-03-26 23:17:33 --> Helper loaded: util_helper
INFO - 2021-03-26 23:17:33 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:17:33 --> Form Validation Class Initialized
INFO - 2021-03-26 23:17:33 --> Controller Class Initialized
INFO - 2021-03-26 23:17:33 --> Model Class Initialized
INFO - 2021-03-26 23:17:33 --> Model Class Initialized
INFO - 2021-03-26 23:17:33 --> Model Class Initialized
ERROR - 2021-03-26 23:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 50
INFO - 2021-03-26 23:18:17 --> Config Class Initialized
INFO - 2021-03-26 23:18:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:18:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:18:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:18:17 --> URI Class Initialized
INFO - 2021-03-26 23:18:17 --> Router Class Initialized
INFO - 2021-03-26 23:18:17 --> Output Class Initialized
INFO - 2021-03-26 23:18:17 --> Security Class Initialized
DEBUG - 2021-03-26 23:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:18:17 --> Input Class Initialized
INFO - 2021-03-26 23:18:17 --> Language Class Initialized
INFO - 2021-03-26 23:18:17 --> Loader Class Initialized
INFO - 2021-03-26 23:18:17 --> Helper loaded: url_helper
INFO - 2021-03-26 23:18:17 --> Helper loaded: form_helper
INFO - 2021-03-26 23:18:17 --> Helper loaded: common_helper
INFO - 2021-03-26 23:18:17 --> Helper loaded: util_helper
INFO - 2021-03-26 23:18:17 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:18:17 --> Form Validation Class Initialized
INFO - 2021-03-26 23:18:17 --> Controller Class Initialized
INFO - 2021-03-26 23:18:17 --> Model Class Initialized
INFO - 2021-03-26 23:18:17 --> Model Class Initialized
INFO - 2021-03-26 23:18:17 --> Model Class Initialized
INFO - 2021-03-26 23:18:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:18:17 --> Final output sent to browser
DEBUG - 2021-03-26 23:18:17 --> Total execution time: 0.0470
INFO - 2021-03-26 23:18:40 --> Config Class Initialized
INFO - 2021-03-26 23:18:40 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:18:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:18:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:18:40 --> URI Class Initialized
INFO - 2021-03-26 23:18:40 --> Router Class Initialized
INFO - 2021-03-26 23:18:40 --> Output Class Initialized
INFO - 2021-03-26 23:18:40 --> Security Class Initialized
DEBUG - 2021-03-26 23:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:18:40 --> Input Class Initialized
INFO - 2021-03-26 23:18:40 --> Language Class Initialized
INFO - 2021-03-26 23:18:40 --> Loader Class Initialized
INFO - 2021-03-26 23:18:40 --> Helper loaded: url_helper
INFO - 2021-03-26 23:18:40 --> Helper loaded: form_helper
INFO - 2021-03-26 23:18:40 --> Helper loaded: common_helper
INFO - 2021-03-26 23:18:40 --> Helper loaded: util_helper
INFO - 2021-03-26 23:18:40 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:18:40 --> Form Validation Class Initialized
INFO - 2021-03-26 23:18:40 --> Controller Class Initialized
INFO - 2021-03-26 23:18:40 --> Model Class Initialized
INFO - 2021-03-26 23:18:40 --> Model Class Initialized
INFO - 2021-03-26 23:18:40 --> Model Class Initialized
INFO - 2021-03-26 23:19:09 --> Config Class Initialized
INFO - 2021-03-26 23:19:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:09 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:09 --> URI Class Initialized
INFO - 2021-03-26 23:19:09 --> Router Class Initialized
INFO - 2021-03-26 23:19:09 --> Output Class Initialized
INFO - 2021-03-26 23:19:09 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:09 --> Input Class Initialized
INFO - 2021-03-26 23:19:09 --> Language Class Initialized
INFO - 2021-03-26 23:19:09 --> Loader Class Initialized
INFO - 2021-03-26 23:19:09 --> Helper loaded: url_helper
INFO - 2021-03-26 23:19:09 --> Helper loaded: form_helper
INFO - 2021-03-26 23:19:09 --> Helper loaded: common_helper
INFO - 2021-03-26 23:19:09 --> Helper loaded: util_helper
INFO - 2021-03-26 23:19:09 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:19:09 --> Form Validation Class Initialized
INFO - 2021-03-26 23:19:09 --> Controller Class Initialized
INFO - 2021-03-26 23:19:09 --> Model Class Initialized
INFO - 2021-03-26 23:19:09 --> Model Class Initialized
INFO - 2021-03-26 23:19:09 --> Model Class Initialized
INFO - 2021-03-26 23:19:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:19:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:19:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:19:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:19:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:19:09 --> Final output sent to browser
DEBUG - 2021-03-26 23:19:09 --> Total execution time: 0.0503
INFO - 2021-03-26 23:19:09 --> Config Class Initialized
INFO - 2021-03-26 23:19:09 --> Config Class Initialized
INFO - 2021-03-26 23:19:09 --> Hooks Class Initialized
INFO - 2021-03-26 23:19:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 23:19:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:09 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:09 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:09 --> URI Class Initialized
INFO - 2021-03-26 23:19:09 --> URI Class Initialized
INFO - 2021-03-26 23:19:09 --> Router Class Initialized
INFO - 2021-03-26 23:19:09 --> Router Class Initialized
INFO - 2021-03-26 23:19:09 --> Output Class Initialized
INFO - 2021-03-26 23:19:09 --> Output Class Initialized
INFO - 2021-03-26 23:19:09 --> Security Class Initialized
INFO - 2021-03-26 23:19:09 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:09 --> Input Class Initialized
INFO - 2021-03-26 23:19:09 --> Language Class Initialized
DEBUG - 2021-03-26 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:09 --> Input Class Initialized
INFO - 2021-03-26 23:19:09 --> Language Class Initialized
ERROR - 2021-03-26 23:19:09 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:19:09 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:19:09 --> Config Class Initialized
INFO - 2021-03-26 23:19:09 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:09 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:09 --> Config Class Initialized
INFO - 2021-03-26 23:19:09 --> Hooks Class Initialized
INFO - 2021-03-26 23:19:09 --> URI Class Initialized
DEBUG - 2021-03-26 23:19:09 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:09 --> Router Class Initialized
INFO - 2021-03-26 23:19:09 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:09 --> URI Class Initialized
INFO - 2021-03-26 23:19:09 --> Output Class Initialized
INFO - 2021-03-26 23:19:09 --> Router Class Initialized
INFO - 2021-03-26 23:19:09 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:09 --> Output Class Initialized
INFO - 2021-03-26 23:19:09 --> Input Class Initialized
INFO - 2021-03-26 23:19:09 --> Language Class Initialized
INFO - 2021-03-26 23:19:09 --> Security Class Initialized
ERROR - 2021-03-26 23:19:09 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:09 --> Input Class Initialized
INFO - 2021-03-26 23:19:09 --> Language Class Initialized
ERROR - 2021-03-26 23:19:09 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:19:16 --> Config Class Initialized
INFO - 2021-03-26 23:19:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:16 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:16 --> URI Class Initialized
INFO - 2021-03-26 23:19:16 --> Router Class Initialized
INFO - 2021-03-26 23:19:16 --> Output Class Initialized
INFO - 2021-03-26 23:19:16 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:16 --> Input Class Initialized
INFO - 2021-03-26 23:19:16 --> Language Class Initialized
INFO - 2021-03-26 23:19:16 --> Loader Class Initialized
INFO - 2021-03-26 23:19:16 --> Helper loaded: url_helper
INFO - 2021-03-26 23:19:16 --> Helper loaded: form_helper
INFO - 2021-03-26 23:19:16 --> Helper loaded: common_helper
INFO - 2021-03-26 23:19:16 --> Helper loaded: util_helper
INFO - 2021-03-26 23:19:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:19:16 --> Form Validation Class Initialized
INFO - 2021-03-26 23:19:16 --> Controller Class Initialized
INFO - 2021-03-26 23:19:16 --> Model Class Initialized
INFO - 2021-03-26 23:19:16 --> Model Class Initialized
INFO - 2021-03-26 23:19:16 --> Model Class Initialized
INFO - 2021-03-26 23:19:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:19:16 --> Final output sent to browser
DEBUG - 2021-03-26 23:19:16 --> Total execution time: 0.0471
INFO - 2021-03-26 23:19:26 --> Config Class Initialized
INFO - 2021-03-26 23:19:26 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:26 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:26 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:26 --> URI Class Initialized
INFO - 2021-03-26 23:19:26 --> Router Class Initialized
INFO - 2021-03-26 23:19:26 --> Output Class Initialized
INFO - 2021-03-26 23:19:26 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:26 --> Input Class Initialized
INFO - 2021-03-26 23:19:26 --> Language Class Initialized
INFO - 2021-03-26 23:19:26 --> Loader Class Initialized
INFO - 2021-03-26 23:19:26 --> Helper loaded: url_helper
INFO - 2021-03-26 23:19:26 --> Helper loaded: form_helper
INFO - 2021-03-26 23:19:26 --> Helper loaded: common_helper
INFO - 2021-03-26 23:19:26 --> Helper loaded: util_helper
INFO - 2021-03-26 23:19:26 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:19:26 --> Form Validation Class Initialized
INFO - 2021-03-26 23:19:26 --> Controller Class Initialized
INFO - 2021-03-26 23:19:26 --> Model Class Initialized
INFO - 2021-03-26 23:19:26 --> Model Class Initialized
INFO - 2021-03-26 23:19:26 --> Model Class Initialized
INFO - 2021-03-26 23:19:26 --> Final output sent to browser
DEBUG - 2021-03-26 23:19:26 --> Total execution time: 0.1114
INFO - 2021-03-26 23:19:39 --> Config Class Initialized
INFO - 2021-03-26 23:19:39 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:39 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:39 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:39 --> URI Class Initialized
INFO - 2021-03-26 23:19:39 --> Router Class Initialized
INFO - 2021-03-26 23:19:39 --> Output Class Initialized
INFO - 2021-03-26 23:19:39 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:39 --> Input Class Initialized
INFO - 2021-03-26 23:19:39 --> Language Class Initialized
INFO - 2021-03-26 23:19:39 --> Loader Class Initialized
INFO - 2021-03-26 23:19:39 --> Helper loaded: url_helper
INFO - 2021-03-26 23:19:39 --> Helper loaded: form_helper
INFO - 2021-03-26 23:19:39 --> Helper loaded: common_helper
INFO - 2021-03-26 23:19:39 --> Helper loaded: util_helper
INFO - 2021-03-26 23:19:39 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:19:39 --> Form Validation Class Initialized
INFO - 2021-03-26 23:19:39 --> Controller Class Initialized
INFO - 2021-03-26 23:19:39 --> Model Class Initialized
INFO - 2021-03-26 23:19:39 --> Model Class Initialized
INFO - 2021-03-26 23:19:39 --> Model Class Initialized
INFO - 2021-03-26 23:19:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:19:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:19:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:19:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:19:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:19:39 --> Final output sent to browser
DEBUG - 2021-03-26 23:19:39 --> Total execution time: 0.0454
INFO - 2021-03-26 23:19:39 --> Config Class Initialized
INFO - 2021-03-26 23:19:39 --> Hooks Class Initialized
INFO - 2021-03-26 23:19:39 --> Config Class Initialized
INFO - 2021-03-26 23:19:39 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:39 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:39 --> Utf8 Class Initialized
DEBUG - 2021-03-26 23:19:39 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:39 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:39 --> URI Class Initialized
INFO - 2021-03-26 23:19:39 --> Router Class Initialized
INFO - 2021-03-26 23:19:39 --> Output Class Initialized
INFO - 2021-03-26 23:19:39 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:39 --> Input Class Initialized
INFO - 2021-03-26 23:19:39 --> Language Class Initialized
ERROR - 2021-03-26 23:19:39 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:19:39 --> URI Class Initialized
INFO - 2021-03-26 23:19:39 --> Router Class Initialized
INFO - 2021-03-26 23:19:39 --> Output Class Initialized
INFO - 2021-03-26 23:19:39 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:39 --> Input Class Initialized
INFO - 2021-03-26 23:19:39 --> Config Class Initialized
INFO - 2021-03-26 23:19:39 --> Config Class Initialized
INFO - 2021-03-26 23:19:39 --> Hooks Class Initialized
INFO - 2021-03-26 23:19:39 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 23:19:39 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:39 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:39 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:39 --> URI Class Initialized
INFO - 2021-03-26 23:19:39 --> URI Class Initialized
INFO - 2021-03-26 23:19:39 --> Language Class Initialized
INFO - 2021-03-26 23:19:39 --> Router Class Initialized
INFO - 2021-03-26 23:19:39 --> Router Class Initialized
INFO - 2021-03-26 23:19:39 --> Output Class Initialized
INFO - 2021-03-26 23:19:39 --> Output Class Initialized
INFO - 2021-03-26 23:19:39 --> Security Class Initialized
INFO - 2021-03-26 23:19:39 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:39 --> Input Class Initialized
INFO - 2021-03-26 23:19:39 --> Input Class Initialized
INFO - 2021-03-26 23:19:39 --> Language Class Initialized
INFO - 2021-03-26 23:19:39 --> Language Class Initialized
ERROR - 2021-03-26 23:19:39 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:19:39 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:19:39 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:19:55 --> Config Class Initialized
INFO - 2021-03-26 23:19:55 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:19:55 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:19:55 --> Utf8 Class Initialized
INFO - 2021-03-26 23:19:55 --> URI Class Initialized
INFO - 2021-03-26 23:19:55 --> Router Class Initialized
INFO - 2021-03-26 23:19:55 --> Output Class Initialized
INFO - 2021-03-26 23:19:55 --> Security Class Initialized
DEBUG - 2021-03-26 23:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:19:55 --> Input Class Initialized
INFO - 2021-03-26 23:19:55 --> Language Class Initialized
INFO - 2021-03-26 23:19:55 --> Loader Class Initialized
INFO - 2021-03-26 23:19:55 --> Helper loaded: url_helper
INFO - 2021-03-26 23:19:55 --> Helper loaded: form_helper
INFO - 2021-03-26 23:19:55 --> Helper loaded: common_helper
INFO - 2021-03-26 23:19:55 --> Helper loaded: util_helper
INFO - 2021-03-26 23:19:55 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:19:55 --> Form Validation Class Initialized
INFO - 2021-03-26 23:19:55 --> Controller Class Initialized
INFO - 2021-03-26 23:19:55 --> Model Class Initialized
INFO - 2021-03-26 23:19:55 --> Model Class Initialized
INFO - 2021-03-26 23:19:55 --> Model Class Initialized
INFO - 2021-03-26 23:19:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:19:55 --> Final output sent to browser
DEBUG - 2021-03-26 23:19:55 --> Total execution time: 0.0477
INFO - 2021-03-26 23:23:57 --> Config Class Initialized
INFO - 2021-03-26 23:23:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:23:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:23:57 --> Utf8 Class Initialized
INFO - 2021-03-26 23:23:57 --> URI Class Initialized
INFO - 2021-03-26 23:23:57 --> Router Class Initialized
INFO - 2021-03-26 23:23:57 --> Output Class Initialized
INFO - 2021-03-26 23:23:57 --> Security Class Initialized
DEBUG - 2021-03-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:23:57 --> Input Class Initialized
INFO - 2021-03-26 23:23:57 --> Language Class Initialized
INFO - 2021-03-26 23:23:57 --> Loader Class Initialized
INFO - 2021-03-26 23:23:57 --> Helper loaded: url_helper
INFO - 2021-03-26 23:23:57 --> Helper loaded: form_helper
INFO - 2021-03-26 23:23:57 --> Helper loaded: common_helper
INFO - 2021-03-26 23:23:57 --> Helper loaded: util_helper
INFO - 2021-03-26 23:23:57 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:23:57 --> Form Validation Class Initialized
INFO - 2021-03-26 23:23:57 --> Controller Class Initialized
INFO - 2021-03-26 23:23:57 --> Model Class Initialized
INFO - 2021-03-26 23:23:57 --> Model Class Initialized
INFO - 2021-03-26 23:23:57 --> Model Class Initialized
INFO - 2021-03-26 23:23:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:23:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:23:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:23:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:23:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:23:57 --> Final output sent to browser
DEBUG - 2021-03-26 23:23:57 --> Total execution time: 0.0457
INFO - 2021-03-26 23:23:57 --> Config Class Initialized
INFO - 2021-03-26 23:23:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:23:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:23:57 --> Utf8 Class Initialized
INFO - 2021-03-26 23:23:57 --> Config Class Initialized
INFO - 2021-03-26 23:23:57 --> Hooks Class Initialized
INFO - 2021-03-26 23:23:57 --> URI Class Initialized
INFO - 2021-03-26 23:23:57 --> Router Class Initialized
DEBUG - 2021-03-26 23:23:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:23:57 --> Utf8 Class Initialized
INFO - 2021-03-26 23:23:57 --> Output Class Initialized
INFO - 2021-03-26 23:23:57 --> URI Class Initialized
INFO - 2021-03-26 23:23:57 --> Security Class Initialized
INFO - 2021-03-26 23:23:57 --> Router Class Initialized
DEBUG - 2021-03-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:23:57 --> Input Class Initialized
INFO - 2021-03-26 23:23:57 --> Output Class Initialized
INFO - 2021-03-26 23:23:57 --> Language Class Initialized
INFO - 2021-03-26 23:23:57 --> Security Class Initialized
ERROR - 2021-03-26 23:23:57 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:23:57 --> Input Class Initialized
INFO - 2021-03-26 23:23:57 --> Language Class Initialized
ERROR - 2021-03-26 23:23:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:23:57 --> Config Class Initialized
INFO - 2021-03-26 23:23:57 --> Hooks Class Initialized
INFO - 2021-03-26 23:23:57 --> Config Class Initialized
INFO - 2021-03-26 23:23:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:23:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:23:57 --> Utf8 Class Initialized
DEBUG - 2021-03-26 23:23:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:23:57 --> Utf8 Class Initialized
INFO - 2021-03-26 23:23:57 --> URI Class Initialized
INFO - 2021-03-26 23:23:57 --> URI Class Initialized
INFO - 2021-03-26 23:23:57 --> Router Class Initialized
INFO - 2021-03-26 23:23:57 --> Router Class Initialized
INFO - 2021-03-26 23:23:57 --> Output Class Initialized
INFO - 2021-03-26 23:23:57 --> Output Class Initialized
INFO - 2021-03-26 23:23:57 --> Security Class Initialized
INFO - 2021-03-26 23:23:57 --> Security Class Initialized
DEBUG - 2021-03-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:23:57 --> Input Class Initialized
INFO - 2021-03-26 23:23:57 --> Input Class Initialized
INFO - 2021-03-26 23:23:57 --> Language Class Initialized
INFO - 2021-03-26 23:23:57 --> Language Class Initialized
ERROR - 2021-03-26 23:23:57 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:23:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:24:01 --> Config Class Initialized
INFO - 2021-03-26 23:24:01 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:24:01 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:24:01 --> Utf8 Class Initialized
INFO - 2021-03-26 23:24:01 --> URI Class Initialized
INFO - 2021-03-26 23:24:01 --> Router Class Initialized
INFO - 2021-03-26 23:24:01 --> Output Class Initialized
INFO - 2021-03-26 23:24:01 --> Security Class Initialized
DEBUG - 2021-03-26 23:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:24:01 --> Input Class Initialized
INFO - 2021-03-26 23:24:01 --> Language Class Initialized
INFO - 2021-03-26 23:24:01 --> Loader Class Initialized
INFO - 2021-03-26 23:24:01 --> Helper loaded: url_helper
INFO - 2021-03-26 23:24:01 --> Helper loaded: form_helper
INFO - 2021-03-26 23:24:01 --> Helper loaded: common_helper
INFO - 2021-03-26 23:24:01 --> Helper loaded: util_helper
INFO - 2021-03-26 23:24:01 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:24:01 --> Form Validation Class Initialized
INFO - 2021-03-26 23:24:01 --> Controller Class Initialized
INFO - 2021-03-26 23:24:01 --> Model Class Initialized
INFO - 2021-03-26 23:24:01 --> Model Class Initialized
INFO - 2021-03-26 23:24:01 --> Model Class Initialized
INFO - 2021-03-26 23:25:19 --> Config Class Initialized
INFO - 2021-03-26 23:25:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:25:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:19 --> URI Class Initialized
INFO - 2021-03-26 23:25:19 --> Router Class Initialized
INFO - 2021-03-26 23:25:19 --> Output Class Initialized
INFO - 2021-03-26 23:25:19 --> Security Class Initialized
DEBUG - 2021-03-26 23:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:25:19 --> Input Class Initialized
INFO - 2021-03-26 23:25:19 --> Language Class Initialized
INFO - 2021-03-26 23:25:19 --> Loader Class Initialized
INFO - 2021-03-26 23:25:19 --> Helper loaded: url_helper
INFO - 2021-03-26 23:25:19 --> Helper loaded: form_helper
INFO - 2021-03-26 23:25:19 --> Helper loaded: common_helper
INFO - 2021-03-26 23:25:19 --> Helper loaded: util_helper
INFO - 2021-03-26 23:25:19 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:25:19 --> Form Validation Class Initialized
INFO - 2021-03-26 23:25:19 --> Controller Class Initialized
INFO - 2021-03-26 23:25:19 --> Model Class Initialized
INFO - 2021-03-26 23:25:19 --> Model Class Initialized
INFO - 2021-03-26 23:25:19 --> Model Class Initialized
INFO - 2021-03-26 23:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:25:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:25:19 --> Final output sent to browser
DEBUG - 2021-03-26 23:25:19 --> Total execution time: 0.0500
INFO - 2021-03-26 23:25:19 --> Config Class Initialized
INFO - 2021-03-26 23:25:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:25:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:19 --> URI Class Initialized
INFO - 2021-03-26 23:25:19 --> Router Class Initialized
INFO - 2021-03-26 23:25:19 --> Output Class Initialized
INFO - 2021-03-26 23:25:19 --> Security Class Initialized
DEBUG - 2021-03-26 23:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:25:19 --> Input Class Initialized
INFO - 2021-03-26 23:25:19 --> Language Class Initialized
ERROR - 2021-03-26 23:25:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:25:19 --> Config Class Initialized
INFO - 2021-03-26 23:25:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:25:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:19 --> URI Class Initialized
INFO - 2021-03-26 23:25:19 --> Router Class Initialized
INFO - 2021-03-26 23:25:19 --> Output Class Initialized
INFO - 2021-03-26 23:25:19 --> Security Class Initialized
DEBUG - 2021-03-26 23:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:25:19 --> Input Class Initialized
INFO - 2021-03-26 23:25:19 --> Language Class Initialized
ERROR - 2021-03-26 23:25:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:25:19 --> Config Class Initialized
INFO - 2021-03-26 23:25:19 --> Config Class Initialized
INFO - 2021-03-26 23:25:19 --> Hooks Class Initialized
INFO - 2021-03-26 23:25:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 23:25:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:19 --> URI Class Initialized
INFO - 2021-03-26 23:25:19 --> URI Class Initialized
INFO - 2021-03-26 23:25:19 --> Router Class Initialized
INFO - 2021-03-26 23:25:19 --> Router Class Initialized
INFO - 2021-03-26 23:25:19 --> Output Class Initialized
INFO - 2021-03-26 23:25:19 --> Output Class Initialized
INFO - 2021-03-26 23:25:19 --> Security Class Initialized
INFO - 2021-03-26 23:25:19 --> Security Class Initialized
DEBUG - 2021-03-26 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:25:19 --> Input Class Initialized
INFO - 2021-03-26 23:25:19 --> Input Class Initialized
INFO - 2021-03-26 23:25:19 --> Language Class Initialized
INFO - 2021-03-26 23:25:19 --> Language Class Initialized
ERROR - 2021-03-26 23:25:19 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:25:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:25:22 --> Config Class Initialized
INFO - 2021-03-26 23:25:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:25:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:25:22 --> Utf8 Class Initialized
INFO - 2021-03-26 23:25:22 --> URI Class Initialized
INFO - 2021-03-26 23:25:22 --> Router Class Initialized
INFO - 2021-03-26 23:25:22 --> Output Class Initialized
INFO - 2021-03-26 23:25:22 --> Security Class Initialized
DEBUG - 2021-03-26 23:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:25:22 --> Input Class Initialized
INFO - 2021-03-26 23:25:22 --> Language Class Initialized
INFO - 2021-03-26 23:25:22 --> Loader Class Initialized
INFO - 2021-03-26 23:25:22 --> Helper loaded: url_helper
INFO - 2021-03-26 23:25:22 --> Helper loaded: form_helper
INFO - 2021-03-26 23:25:22 --> Helper loaded: common_helper
INFO - 2021-03-26 23:25:22 --> Helper loaded: util_helper
INFO - 2021-03-26 23:25:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:25:22 --> Form Validation Class Initialized
INFO - 2021-03-26 23:25:22 --> Controller Class Initialized
INFO - 2021-03-26 23:25:22 --> Model Class Initialized
INFO - 2021-03-26 23:25:22 --> Model Class Initialized
INFO - 2021-03-26 23:25:22 --> Model Class Initialized
INFO - 2021-03-26 23:25:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:25:22 --> Final output sent to browser
DEBUG - 2021-03-26 23:25:22 --> Total execution time: 0.0362
INFO - 2021-03-26 23:28:47 --> Config Class Initialized
INFO - 2021-03-26 23:28:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:47 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:47 --> URI Class Initialized
INFO - 2021-03-26 23:28:47 --> Router Class Initialized
INFO - 2021-03-26 23:28:47 --> Output Class Initialized
INFO - 2021-03-26 23:28:47 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:47 --> Input Class Initialized
INFO - 2021-03-26 23:28:47 --> Language Class Initialized
INFO - 2021-03-26 23:28:47 --> Loader Class Initialized
INFO - 2021-03-26 23:28:47 --> Helper loaded: url_helper
INFO - 2021-03-26 23:28:47 --> Helper loaded: form_helper
INFO - 2021-03-26 23:28:47 --> Helper loaded: common_helper
INFO - 2021-03-26 23:28:47 --> Helper loaded: util_helper
INFO - 2021-03-26 23:28:47 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:28:47 --> Form Validation Class Initialized
INFO - 2021-03-26 23:28:47 --> Controller Class Initialized
INFO - 2021-03-26 23:28:47 --> Model Class Initialized
INFO - 2021-03-26 23:28:47 --> Model Class Initialized
INFO - 2021-03-26 23:28:47 --> Model Class Initialized
INFO - 2021-03-26 23:28:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:28:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:28:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:28:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:28:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:28:47 --> Final output sent to browser
DEBUG - 2021-03-26 23:28:47 --> Total execution time: 0.0536
INFO - 2021-03-26 23:28:47 --> Config Class Initialized
INFO - 2021-03-26 23:28:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:47 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:47 --> URI Class Initialized
INFO - 2021-03-26 23:28:47 --> Router Class Initialized
INFO - 2021-03-26 23:28:47 --> Output Class Initialized
INFO - 2021-03-26 23:28:47 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:47 --> Input Class Initialized
INFO - 2021-03-26 23:28:47 --> Language Class Initialized
ERROR - 2021-03-26 23:28:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:28:47 --> Config Class Initialized
INFO - 2021-03-26 23:28:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:47 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:47 --> URI Class Initialized
INFO - 2021-03-26 23:28:47 --> Router Class Initialized
INFO - 2021-03-26 23:28:47 --> Output Class Initialized
INFO - 2021-03-26 23:28:47 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:47 --> Input Class Initialized
INFO - 2021-03-26 23:28:47 --> Language Class Initialized
ERROR - 2021-03-26 23:28:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:28:47 --> Config Class Initialized
INFO - 2021-03-26 23:28:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:47 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:47 --> URI Class Initialized
INFO - 2021-03-26 23:28:47 --> Router Class Initialized
INFO - 2021-03-26 23:28:47 --> Output Class Initialized
INFO - 2021-03-26 23:28:47 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:47 --> Input Class Initialized
INFO - 2021-03-26 23:28:47 --> Language Class Initialized
ERROR - 2021-03-26 23:28:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:28:47 --> Config Class Initialized
INFO - 2021-03-26 23:28:47 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:47 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:47 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:47 --> URI Class Initialized
INFO - 2021-03-26 23:28:47 --> Router Class Initialized
INFO - 2021-03-26 23:28:47 --> Output Class Initialized
INFO - 2021-03-26 23:28:47 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:47 --> Input Class Initialized
INFO - 2021-03-26 23:28:47 --> Language Class Initialized
ERROR - 2021-03-26 23:28:47 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:28:54 --> Config Class Initialized
INFO - 2021-03-26 23:28:54 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:28:54 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:28:54 --> Utf8 Class Initialized
INFO - 2021-03-26 23:28:54 --> URI Class Initialized
INFO - 2021-03-26 23:28:54 --> Router Class Initialized
INFO - 2021-03-26 23:28:54 --> Output Class Initialized
INFO - 2021-03-26 23:28:54 --> Security Class Initialized
DEBUG - 2021-03-26 23:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:28:54 --> Input Class Initialized
INFO - 2021-03-26 23:28:54 --> Language Class Initialized
INFO - 2021-03-26 23:28:54 --> Loader Class Initialized
INFO - 2021-03-26 23:28:54 --> Helper loaded: url_helper
INFO - 2021-03-26 23:28:54 --> Helper loaded: form_helper
INFO - 2021-03-26 23:28:54 --> Helper loaded: common_helper
INFO - 2021-03-26 23:28:54 --> Helper loaded: util_helper
INFO - 2021-03-26 23:28:54 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:28:54 --> Form Validation Class Initialized
INFO - 2021-03-26 23:28:54 --> Controller Class Initialized
INFO - 2021-03-26 23:28:54 --> Model Class Initialized
INFO - 2021-03-26 23:28:54 --> Model Class Initialized
INFO - 2021-03-26 23:28:54 --> Model Class Initialized
INFO - 2021-03-26 23:28:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:28:54 --> Final output sent to browser
DEBUG - 2021-03-26 23:28:54 --> Total execution time: 0.0464
INFO - 2021-03-26 23:30:17 --> Config Class Initialized
INFO - 2021-03-26 23:30:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:30:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:17 --> URI Class Initialized
INFO - 2021-03-26 23:30:17 --> Router Class Initialized
INFO - 2021-03-26 23:30:17 --> Output Class Initialized
INFO - 2021-03-26 23:30:17 --> Security Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:17 --> Input Class Initialized
INFO - 2021-03-26 23:30:17 --> Language Class Initialized
INFO - 2021-03-26 23:30:17 --> Loader Class Initialized
INFO - 2021-03-26 23:30:17 --> Helper loaded: url_helper
INFO - 2021-03-26 23:30:17 --> Helper loaded: form_helper
INFO - 2021-03-26 23:30:17 --> Helper loaded: common_helper
INFO - 2021-03-26 23:30:17 --> Helper loaded: util_helper
INFO - 2021-03-26 23:30:17 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:30:17 --> Form Validation Class Initialized
INFO - 2021-03-26 23:30:17 --> Controller Class Initialized
INFO - 2021-03-26 23:30:17 --> Model Class Initialized
INFO - 2021-03-26 23:30:17 --> Model Class Initialized
INFO - 2021-03-26 23:30:17 --> Model Class Initialized
INFO - 2021-03-26 23:30:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:30:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:30:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:30:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:30:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:30:17 --> Final output sent to browser
DEBUG - 2021-03-26 23:30:17 --> Total execution time: 0.0528
INFO - 2021-03-26 23:30:17 --> Config Class Initialized
INFO - 2021-03-26 23:30:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:30:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:17 --> URI Class Initialized
INFO - 2021-03-26 23:30:17 --> Router Class Initialized
INFO - 2021-03-26 23:30:17 --> Output Class Initialized
INFO - 2021-03-26 23:30:17 --> Security Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:17 --> Input Class Initialized
INFO - 2021-03-26 23:30:17 --> Config Class Initialized
INFO - 2021-03-26 23:30:17 --> Language Class Initialized
INFO - 2021-03-26 23:30:17 --> Hooks Class Initialized
ERROR - 2021-03-26 23:30:17 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:30:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:17 --> URI Class Initialized
INFO - 2021-03-26 23:30:17 --> Router Class Initialized
INFO - 2021-03-26 23:30:17 --> Output Class Initialized
INFO - 2021-03-26 23:30:17 --> Security Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:17 --> Input Class Initialized
INFO - 2021-03-26 23:30:17 --> Language Class Initialized
ERROR - 2021-03-26 23:30:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:30:17 --> Config Class Initialized
INFO - 2021-03-26 23:30:17 --> Hooks Class Initialized
INFO - 2021-03-26 23:30:17 --> Config Class Initialized
INFO - 2021-03-26 23:30:17 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:30:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:17 --> URI Class Initialized
DEBUG - 2021-03-26 23:30:17 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:17 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:17 --> URI Class Initialized
INFO - 2021-03-26 23:30:17 --> Router Class Initialized
INFO - 2021-03-26 23:30:17 --> Router Class Initialized
INFO - 2021-03-26 23:30:17 --> Output Class Initialized
INFO - 2021-03-26 23:30:17 --> Output Class Initialized
INFO - 2021-03-26 23:30:17 --> Security Class Initialized
INFO - 2021-03-26 23:30:17 --> Security Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:17 --> Input Class Initialized
INFO - 2021-03-26 23:30:17 --> Language Class Initialized
DEBUG - 2021-03-26 23:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:17 --> Input Class Initialized
INFO - 2021-03-26 23:30:17 --> Language Class Initialized
ERROR - 2021-03-26 23:30:17 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:30:17 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:30:22 --> Config Class Initialized
INFO - 2021-03-26 23:30:22 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:30:22 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:30:22 --> Utf8 Class Initialized
INFO - 2021-03-26 23:30:22 --> URI Class Initialized
INFO - 2021-03-26 23:30:22 --> Router Class Initialized
INFO - 2021-03-26 23:30:22 --> Output Class Initialized
INFO - 2021-03-26 23:30:22 --> Security Class Initialized
DEBUG - 2021-03-26 23:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:30:22 --> Input Class Initialized
INFO - 2021-03-26 23:30:22 --> Language Class Initialized
INFO - 2021-03-26 23:30:22 --> Loader Class Initialized
INFO - 2021-03-26 23:30:22 --> Helper loaded: url_helper
INFO - 2021-03-26 23:30:22 --> Helper loaded: form_helper
INFO - 2021-03-26 23:30:22 --> Helper loaded: common_helper
INFO - 2021-03-26 23:30:22 --> Helper loaded: util_helper
INFO - 2021-03-26 23:30:22 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:30:22 --> Form Validation Class Initialized
INFO - 2021-03-26 23:30:22 --> Controller Class Initialized
INFO - 2021-03-26 23:30:22 --> Model Class Initialized
INFO - 2021-03-26 23:30:22 --> Model Class Initialized
INFO - 2021-03-26 23:30:22 --> Model Class Initialized
INFO - 2021-03-26 23:30:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:30:22 --> Final output sent to browser
DEBUG - 2021-03-26 23:30:22 --> Total execution time: 0.0366
INFO - 2021-03-26 23:34:11 --> Config Class Initialized
INFO - 2021-03-26 23:34:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:11 --> URI Class Initialized
INFO - 2021-03-26 23:34:11 --> Router Class Initialized
INFO - 2021-03-26 23:34:11 --> Output Class Initialized
INFO - 2021-03-26 23:34:11 --> Security Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:11 --> Input Class Initialized
INFO - 2021-03-26 23:34:11 --> Language Class Initialized
INFO - 2021-03-26 23:34:11 --> Loader Class Initialized
INFO - 2021-03-26 23:34:11 --> Helper loaded: url_helper
INFO - 2021-03-26 23:34:11 --> Helper loaded: form_helper
INFO - 2021-03-26 23:34:11 --> Helper loaded: common_helper
INFO - 2021-03-26 23:34:11 --> Helper loaded: util_helper
INFO - 2021-03-26 23:34:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:34:11 --> Form Validation Class Initialized
INFO - 2021-03-26 23:34:11 --> Controller Class Initialized
INFO - 2021-03-26 23:34:11 --> Model Class Initialized
INFO - 2021-03-26 23:34:11 --> Model Class Initialized
INFO - 2021-03-26 23:34:11 --> Model Class Initialized
INFO - 2021-03-26 23:34:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:34:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:34:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:34:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:34:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:34:11 --> Final output sent to browser
DEBUG - 2021-03-26 23:34:11 --> Total execution time: 0.0489
INFO - 2021-03-26 23:34:11 --> Config Class Initialized
INFO - 2021-03-26 23:34:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:11 --> URI Class Initialized
INFO - 2021-03-26 23:34:11 --> Router Class Initialized
INFO - 2021-03-26 23:34:11 --> Output Class Initialized
INFO - 2021-03-26 23:34:11 --> Security Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:11 --> Input Class Initialized
INFO - 2021-03-26 23:34:11 --> Language Class Initialized
ERROR - 2021-03-26 23:34:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:34:11 --> Config Class Initialized
INFO - 2021-03-26 23:34:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:11 --> URI Class Initialized
INFO - 2021-03-26 23:34:11 --> Router Class Initialized
INFO - 2021-03-26 23:34:11 --> Output Class Initialized
INFO - 2021-03-26 23:34:11 --> Security Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:11 --> Input Class Initialized
INFO - 2021-03-26 23:34:11 --> Language Class Initialized
ERROR - 2021-03-26 23:34:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:34:11 --> Config Class Initialized
INFO - 2021-03-26 23:34:11 --> Hooks Class Initialized
INFO - 2021-03-26 23:34:11 --> Config Class Initialized
INFO - 2021-03-26 23:34:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:11 --> URI Class Initialized
DEBUG - 2021-03-26 23:34:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:11 --> Router Class Initialized
INFO - 2021-03-26 23:34:11 --> URI Class Initialized
INFO - 2021-03-26 23:34:11 --> Router Class Initialized
INFO - 2021-03-26 23:34:11 --> Output Class Initialized
INFO - 2021-03-26 23:34:11 --> Security Class Initialized
INFO - 2021-03-26 23:34:11 --> Output Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:11 --> Security Class Initialized
INFO - 2021-03-26 23:34:11 --> Input Class Initialized
INFO - 2021-03-26 23:34:11 --> Language Class Initialized
DEBUG - 2021-03-26 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:11 --> Input Class Initialized
INFO - 2021-03-26 23:34:11 --> Language Class Initialized
ERROR - 2021-03-26 23:34:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:34:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:34:19 --> Config Class Initialized
INFO - 2021-03-26 23:34:19 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:19 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:19 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:19 --> URI Class Initialized
INFO - 2021-03-26 23:34:19 --> Router Class Initialized
INFO - 2021-03-26 23:34:19 --> Output Class Initialized
INFO - 2021-03-26 23:34:19 --> Security Class Initialized
DEBUG - 2021-03-26 23:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:19 --> Input Class Initialized
INFO - 2021-03-26 23:34:19 --> Language Class Initialized
INFO - 2021-03-26 23:34:19 --> Loader Class Initialized
INFO - 2021-03-26 23:34:19 --> Helper loaded: url_helper
INFO - 2021-03-26 23:34:19 --> Helper loaded: form_helper
INFO - 2021-03-26 23:34:19 --> Helper loaded: common_helper
INFO - 2021-03-26 23:34:19 --> Helper loaded: util_helper
INFO - 2021-03-26 23:34:19 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:34:19 --> Form Validation Class Initialized
INFO - 2021-03-26 23:34:19 --> Controller Class Initialized
INFO - 2021-03-26 23:34:19 --> Model Class Initialized
INFO - 2021-03-26 23:34:19 --> Model Class Initialized
INFO - 2021-03-26 23:34:19 --> Model Class Initialized
INFO - 2021-03-26 23:34:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:34:19 --> Final output sent to browser
DEBUG - 2021-03-26 23:34:19 --> Total execution time: 0.0475
INFO - 2021-03-26 23:34:57 --> Config Class Initialized
INFO - 2021-03-26 23:34:57 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:34:57 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:34:57 --> Utf8 Class Initialized
INFO - 2021-03-26 23:34:57 --> URI Class Initialized
INFO - 2021-03-26 23:34:57 --> Router Class Initialized
INFO - 2021-03-26 23:34:57 --> Output Class Initialized
INFO - 2021-03-26 23:34:57 --> Security Class Initialized
DEBUG - 2021-03-26 23:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:34:57 --> Input Class Initialized
INFO - 2021-03-26 23:34:57 --> Language Class Initialized
INFO - 2021-03-26 23:34:57 --> Loader Class Initialized
INFO - 2021-03-26 23:34:57 --> Helper loaded: url_helper
INFO - 2021-03-26 23:34:57 --> Helper loaded: form_helper
INFO - 2021-03-26 23:34:57 --> Helper loaded: common_helper
INFO - 2021-03-26 23:34:57 --> Helper loaded: util_helper
INFO - 2021-03-26 23:34:57 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:34:57 --> Form Validation Class Initialized
INFO - 2021-03-26 23:34:57 --> Controller Class Initialized
INFO - 2021-03-26 23:34:57 --> Model Class Initialized
INFO - 2021-03-26 23:34:57 --> Model Class Initialized
INFO - 2021-03-26 23:34:57 --> Model Class Initialized
INFO - 2021-03-26 23:34:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:34:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:34:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:34:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:34:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:34:57 --> Final output sent to browser
DEBUG - 2021-03-26 23:34:57 --> Total execution time: 0.0525
INFO - 2021-03-26 23:35:20 --> Config Class Initialized
INFO - 2021-03-26 23:35:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:35:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:20 --> Utf8 Class Initialized
INFO - 2021-03-26 23:35:20 --> URI Class Initialized
INFO - 2021-03-26 23:35:20 --> Router Class Initialized
INFO - 2021-03-26 23:35:20 --> Output Class Initialized
INFO - 2021-03-26 23:35:20 --> Security Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:20 --> Input Class Initialized
INFO - 2021-03-26 23:35:20 --> Language Class Initialized
INFO - 2021-03-26 23:35:20 --> Loader Class Initialized
INFO - 2021-03-26 23:35:20 --> Helper loaded: url_helper
INFO - 2021-03-26 23:35:20 --> Helper loaded: form_helper
INFO - 2021-03-26 23:35:20 --> Helper loaded: common_helper
INFO - 2021-03-26 23:35:20 --> Helper loaded: util_helper
INFO - 2021-03-26 23:35:20 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:35:20 --> Form Validation Class Initialized
INFO - 2021-03-26 23:35:20 --> Controller Class Initialized
INFO - 2021-03-26 23:35:20 --> Model Class Initialized
INFO - 2021-03-26 23:35:20 --> Model Class Initialized
INFO - 2021-03-26 23:35:20 --> Model Class Initialized
INFO - 2021-03-26 23:35:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:35:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:35:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:35:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:35:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:35:20 --> Final output sent to browser
DEBUG - 2021-03-26 23:35:20 --> Total execution time: 0.0458
INFO - 2021-03-26 23:35:20 --> Config Class Initialized
INFO - 2021-03-26 23:35:20 --> Hooks Class Initialized
INFO - 2021-03-26 23:35:20 --> Config Class Initialized
INFO - 2021-03-26 23:35:20 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:35:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:20 --> Utf8 Class Initialized
DEBUG - 2021-03-26 23:35:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:20 --> Utf8 Class Initialized
INFO - 2021-03-26 23:35:20 --> URI Class Initialized
INFO - 2021-03-26 23:35:20 --> URI Class Initialized
INFO - 2021-03-26 23:35:20 --> Router Class Initialized
INFO - 2021-03-26 23:35:20 --> Router Class Initialized
INFO - 2021-03-26 23:35:20 --> Output Class Initialized
INFO - 2021-03-26 23:35:20 --> Output Class Initialized
INFO - 2021-03-26 23:35:20 --> Config Class Initialized
INFO - 2021-03-26 23:35:20 --> Config Class Initialized
INFO - 2021-03-26 23:35:20 --> Security Class Initialized
INFO - 2021-03-26 23:35:20 --> Hooks Class Initialized
INFO - 2021-03-26 23:35:20 --> Hooks Class Initialized
INFO - 2021-03-26 23:35:20 --> Security Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:20 --> Input Class Initialized
INFO - 2021-03-26 23:35:20 --> Language Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:20 --> Input Class Initialized
INFO - 2021-03-26 23:35:20 --> Language Class Initialized
DEBUG - 2021-03-26 23:35:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:20 --> Utf8 Class Initialized
ERROR - 2021-03-26 23:35:20 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:35:20 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:35:20 --> URI Class Initialized
DEBUG - 2021-03-26 23:35:20 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:20 --> Utf8 Class Initialized
INFO - 2021-03-26 23:35:20 --> Router Class Initialized
INFO - 2021-03-26 23:35:20 --> URI Class Initialized
INFO - 2021-03-26 23:35:20 --> Output Class Initialized
INFO - 2021-03-26 23:35:20 --> Router Class Initialized
INFO - 2021-03-26 23:35:20 --> Security Class Initialized
INFO - 2021-03-26 23:35:20 --> Output Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:20 --> Input Class Initialized
INFO - 2021-03-26 23:35:20 --> Security Class Initialized
INFO - 2021-03-26 23:35:20 --> Language Class Initialized
DEBUG - 2021-03-26 23:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:20 --> Input Class Initialized
ERROR - 2021-03-26 23:35:20 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:35:20 --> Language Class Initialized
ERROR - 2021-03-26 23:35:20 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:35:28 --> Config Class Initialized
INFO - 2021-03-26 23:35:28 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:35:28 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:35:28 --> Utf8 Class Initialized
INFO - 2021-03-26 23:35:28 --> URI Class Initialized
INFO - 2021-03-26 23:35:28 --> Router Class Initialized
INFO - 2021-03-26 23:35:28 --> Output Class Initialized
INFO - 2021-03-26 23:35:28 --> Security Class Initialized
DEBUG - 2021-03-26 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:35:28 --> Input Class Initialized
INFO - 2021-03-26 23:35:28 --> Language Class Initialized
INFO - 2021-03-26 23:35:28 --> Loader Class Initialized
INFO - 2021-03-26 23:35:28 --> Helper loaded: url_helper
INFO - 2021-03-26 23:35:28 --> Helper loaded: form_helper
INFO - 2021-03-26 23:35:28 --> Helper loaded: common_helper
INFO - 2021-03-26 23:35:28 --> Helper loaded: util_helper
INFO - 2021-03-26 23:35:28 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:35:28 --> Form Validation Class Initialized
INFO - 2021-03-26 23:35:28 --> Controller Class Initialized
INFO - 2021-03-26 23:35:28 --> Model Class Initialized
INFO - 2021-03-26 23:35:28 --> Model Class Initialized
INFO - 2021-03-26 23:35:28 --> Model Class Initialized
INFO - 2021-03-26 23:35:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:35:28 --> Final output sent to browser
DEBUG - 2021-03-26 23:35:28 --> Total execution time: 0.0436
INFO - 2021-03-26 23:37:11 --> Config Class Initialized
INFO - 2021-03-26 23:37:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:37:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:37:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:11 --> URI Class Initialized
INFO - 2021-03-26 23:37:11 --> Router Class Initialized
INFO - 2021-03-26 23:37:11 --> Output Class Initialized
INFO - 2021-03-26 23:37:11 --> Security Class Initialized
DEBUG - 2021-03-26 23:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:37:11 --> Input Class Initialized
INFO - 2021-03-26 23:37:11 --> Language Class Initialized
INFO - 2021-03-26 23:37:11 --> Loader Class Initialized
INFO - 2021-03-26 23:37:11 --> Helper loaded: url_helper
INFO - 2021-03-26 23:37:11 --> Helper loaded: form_helper
INFO - 2021-03-26 23:37:11 --> Helper loaded: common_helper
INFO - 2021-03-26 23:37:11 --> Helper loaded: util_helper
INFO - 2021-03-26 23:37:11 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:37:11 --> Form Validation Class Initialized
INFO - 2021-03-26 23:37:11 --> Controller Class Initialized
INFO - 2021-03-26 23:37:11 --> Model Class Initialized
INFO - 2021-03-26 23:37:11 --> Model Class Initialized
INFO - 2021-03-26 23:37:11 --> Model Class Initialized
INFO - 2021-03-26 23:37:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:37:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:37:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:37:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:37:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:37:11 --> Final output sent to browser
DEBUG - 2021-03-26 23:37:11 --> Total execution time: 0.0460
INFO - 2021-03-26 23:37:11 --> Config Class Initialized
INFO - 2021-03-26 23:37:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:37:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:37:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:11 --> Config Class Initialized
INFO - 2021-03-26 23:37:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:37:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:37:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:11 --> URI Class Initialized
INFO - 2021-03-26 23:37:11 --> Router Class Initialized
INFO - 2021-03-26 23:37:11 --> Output Class Initialized
INFO - 2021-03-26 23:37:11 --> URI Class Initialized
INFO - 2021-03-26 23:37:11 --> Security Class Initialized
INFO - 2021-03-26 23:37:11 --> Router Class Initialized
DEBUG - 2021-03-26 23:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:37:11 --> Input Class Initialized
INFO - 2021-03-26 23:37:11 --> Output Class Initialized
INFO - 2021-03-26 23:37:11 --> Language Class Initialized
INFO - 2021-03-26 23:37:11 --> Security Class Initialized
ERROR - 2021-03-26 23:37:11 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:37:11 --> Input Class Initialized
INFO - 2021-03-26 23:37:11 --> Language Class Initialized
ERROR - 2021-03-26 23:37:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:37:11 --> Config Class Initialized
INFO - 2021-03-26 23:37:11 --> Hooks Class Initialized
INFO - 2021-03-26 23:37:11 --> Config Class Initialized
INFO - 2021-03-26 23:37:11 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-03-26 23:37:11 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:37:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:11 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:11 --> URI Class Initialized
INFO - 2021-03-26 23:37:11 --> URI Class Initialized
INFO - 2021-03-26 23:37:11 --> Router Class Initialized
INFO - 2021-03-26 23:37:11 --> Router Class Initialized
INFO - 2021-03-26 23:37:11 --> Output Class Initialized
INFO - 2021-03-26 23:37:11 --> Output Class Initialized
INFO - 2021-03-26 23:37:11 --> Security Class Initialized
INFO - 2021-03-26 23:37:11 --> Security Class Initialized
DEBUG - 2021-03-26 23:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:37:11 --> Input Class Initialized
INFO - 2021-03-26 23:37:11 --> Input Class Initialized
INFO - 2021-03-26 23:37:11 --> Language Class Initialized
INFO - 2021-03-26 23:37:11 --> Language Class Initialized
ERROR - 2021-03-26 23:37:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-26 23:37:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:37:16 --> Config Class Initialized
INFO - 2021-03-26 23:37:16 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:37:16 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:37:16 --> Utf8 Class Initialized
INFO - 2021-03-26 23:37:16 --> URI Class Initialized
INFO - 2021-03-26 23:37:16 --> Router Class Initialized
INFO - 2021-03-26 23:37:16 --> Output Class Initialized
INFO - 2021-03-26 23:37:16 --> Security Class Initialized
DEBUG - 2021-03-26 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:37:16 --> Input Class Initialized
INFO - 2021-03-26 23:37:16 --> Language Class Initialized
INFO - 2021-03-26 23:37:16 --> Loader Class Initialized
INFO - 2021-03-26 23:37:16 --> Helper loaded: url_helper
INFO - 2021-03-26 23:37:16 --> Helper loaded: form_helper
INFO - 2021-03-26 23:37:16 --> Helper loaded: common_helper
INFO - 2021-03-26 23:37:16 --> Helper loaded: util_helper
INFO - 2021-03-26 23:37:16 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:37:16 --> Form Validation Class Initialized
INFO - 2021-03-26 23:37:16 --> Controller Class Initialized
INFO - 2021-03-26 23:37:16 --> Model Class Initialized
INFO - 2021-03-26 23:37:16 --> Model Class Initialized
INFO - 2021-03-26 23:37:16 --> Model Class Initialized
INFO - 2021-03-26 23:37:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:37:16 --> Final output sent to browser
DEBUG - 2021-03-26 23:37:16 --> Total execution time: 0.0470
INFO - 2021-03-26 23:38:36 --> Config Class Initialized
INFO - 2021-03-26 23:38:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:38:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:36 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:36 --> URI Class Initialized
INFO - 2021-03-26 23:38:36 --> Router Class Initialized
INFO - 2021-03-26 23:38:36 --> Output Class Initialized
INFO - 2021-03-26 23:38:36 --> Security Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:36 --> Input Class Initialized
INFO - 2021-03-26 23:38:36 --> Language Class Initialized
INFO - 2021-03-26 23:38:36 --> Loader Class Initialized
INFO - 2021-03-26 23:38:36 --> Helper loaded: url_helper
INFO - 2021-03-26 23:38:36 --> Helper loaded: form_helper
INFO - 2021-03-26 23:38:36 --> Helper loaded: common_helper
INFO - 2021-03-26 23:38:36 --> Helper loaded: util_helper
INFO - 2021-03-26 23:38:36 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:38:36 --> Form Validation Class Initialized
INFO - 2021-03-26 23:38:36 --> Controller Class Initialized
INFO - 2021-03-26 23:38:36 --> Model Class Initialized
INFO - 2021-03-26 23:38:36 --> Model Class Initialized
INFO - 2021-03-26 23:38:36 --> Model Class Initialized
INFO - 2021-03-26 23:38:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:38:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:38:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:38:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:38:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:38:36 --> Final output sent to browser
DEBUG - 2021-03-26 23:38:36 --> Total execution time: 0.0455
INFO - 2021-03-26 23:38:36 --> Config Class Initialized
INFO - 2021-03-26 23:38:36 --> Hooks Class Initialized
INFO - 2021-03-26 23:38:36 --> Config Class Initialized
INFO - 2021-03-26 23:38:36 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:38:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:36 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:36 --> URI Class Initialized
DEBUG - 2021-03-26 23:38:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:36 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:36 --> Router Class Initialized
INFO - 2021-03-26 23:38:36 --> URI Class Initialized
INFO - 2021-03-26 23:38:36 --> Output Class Initialized
INFO - 2021-03-26 23:38:36 --> Router Class Initialized
INFO - 2021-03-26 23:38:36 --> Security Class Initialized
INFO - 2021-03-26 23:38:36 --> Output Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:36 --> Input Class Initialized
INFO - 2021-03-26 23:38:36 --> Security Class Initialized
INFO - 2021-03-26 23:38:36 --> Language Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:36 --> Input Class Initialized
ERROR - 2021-03-26 23:38:36 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:38:36 --> Language Class Initialized
INFO - 2021-03-26 23:38:36 --> Config Class Initialized
INFO - 2021-03-26 23:38:36 --> Hooks Class Initialized
ERROR - 2021-03-26 23:38:36 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:38:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:36 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:36 --> URI Class Initialized
INFO - 2021-03-26 23:38:36 --> Router Class Initialized
INFO - 2021-03-26 23:38:36 --> Output Class Initialized
INFO - 2021-03-26 23:38:36 --> Security Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:36 --> Input Class Initialized
INFO - 2021-03-26 23:38:36 --> Language Class Initialized
INFO - 2021-03-26 23:38:36 --> Config Class Initialized
INFO - 2021-03-26 23:38:36 --> Hooks Class Initialized
ERROR - 2021-03-26 23:38:36 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:38:36 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:36 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:36 --> URI Class Initialized
INFO - 2021-03-26 23:38:36 --> Router Class Initialized
INFO - 2021-03-26 23:38:36 --> Output Class Initialized
INFO - 2021-03-26 23:38:36 --> Security Class Initialized
DEBUG - 2021-03-26 23:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:36 --> Input Class Initialized
INFO - 2021-03-26 23:38:36 --> Language Class Initialized
ERROR - 2021-03-26 23:38:36 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:38:40 --> Config Class Initialized
INFO - 2021-03-26 23:38:40 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:38:40 --> Utf8 Class Initialized
INFO - 2021-03-26 23:38:40 --> URI Class Initialized
INFO - 2021-03-26 23:38:40 --> Router Class Initialized
INFO - 2021-03-26 23:38:40 --> Output Class Initialized
INFO - 2021-03-26 23:38:40 --> Security Class Initialized
DEBUG - 2021-03-26 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:38:40 --> Input Class Initialized
INFO - 2021-03-26 23:38:40 --> Language Class Initialized
INFO - 2021-03-26 23:38:40 --> Loader Class Initialized
INFO - 2021-03-26 23:38:40 --> Helper loaded: url_helper
INFO - 2021-03-26 23:38:40 --> Helper loaded: form_helper
INFO - 2021-03-26 23:38:40 --> Helper loaded: common_helper
INFO - 2021-03-26 23:38:40 --> Helper loaded: util_helper
INFO - 2021-03-26 23:38:40 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:38:40 --> Form Validation Class Initialized
INFO - 2021-03-26 23:38:40 --> Controller Class Initialized
INFO - 2021-03-26 23:38:40 --> Model Class Initialized
INFO - 2021-03-26 23:38:40 --> Model Class Initialized
INFO - 2021-03-26 23:38:40 --> Model Class Initialized
INFO - 2021-03-26 23:38:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:38:40 --> Final output sent to browser
DEBUG - 2021-03-26 23:38:40 --> Total execution time: 0.0347
INFO - 2021-03-26 23:48:25 --> Config Class Initialized
INFO - 2021-03-26 23:48:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:48:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:48:25 --> Utf8 Class Initialized
INFO - 2021-03-26 23:48:25 --> URI Class Initialized
INFO - 2021-03-26 23:48:25 --> Router Class Initialized
INFO - 2021-03-26 23:48:25 --> Output Class Initialized
INFO - 2021-03-26 23:48:25 --> Security Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:48:25 --> Input Class Initialized
INFO - 2021-03-26 23:48:25 --> Language Class Initialized
INFO - 2021-03-26 23:48:25 --> Loader Class Initialized
INFO - 2021-03-26 23:48:25 --> Helper loaded: url_helper
INFO - 2021-03-26 23:48:25 --> Helper loaded: form_helper
INFO - 2021-03-26 23:48:25 --> Helper loaded: common_helper
INFO - 2021-03-26 23:48:25 --> Helper loaded: util_helper
INFO - 2021-03-26 23:48:25 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:48:25 --> Form Validation Class Initialized
INFO - 2021-03-26 23:48:25 --> Controller Class Initialized
INFO - 2021-03-26 23:48:25 --> Model Class Initialized
INFO - 2021-03-26 23:48:25 --> Model Class Initialized
INFO - 2021-03-26 23:48:25 --> Model Class Initialized
INFO - 2021-03-26 23:48:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:48:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:48:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:48:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:48:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:48:25 --> Final output sent to browser
DEBUG - 2021-03-26 23:48:25 --> Total execution time: 0.0547
INFO - 2021-03-26 23:48:25 --> Config Class Initialized
INFO - 2021-03-26 23:48:25 --> Hooks Class Initialized
INFO - 2021-03-26 23:48:25 --> Config Class Initialized
INFO - 2021-03-26 23:48:25 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:48:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:48:25 --> Utf8 Class Initialized
INFO - 2021-03-26 23:48:25 --> URI Class Initialized
INFO - 2021-03-26 23:48:25 --> Router Class Initialized
INFO - 2021-03-26 23:48:25 --> Output Class Initialized
INFO - 2021-03-26 23:48:25 --> Config Class Initialized
INFO - 2021-03-26 23:48:25 --> Hooks Class Initialized
INFO - 2021-03-26 23:48:25 --> Security Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:48:25 --> Input Class Initialized
DEBUG - 2021-03-26 23:48:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:48:25 --> Language Class Initialized
INFO - 2021-03-26 23:48:25 --> Utf8 Class Initialized
ERROR - 2021-03-26 23:48:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:48:25 --> URI Class Initialized
INFO - 2021-03-26 23:48:25 --> Router Class Initialized
DEBUG - 2021-03-26 23:48:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:48:25 --> Utf8 Class Initialized
INFO - 2021-03-26 23:48:25 --> Output Class Initialized
INFO - 2021-03-26 23:48:25 --> URI Class Initialized
INFO - 2021-03-26 23:48:25 --> Security Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:48:25 --> Router Class Initialized
INFO - 2021-03-26 23:48:25 --> Input Class Initialized
INFO - 2021-03-26 23:48:25 --> Language Class Initialized
INFO - 2021-03-26 23:48:25 --> Output Class Initialized
INFO - 2021-03-26 23:48:25 --> Config Class Initialized
INFO - 2021-03-26 23:48:25 --> Hooks Class Initialized
ERROR - 2021-03-26 23:48:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:48:25 --> Security Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:48:25 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:48:25 --> Input Class Initialized
INFO - 2021-03-26 23:48:25 --> Utf8 Class Initialized
INFO - 2021-03-26 23:48:25 --> Language Class Initialized
INFO - 2021-03-26 23:48:25 --> URI Class Initialized
ERROR - 2021-03-26 23:48:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:48:25 --> Router Class Initialized
INFO - 2021-03-26 23:48:25 --> Output Class Initialized
INFO - 2021-03-26 23:48:25 --> Security Class Initialized
DEBUG - 2021-03-26 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:48:25 --> Input Class Initialized
INFO - 2021-03-26 23:48:25 --> Language Class Initialized
ERROR - 2021-03-26 23:48:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:49:04 --> Config Class Initialized
INFO - 2021-03-26 23:49:04 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:49:04 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:49:04 --> Utf8 Class Initialized
INFO - 2021-03-26 23:49:04 --> URI Class Initialized
INFO - 2021-03-26 23:49:04 --> Router Class Initialized
INFO - 2021-03-26 23:49:04 --> Output Class Initialized
INFO - 2021-03-26 23:49:04 --> Security Class Initialized
DEBUG - 2021-03-26 23:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:49:04 --> Input Class Initialized
INFO - 2021-03-26 23:49:04 --> Language Class Initialized
INFO - 2021-03-26 23:49:04 --> Loader Class Initialized
INFO - 2021-03-26 23:49:04 --> Helper loaded: url_helper
INFO - 2021-03-26 23:49:04 --> Helper loaded: form_helper
INFO - 2021-03-26 23:49:04 --> Helper loaded: common_helper
INFO - 2021-03-26 23:49:04 --> Helper loaded: util_helper
INFO - 2021-03-26 23:49:04 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:49:04 --> Form Validation Class Initialized
INFO - 2021-03-26 23:49:04 --> Controller Class Initialized
INFO - 2021-03-26 23:49:04 --> Model Class Initialized
INFO - 2021-03-26 23:49:04 --> Model Class Initialized
INFO - 2021-03-26 23:49:04 --> Model Class Initialized
INFO - 2021-03-26 23:49:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:49:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:49:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:49:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:49:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:49:04 --> Final output sent to browser
DEBUG - 2021-03-26 23:49:04 --> Total execution time: 0.0555
INFO - 2021-03-26 23:57:58 --> Config Class Initialized
INFO - 2021-03-26 23:57:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:57:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:57:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:57:58 --> URI Class Initialized
INFO - 2021-03-26 23:57:58 --> Router Class Initialized
INFO - 2021-03-26 23:57:58 --> Output Class Initialized
INFO - 2021-03-26 23:57:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:57:58 --> Input Class Initialized
INFO - 2021-03-26 23:57:58 --> Language Class Initialized
INFO - 2021-03-26 23:57:58 --> Loader Class Initialized
INFO - 2021-03-26 23:57:58 --> Helper loaded: url_helper
INFO - 2021-03-26 23:57:58 --> Helper loaded: form_helper
INFO - 2021-03-26 23:57:58 --> Helper loaded: common_helper
INFO - 2021-03-26 23:57:58 --> Helper loaded: util_helper
INFO - 2021-03-26 23:57:58 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:57:58 --> Form Validation Class Initialized
INFO - 2021-03-26 23:57:58 --> Controller Class Initialized
INFO - 2021-03-26 23:57:58 --> Model Class Initialized
INFO - 2021-03-26 23:57:58 --> Model Class Initialized
INFO - 2021-03-26 23:57:58 --> Model Class Initialized
INFO - 2021-03-26 23:57:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:57:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:57:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:57:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:57:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:57:58 --> Final output sent to browser
DEBUG - 2021-03-26 23:57:58 --> Total execution time: 0.0531
INFO - 2021-03-26 23:57:58 --> Config Class Initialized
INFO - 2021-03-26 23:57:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:57:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:57:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:57:58 --> URI Class Initialized
INFO - 2021-03-26 23:57:58 --> Router Class Initialized
INFO - 2021-03-26 23:57:58 --> Output Class Initialized
INFO - 2021-03-26 23:57:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:57:58 --> Config Class Initialized
INFO - 2021-03-26 23:57:58 --> Input Class Initialized
INFO - 2021-03-26 23:57:58 --> Hooks Class Initialized
INFO - 2021-03-26 23:57:58 --> Language Class Initialized
ERROR - 2021-03-26 23:57:58 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:57:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:57:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:57:58 --> URI Class Initialized
INFO - 2021-03-26 23:57:58 --> Router Class Initialized
INFO - 2021-03-26 23:57:58 --> Output Class Initialized
INFO - 2021-03-26 23:57:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:57:58 --> Input Class Initialized
INFO - 2021-03-26 23:57:58 --> Language Class Initialized
ERROR - 2021-03-26 23:57:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:57:58 --> Config Class Initialized
INFO - 2021-03-26 23:57:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:57:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:57:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:57:58 --> URI Class Initialized
INFO - 2021-03-26 23:57:58 --> Router Class Initialized
INFO - 2021-03-26 23:57:58 --> Config Class Initialized
INFO - 2021-03-26 23:57:58 --> Hooks Class Initialized
INFO - 2021-03-26 23:57:58 --> Output Class Initialized
INFO - 2021-03-26 23:57:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-26 23:57:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:57:58 --> Input Class Initialized
INFO - 2021-03-26 23:57:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:57:58 --> Language Class Initialized
INFO - 2021-03-26 23:57:58 --> URI Class Initialized
ERROR - 2021-03-26 23:57:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:57:58 --> Router Class Initialized
INFO - 2021-03-26 23:57:58 --> Output Class Initialized
INFO - 2021-03-26 23:57:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:57:58 --> Input Class Initialized
INFO - 2021-03-26 23:57:58 --> Language Class Initialized
ERROR - 2021-03-26 23:57:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:58:58 --> Config Class Initialized
INFO - 2021-03-26 23:58:58 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:58:58 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:58:58 --> Utf8 Class Initialized
INFO - 2021-03-26 23:58:58 --> URI Class Initialized
INFO - 2021-03-26 23:58:58 --> Router Class Initialized
INFO - 2021-03-26 23:58:58 --> Output Class Initialized
INFO - 2021-03-26 23:58:58 --> Security Class Initialized
DEBUG - 2021-03-26 23:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:58:58 --> Input Class Initialized
INFO - 2021-03-26 23:58:58 --> Language Class Initialized
INFO - 2021-03-26 23:58:58 --> Loader Class Initialized
INFO - 2021-03-26 23:58:58 --> Helper loaded: url_helper
INFO - 2021-03-26 23:58:58 --> Helper loaded: form_helper
INFO - 2021-03-26 23:58:58 --> Helper loaded: common_helper
INFO - 2021-03-26 23:58:58 --> Helper loaded: util_helper
INFO - 2021-03-26 23:58:58 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:58:58 --> Form Validation Class Initialized
INFO - 2021-03-26 23:58:58 --> Controller Class Initialized
INFO - 2021-03-26 23:58:58 --> Model Class Initialized
INFO - 2021-03-26 23:58:58 --> Model Class Initialized
INFO - 2021-03-26 23:58:58 --> Model Class Initialized
INFO - 2021-03-26 23:58:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:58:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:58:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:58:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:58:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:58:58 --> Final output sent to browser
DEBUG - 2021-03-26 23:58:58 --> Total execution time: 0.0373
INFO - 2021-03-26 23:59:21 --> Config Class Initialized
INFO - 2021-03-26 23:59:21 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:21 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:21 --> URI Class Initialized
INFO - 2021-03-26 23:59:21 --> Router Class Initialized
INFO - 2021-03-26 23:59:21 --> Output Class Initialized
INFO - 2021-03-26 23:59:21 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:21 --> Input Class Initialized
INFO - 2021-03-26 23:59:21 --> Language Class Initialized
INFO - 2021-03-26 23:59:21 --> Loader Class Initialized
INFO - 2021-03-26 23:59:21 --> Helper loaded: url_helper
INFO - 2021-03-26 23:59:21 --> Helper loaded: form_helper
INFO - 2021-03-26 23:59:21 --> Helper loaded: common_helper
INFO - 2021-03-26 23:59:21 --> Helper loaded: util_helper
INFO - 2021-03-26 23:59:21 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:59:21 --> Form Validation Class Initialized
INFO - 2021-03-26 23:59:21 --> Controller Class Initialized
INFO - 2021-03-26 23:59:21 --> Model Class Initialized
INFO - 2021-03-26 23:59:21 --> Model Class Initialized
INFO - 2021-03-26 23:59:21 --> Model Class Initialized
INFO - 2021-03-26 23:59:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:59:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:59:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:59:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:59:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:59:21 --> Final output sent to browser
DEBUG - 2021-03-26 23:59:21 --> Total execution time: 0.0393
INFO - 2021-03-26 23:59:21 --> Config Class Initialized
INFO - 2021-03-26 23:59:21 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:21 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:21 --> URI Class Initialized
INFO - 2021-03-26 23:59:21 --> Config Class Initialized
INFO - 2021-03-26 23:59:21 --> Router Class Initialized
INFO - 2021-03-26 23:59:21 --> Output Class Initialized
INFO - 2021-03-26 23:59:21 --> Hooks Class Initialized
INFO - 2021-03-26 23:59:21 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:21 --> Input Class Initialized
DEBUG - 2021-03-26 23:59:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:21 --> Language Class Initialized
INFO - 2021-03-26 23:59:21 --> Utf8 Class Initialized
ERROR - 2021-03-26 23:59:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:21 --> URI Class Initialized
INFO - 2021-03-26 23:59:21 --> Router Class Initialized
INFO - 2021-03-26 23:59:21 --> Output Class Initialized
INFO - 2021-03-26 23:59:21 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:21 --> Input Class Initialized
INFO - 2021-03-26 23:59:21 --> Language Class Initialized
ERROR - 2021-03-26 23:59:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:21 --> Config Class Initialized
INFO - 2021-03-26 23:59:21 --> Hooks Class Initialized
INFO - 2021-03-26 23:59:21 --> Config Class Initialized
DEBUG - 2021-03-26 23:59:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:21 --> Hooks Class Initialized
INFO - 2021-03-26 23:59:21 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:21 --> URI Class Initialized
DEBUG - 2021-03-26 23:59:21 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:21 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:21 --> Router Class Initialized
INFO - 2021-03-26 23:59:21 --> URI Class Initialized
INFO - 2021-03-26 23:59:21 --> Output Class Initialized
INFO - 2021-03-26 23:59:21 --> Router Class Initialized
INFO - 2021-03-26 23:59:21 --> Security Class Initialized
INFO - 2021-03-26 23:59:21 --> Output Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:21 --> Input Class Initialized
INFO - 2021-03-26 23:59:21 --> Language Class Initialized
INFO - 2021-03-26 23:59:21 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-26 23:59:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:21 --> Input Class Initialized
INFO - 2021-03-26 23:59:21 --> Language Class Initialized
ERROR - 2021-03-26 23:59:21 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:28 --> Config Class Initialized
INFO - 2021-03-26 23:59:28 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:28 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:28 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:28 --> URI Class Initialized
INFO - 2021-03-26 23:59:28 --> Router Class Initialized
INFO - 2021-03-26 23:59:28 --> Output Class Initialized
INFO - 2021-03-26 23:59:28 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:28 --> Input Class Initialized
INFO - 2021-03-26 23:59:28 --> Language Class Initialized
INFO - 2021-03-26 23:59:28 --> Loader Class Initialized
INFO - 2021-03-26 23:59:28 --> Helper loaded: url_helper
INFO - 2021-03-26 23:59:28 --> Helper loaded: form_helper
INFO - 2021-03-26 23:59:28 --> Helper loaded: common_helper
INFO - 2021-03-26 23:59:28 --> Helper loaded: util_helper
INFO - 2021-03-26 23:59:28 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:59:28 --> Form Validation Class Initialized
INFO - 2021-03-26 23:59:28 --> Controller Class Initialized
INFO - 2021-03-26 23:59:28 --> Model Class Initialized
INFO - 2021-03-26 23:59:28 --> Model Class Initialized
INFO - 2021-03-26 23:59:28 --> Model Class Initialized
INFO - 2021-03-26 23:59:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:59:28 --> Final output sent to browser
DEBUG - 2021-03-26 23:59:28 --> Total execution time: 0.0471
INFO - 2021-03-26 23:59:50 --> Config Class Initialized
INFO - 2021-03-26 23:59:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:50 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:50 --> URI Class Initialized
INFO - 2021-03-26 23:59:50 --> Router Class Initialized
INFO - 2021-03-26 23:59:50 --> Output Class Initialized
INFO - 2021-03-26 23:59:50 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:50 --> Input Class Initialized
INFO - 2021-03-26 23:59:50 --> Language Class Initialized
INFO - 2021-03-26 23:59:50 --> Loader Class Initialized
INFO - 2021-03-26 23:59:50 --> Helper loaded: url_helper
INFO - 2021-03-26 23:59:50 --> Helper loaded: form_helper
INFO - 2021-03-26 23:59:50 --> Helper loaded: common_helper
INFO - 2021-03-26 23:59:50 --> Helper loaded: util_helper
INFO - 2021-03-26 23:59:50 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:59:50 --> Form Validation Class Initialized
INFO - 2021-03-26 23:59:50 --> Controller Class Initialized
INFO - 2021-03-26 23:59:50 --> Model Class Initialized
INFO - 2021-03-26 23:59:50 --> Model Class Initialized
INFO - 2021-03-26 23:59:50 --> Model Class Initialized
INFO - 2021-03-26 23:59:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-26 23:59:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-26 23:59:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-26 23:59:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-26 23:59:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-26 23:59:50 --> Final output sent to browser
DEBUG - 2021-03-26 23:59:50 --> Total execution time: 0.0435
INFO - 2021-03-26 23:59:50 --> Config Class Initialized
INFO - 2021-03-26 23:59:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:50 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:50 --> URI Class Initialized
INFO - 2021-03-26 23:59:50 --> Router Class Initialized
INFO - 2021-03-26 23:59:50 --> Output Class Initialized
INFO - 2021-03-26 23:59:50 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:50 --> Input Class Initialized
INFO - 2021-03-26 23:59:50 --> Language Class Initialized
INFO - 2021-03-26 23:59:50 --> Config Class Initialized
INFO - 2021-03-26 23:59:50 --> Hooks Class Initialized
ERROR - 2021-03-26 23:59:50 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-26 23:59:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:50 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:50 --> URI Class Initialized
INFO - 2021-03-26 23:59:50 --> Router Class Initialized
INFO - 2021-03-26 23:59:50 --> Output Class Initialized
INFO - 2021-03-26 23:59:50 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:50 --> Input Class Initialized
INFO - 2021-03-26 23:59:50 --> Language Class Initialized
ERROR - 2021-03-26 23:59:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:50 --> Config Class Initialized
INFO - 2021-03-26 23:59:50 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:50 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:50 --> URI Class Initialized
INFO - 2021-03-26 23:59:50 --> Router Class Initialized
INFO - 2021-03-26 23:59:50 --> Config Class Initialized
INFO - 2021-03-26 23:59:50 --> Hooks Class Initialized
INFO - 2021-03-26 23:59:50 --> Output Class Initialized
DEBUG - 2021-03-26 23:59:50 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:50 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:50 --> Security Class Initialized
INFO - 2021-03-26 23:59:50 --> URI Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:50 --> Input Class Initialized
INFO - 2021-03-26 23:59:50 --> Language Class Initialized
INFO - 2021-03-26 23:59:50 --> Router Class Initialized
ERROR - 2021-03-26 23:59:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:50 --> Output Class Initialized
INFO - 2021-03-26 23:59:50 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:50 --> Input Class Initialized
INFO - 2021-03-26 23:59:50 --> Language Class Initialized
ERROR - 2021-03-26 23:59:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-26 23:59:53 --> Config Class Initialized
INFO - 2021-03-26 23:59:53 --> Hooks Class Initialized
DEBUG - 2021-03-26 23:59:53 --> UTF-8 Support Enabled
INFO - 2021-03-26 23:59:53 --> Utf8 Class Initialized
INFO - 2021-03-26 23:59:53 --> URI Class Initialized
INFO - 2021-03-26 23:59:53 --> Router Class Initialized
INFO - 2021-03-26 23:59:53 --> Output Class Initialized
INFO - 2021-03-26 23:59:53 --> Security Class Initialized
DEBUG - 2021-03-26 23:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-26 23:59:53 --> Input Class Initialized
INFO - 2021-03-26 23:59:53 --> Language Class Initialized
INFO - 2021-03-26 23:59:53 --> Loader Class Initialized
INFO - 2021-03-26 23:59:53 --> Helper loaded: url_helper
INFO - 2021-03-26 23:59:53 --> Helper loaded: form_helper
INFO - 2021-03-26 23:59:53 --> Helper loaded: common_helper
INFO - 2021-03-26 23:59:53 --> Helper loaded: util_helper
INFO - 2021-03-26 23:59:53 --> Database Driver Class Initialized
DEBUG - 2021-03-26 23:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-26 23:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-26 23:59:53 --> Form Validation Class Initialized
INFO - 2021-03-26 23:59:53 --> Controller Class Initialized
INFO - 2021-03-26 23:59:53 --> Model Class Initialized
INFO - 2021-03-26 23:59:53 --> Model Class Initialized
INFO - 2021-03-26 23:59:53 --> Model Class Initialized
INFO - 2021-03-26 23:59:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-26 23:59:53 --> Final output sent to browser
DEBUG - 2021-03-26 23:59:53 --> Total execution time: 0.0387
