INFO - 2021-03-31 19:20:01 --> Config Class Initialized
INFO - 2021-03-31 19:20:01 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:20:01 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:20:01 --> Utf8 Class Initialized
INFO - 2021-03-31 19:20:01 --> URI Class Initialized
INFO - 2021-03-31 19:20:01 --> Router Class Initialized
INFO - 2021-03-31 19:20:01 --> Output Class Initialized
INFO - 2021-03-31 19:20:01 --> Security Class Initialized
DEBUG - 2021-03-31 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:20:01 --> Input Class Initialized
INFO - 2021-03-31 19:20:01 --> Language Class Initialized
ERROR - 2021-03-31 19:20:01 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\robust\php\application\controllers\administrator\Company.php 134
INFO - 2021-03-31 19:22:53 --> Config Class Initialized
INFO - 2021-03-31 19:22:53 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:22:53 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:22:53 --> Utf8 Class Initialized
INFO - 2021-03-31 19:22:53 --> URI Class Initialized
INFO - 2021-03-31 19:22:53 --> Router Class Initialized
INFO - 2021-03-31 19:22:53 --> Output Class Initialized
INFO - 2021-03-31 19:22:53 --> Security Class Initialized
DEBUG - 2021-03-31 19:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:22:53 --> Input Class Initialized
INFO - 2021-03-31 19:22:53 --> Language Class Initialized
ERROR - 2021-03-31 19:22:53 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\robust\php\application\controllers\administrator\Company.php 134
INFO - 2021-03-31 19:22:53 --> Config Class Initialized
INFO - 2021-03-31 19:22:53 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:22:53 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:22:53 --> Utf8 Class Initialized
INFO - 2021-03-31 19:22:53 --> URI Class Initialized
INFO - 2021-03-31 19:22:53 --> Router Class Initialized
INFO - 2021-03-31 19:22:53 --> Output Class Initialized
INFO - 2021-03-31 19:22:53 --> Security Class Initialized
DEBUG - 2021-03-31 19:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:22:53 --> Input Class Initialized
INFO - 2021-03-31 19:22:53 --> Language Class Initialized
ERROR - 2021-03-31 19:22:53 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\robust\php\application\controllers\administrator\Company.php 134
INFO - 2021-03-31 19:23:00 --> Config Class Initialized
INFO - 2021-03-31 19:23:00 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:23:00 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:00 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:00 --> URI Class Initialized
INFO - 2021-03-31 19:23:00 --> Router Class Initialized
INFO - 2021-03-31 19:23:00 --> Output Class Initialized
INFO - 2021-03-31 19:23:00 --> Security Class Initialized
DEBUG - 2021-03-31 19:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:00 --> Input Class Initialized
INFO - 2021-03-31 19:23:00 --> Language Class Initialized
ERROR - 2021-03-31 19:23:00 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\robust\php\application\controllers\administrator\Company.php 134
INFO - 2021-03-31 19:23:01 --> Config Class Initialized
INFO - 2021-03-31 19:23:01 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:23:01 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:01 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:01 --> URI Class Initialized
INFO - 2021-03-31 19:23:01 --> Router Class Initialized
INFO - 2021-03-31 19:23:01 --> Output Class Initialized
INFO - 2021-03-31 19:23:01 --> Security Class Initialized
DEBUG - 2021-03-31 19:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:01 --> Input Class Initialized
INFO - 2021-03-31 19:23:01 --> Language Class Initialized
ERROR - 2021-03-31 19:23:01 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\robust\php\application\controllers\administrator\Company.php 134
INFO - 2021-03-31 19:23:58 --> Config Class Initialized
INFO - 2021-03-31 19:23:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:23:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:58 --> URI Class Initialized
INFO - 2021-03-31 19:23:58 --> Router Class Initialized
INFO - 2021-03-31 19:23:58 --> Output Class Initialized
INFO - 2021-03-31 19:23:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:58 --> Input Class Initialized
INFO - 2021-03-31 19:23:58 --> Language Class Initialized
INFO - 2021-03-31 19:23:58 --> Loader Class Initialized
INFO - 2021-03-31 19:23:58 --> Helper loaded: url_helper
INFO - 2021-03-31 19:23:58 --> Helper loaded: form_helper
INFO - 2021-03-31 19:23:58 --> Helper loaded: common_helper
INFO - 2021-03-31 19:23:58 --> Helper loaded: util_helper
INFO - 2021-03-31 19:23:58 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:23:58 --> Form Validation Class Initialized
INFO - 2021-03-31 19:23:58 --> Controller Class Initialized
INFO - 2021-03-31 19:23:58 --> Model Class Initialized
INFO - 2021-03-31 19:23:58 --> Model Class Initialized
INFO - 2021-03-31 19:23:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:23:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:23:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:23:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:23:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:23:58 --> Final output sent to browser
DEBUG - 2021-03-31 19:23:58 --> Total execution time: 0.0458
INFO - 2021-03-31 19:23:58 --> Config Class Initialized
INFO - 2021-03-31 19:23:58 --> Hooks Class Initialized
INFO - 2021-03-31 19:23:58 --> Config Class Initialized
INFO - 2021-03-31 19:23:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:23:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:58 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:23:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:58 --> URI Class Initialized
INFO - 2021-03-31 19:23:58 --> URI Class Initialized
INFO - 2021-03-31 19:23:58 --> Router Class Initialized
INFO - 2021-03-31 19:23:58 --> Router Class Initialized
INFO - 2021-03-31 19:23:58 --> Output Class Initialized
INFO - 2021-03-31 19:23:58 --> Output Class Initialized
INFO - 2021-03-31 19:23:58 --> Security Class Initialized
INFO - 2021-03-31 19:23:59 --> Security Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:59 --> Input Class Initialized
INFO - 2021-03-31 19:23:59 --> Language Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:59 --> Input Class Initialized
INFO - 2021-03-31 19:23:59 --> Language Class Initialized
INFO - 2021-03-31 19:23:59 --> Loader Class Initialized
INFO - 2021-03-31 19:23:59 --> Loader Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: url_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: url_helper
INFO - 2021-03-31 19:23:59 --> Config Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: form_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: form_helper
INFO - 2021-03-31 19:23:59 --> Hooks Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: common_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: common_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: util_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: util_helper
DEBUG - 2021-03-31 19:23:59 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:23:59 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:59 --> URI Class Initialized
INFO - 2021-03-31 19:23:59 --> Database Driver Class Initialized
INFO - 2021-03-31 19:23:59 --> Router Class Initialized
INFO - 2021-03-31 19:23:59 --> Database Driver Class Initialized
INFO - 2021-03-31 19:23:59 --> Config Class Initialized
INFO - 2021-03-31 19:23:59 --> Hooks Class Initialized
INFO - 2021-03-31 19:23:59 --> Output Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:23:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-31 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:23:59 --> Utf8 Class Initialized
INFO - 2021-03-31 19:23:59 --> Security Class Initialized
INFO - 2021-03-31 19:23:59 --> URI Class Initialized
INFO - 2021-03-31 19:23:59 --> Form Validation Class Initialized
INFO - 2021-03-31 19:23:59 --> Controller Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:59 --> Input Class Initialized
INFO - 2021-03-31 19:23:59 --> Router Class Initialized
INFO - 2021-03-31 19:23:59 --> Language Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Output Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:23:59 --> Security Class Initialized
INFO - 2021-03-31 19:23:59 --> Loader Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
DEBUG - 2021-03-31 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:23:59 --> Helper loaded: url_helper
INFO - 2021-03-31 19:23:59 --> Input Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:23:59 --> Final output sent to browser
INFO - 2021-03-31 19:23:59 --> Language Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Total execution time: 0.0466
INFO - 2021-03-31 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:23:59 --> Helper loaded: form_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: common_helper
INFO - 2021-03-31 19:23:59 --> Form Validation Class Initialized
INFO - 2021-03-31 19:23:59 --> Controller Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: util_helper
INFO - 2021-03-31 19:23:59 --> Loader Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: url_helper
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Helper loaded: form_helper
INFO - 2021-03-31 19:23:59 --> Helper loaded: common_helper
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:23:59 --> Helper loaded: util_helper
INFO - 2021-03-31 19:23:59 --> Database Driver Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:23:59 --> Final output sent to browser
DEBUG - 2021-03-31 19:23:59 --> Total execution time: 0.0642
INFO - 2021-03-31 19:23:59 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-31 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:23:59 --> Form Validation Class Initialized
INFO - 2021-03-31 19:23:59 --> Controller Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:23:59 --> Final output sent to browser
DEBUG - 2021-03-31 19:23:59 --> Total execution time: 0.0754
INFO - 2021-03-31 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:23:59 --> Form Validation Class Initialized
INFO - 2021-03-31 19:23:59 --> Controller Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> Model Class Initialized
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:23:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:23:59 --> Final output sent to browser
DEBUG - 2021-03-31 19:23:59 --> Total execution time: 0.0713
INFO - 2021-03-31 19:24:23 --> Config Class Initialized
INFO - 2021-03-31 19:24:23 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:24:23 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:23 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:23 --> URI Class Initialized
INFO - 2021-03-31 19:24:23 --> Router Class Initialized
INFO - 2021-03-31 19:24:23 --> Output Class Initialized
INFO - 2021-03-31 19:24:23 --> Security Class Initialized
DEBUG - 2021-03-31 19:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:24:23 --> Input Class Initialized
INFO - 2021-03-31 19:24:23 --> Language Class Initialized
ERROR - 2021-03-31 19:24:23 --> 404 Page Not Found: administrator/Company/1
INFO - 2021-03-31 19:24:50 --> Config Class Initialized
INFO - 2021-03-31 19:24:50 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:50 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:50 --> URI Class Initialized
INFO - 2021-03-31 19:24:50 --> Router Class Initialized
INFO - 2021-03-31 19:24:50 --> Output Class Initialized
INFO - 2021-03-31 19:24:50 --> Security Class Initialized
DEBUG - 2021-03-31 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:24:50 --> Input Class Initialized
INFO - 2021-03-31 19:24:50 --> Language Class Initialized
INFO - 2021-03-31 19:24:50 --> Loader Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: url_helper
INFO - 2021-03-31 19:24:50 --> Helper loaded: form_helper
INFO - 2021-03-31 19:24:50 --> Helper loaded: common_helper
INFO - 2021-03-31 19:24:50 --> Helper loaded: util_helper
INFO - 2021-03-31 19:24:50 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:24:50 --> Form Validation Class Initialized
INFO - 2021-03-31 19:24:50 --> Controller Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:24:50 --> Final output sent to browser
DEBUG - 2021-03-31 19:24:50 --> Total execution time: 0.0373
INFO - 2021-03-31 19:24:50 --> Config Class Initialized
INFO - 2021-03-31 19:24:50 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:50 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:50 --> URI Class Initialized
INFO - 2021-03-31 19:24:50 --> Router Class Initialized
INFO - 2021-03-31 19:24:50 --> Config Class Initialized
INFO - 2021-03-31 19:24:50 --> Hooks Class Initialized
INFO - 2021-03-31 19:24:50 --> Output Class Initialized
DEBUG - 2021-03-31 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:50 --> Security Class Initialized
INFO - 2021-03-31 19:24:50 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:50 --> URI Class Initialized
DEBUG - 2021-03-31 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:24:50 --> Input Class Initialized
INFO - 2021-03-31 19:24:50 --> Language Class Initialized
INFO - 2021-03-31 19:24:50 --> Router Class Initialized
INFO - 2021-03-31 19:24:50 --> Output Class Initialized
INFO - 2021-03-31 19:24:50 --> Loader Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: url_helper
INFO - 2021-03-31 19:24:50 --> Security Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: form_helper
DEBUG - 2021-03-31 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:24:50 --> Input Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: common_helper
INFO - 2021-03-31 19:24:50 --> Config Class Initialized
INFO - 2021-03-31 19:24:50 --> Hooks Class Initialized
INFO - 2021-03-31 19:24:50 --> Language Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: util_helper
DEBUG - 2021-03-31 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:50 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:50 --> Loader Class Initialized
INFO - 2021-03-31 19:24:50 --> URI Class Initialized
INFO - 2021-03-31 19:24:50 --> Config Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: url_helper
INFO - 2021-03-31 19:24:50 --> Hooks Class Initialized
INFO - 2021-03-31 19:24:50 --> Router Class Initialized
INFO - 2021-03-31 19:24:50 --> Database Driver Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: form_helper
INFO - 2021-03-31 19:24:50 --> Output Class Initialized
DEBUG - 2021-03-31 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:24:50 --> Helper loaded: common_helper
INFO - 2021-03-31 19:24:50 --> Utf8 Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: util_helper
INFO - 2021-03-31 19:24:50 --> Security Class Initialized
DEBUG - 2021-03-31 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:24:50 --> URI Class Initialized
INFO - 2021-03-31 19:24:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-31 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:24:50 --> Input Class Initialized
INFO - 2021-03-31 19:24:50 --> Language Class Initialized
INFO - 2021-03-31 19:24:50 --> Form Validation Class Initialized
INFO - 2021-03-31 19:24:50 --> Router Class Initialized
INFO - 2021-03-31 19:24:50 --> Controller Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Loader Class Initialized
INFO - 2021-03-31 19:24:50 --> Database Driver Class Initialized
INFO - 2021-03-31 19:24:50 --> Output Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:24:50 --> Helper loaded: url_helper
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:24:50 --> Security Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-31 19:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:24:50 --> Final output sent to browser
DEBUG - 2021-03-31 19:24:50 --> Total execution time: 0.0468
INFO - 2021-03-31 19:24:50 --> Input Class Initialized
INFO - 2021-03-31 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:24:50 --> Helper loaded: form_helper
INFO - 2021-03-31 19:24:50 --> Language Class Initialized
INFO - 2021-03-31 19:24:50 --> Form Validation Class Initialized
INFO - 2021-03-31 19:24:50 --> Controller Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: common_helper
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: util_helper
INFO - 2021-03-31 19:24:50 --> Loader Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:24:50 --> Helper loaded: url_helper
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:24:50 --> Helper loaded: form_helper
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:24:50 --> Final output sent to browser
INFO - 2021-03-31 19:24:50 --> Helper loaded: common_helper
DEBUG - 2021-03-31 19:24:50 --> Total execution time: 0.0518
INFO - 2021-03-31 19:24:50 --> Database Driver Class Initialized
INFO - 2021-03-31 19:24:50 --> Helper loaded: util_helper
INFO - 2021-03-31 19:24:50 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-31 19:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:24:50 --> Form Validation Class Initialized
INFO - 2021-03-31 19:24:50 --> Controller Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:24:50 --> Final output sent to browser
DEBUG - 2021-03-31 19:24:50 --> Total execution time: 0.0851
INFO - 2021-03-31 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:24:50 --> Form Validation Class Initialized
INFO - 2021-03-31 19:24:50 --> Controller Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> Model Class Initialized
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:24:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:24:50 --> Final output sent to browser
DEBUG - 2021-03-31 19:24:50 --> Total execution time: 0.0883
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:33 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:33 --> Total execution time: 0.0457
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:33 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:33 --> Total execution time: 0.0494
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:33 --> Config Class Initialized
INFO - 2021-03-31 19:25:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:25:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:33 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
INFO - 2021-03-31 19:25:33 --> URI Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Router Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
INFO - 2021-03-31 19:25:33 --> Output Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:33 --> Security Class Initialized
INFO - 2021-03-31 19:25:33 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:33 --> Total execution time: 0.0665
DEBUG - 2021-03-31 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:33 --> Input Class Initialized
INFO - 2021-03-31 19:25:33 --> Language Class Initialized
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Loader Class Initialized
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:33 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
INFO - 2021-03-31 19:25:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-31 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:33 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:33 --> Total execution time: 0.0487
INFO - 2021-03-31 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:33 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:33 --> Controller Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> Model Class Initialized
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:33 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:33 --> Total execution time: 0.0636
INFO - 2021-03-31 19:25:58 --> Config Class Initialized
INFO - 2021-03-31 19:25:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:58 --> URI Class Initialized
INFO - 2021-03-31 19:25:58 --> Router Class Initialized
INFO - 2021-03-31 19:25:58 --> Output Class Initialized
INFO - 2021-03-31 19:25:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:58 --> Input Class Initialized
INFO - 2021-03-31 19:25:58 --> Language Class Initialized
INFO - 2021-03-31 19:25:58 --> Loader Class Initialized
INFO - 2021-03-31 19:25:58 --> Helper loaded: url_helper
INFO - 2021-03-31 19:25:58 --> Helper loaded: form_helper
INFO - 2021-03-31 19:25:58 --> Helper loaded: common_helper
INFO - 2021-03-31 19:25:58 --> Helper loaded: util_helper
INFO - 2021-03-31 19:25:58 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:25:58 --> Form Validation Class Initialized
INFO - 2021-03-31 19:25:58 --> Controller Class Initialized
INFO - 2021-03-31 19:25:58 --> Model Class Initialized
INFO - 2021-03-31 19:25:58 --> Model Class Initialized
INFO - 2021-03-31 19:25:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:25:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:25:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:25:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:25:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:25:58 --> Final output sent to browser
DEBUG - 2021-03-31 19:25:58 --> Total execution time: 0.0349
INFO - 2021-03-31 19:25:58 --> Config Class Initialized
INFO - 2021-03-31 19:25:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:58 --> Config Class Initialized
INFO - 2021-03-31 19:25:58 --> Hooks Class Initialized
INFO - 2021-03-31 19:25:58 --> URI Class Initialized
INFO - 2021-03-31 19:25:58 --> Router Class Initialized
DEBUG - 2021-03-31 19:25:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:58 --> URI Class Initialized
INFO - 2021-03-31 19:25:58 --> Output Class Initialized
INFO - 2021-03-31 19:25:58 --> Router Class Initialized
INFO - 2021-03-31 19:25:58 --> Security Class Initialized
INFO - 2021-03-31 19:25:58 --> Output Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:58 --> Input Class Initialized
INFO - 2021-03-31 19:25:58 --> Security Class Initialized
INFO - 2021-03-31 19:25:58 --> Language Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:58 --> Input Class Initialized
INFO - 2021-03-31 19:25:58 --> Language Class Initialized
ERROR - 2021-03-31 19:25:58 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:25:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:25:58 --> Config Class Initialized
INFO - 2021-03-31 19:25:58 --> Hooks Class Initialized
INFO - 2021-03-31 19:25:58 --> Config Class Initialized
INFO - 2021-03-31 19:25:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:25:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:58 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:25:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:25:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:25:58 --> URI Class Initialized
INFO - 2021-03-31 19:25:58 --> URI Class Initialized
INFO - 2021-03-31 19:25:58 --> Router Class Initialized
INFO - 2021-03-31 19:25:58 --> Router Class Initialized
INFO - 2021-03-31 19:25:58 --> Output Class Initialized
INFO - 2021-03-31 19:25:58 --> Output Class Initialized
INFO - 2021-03-31 19:25:58 --> Security Class Initialized
INFO - 2021-03-31 19:25:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:58 --> Input Class Initialized
DEBUG - 2021-03-31 19:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:25:58 --> Language Class Initialized
INFO - 2021-03-31 19:25:58 --> Input Class Initialized
INFO - 2021-03-31 19:25:58 --> Language Class Initialized
ERROR - 2021-03-31 19:25:58 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:25:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:29:37 --> Config Class Initialized
INFO - 2021-03-31 19:29:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:29:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:29:37 --> Utf8 Class Initialized
INFO - 2021-03-31 19:29:37 --> URI Class Initialized
INFO - 2021-03-31 19:29:37 --> Router Class Initialized
INFO - 2021-03-31 19:29:37 --> Output Class Initialized
INFO - 2021-03-31 19:29:37 --> Security Class Initialized
DEBUG - 2021-03-31 19:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:29:37 --> Input Class Initialized
INFO - 2021-03-31 19:29:37 --> Language Class Initialized
INFO - 2021-03-31 19:29:37 --> Loader Class Initialized
INFO - 2021-03-31 19:29:37 --> Helper loaded: url_helper
INFO - 2021-03-31 19:29:37 --> Helper loaded: form_helper
INFO - 2021-03-31 19:29:37 --> Helper loaded: common_helper
INFO - 2021-03-31 19:29:37 --> Helper loaded: util_helper
INFO - 2021-03-31 19:29:37 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:29:37 --> Form Validation Class Initialized
INFO - 2021-03-31 19:29:37 --> Controller Class Initialized
INFO - 2021-03-31 19:29:37 --> Model Class Initialized
INFO - 2021-03-31 19:29:37 --> Model Class Initialized
ERROR - 2021-03-31 19:29:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'where is_deleted='0'' at line 1 - Invalid query: select * from company order by company_name where is_deleted='0'
ERROR - 2021-03-31 19:29:37 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\robust\php\application\models\admin\Company_m.php 24
INFO - 2021-03-31 19:30:30 --> Config Class Initialized
INFO - 2021-03-31 19:30:30 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:30 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:30 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:30 --> URI Class Initialized
INFO - 2021-03-31 19:30:30 --> Router Class Initialized
INFO - 2021-03-31 19:30:30 --> Output Class Initialized
INFO - 2021-03-31 19:30:30 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:30 --> Input Class Initialized
INFO - 2021-03-31 19:30:30 --> Language Class Initialized
INFO - 2021-03-31 19:30:30 --> Loader Class Initialized
INFO - 2021-03-31 19:30:30 --> Helper loaded: url_helper
INFO - 2021-03-31 19:30:30 --> Helper loaded: form_helper
INFO - 2021-03-31 19:30:30 --> Helper loaded: common_helper
INFO - 2021-03-31 19:30:30 --> Helper loaded: util_helper
INFO - 2021-03-31 19:30:30 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:30:30 --> Form Validation Class Initialized
INFO - 2021-03-31 19:30:30 --> Controller Class Initialized
INFO - 2021-03-31 19:30:30 --> Model Class Initialized
INFO - 2021-03-31 19:30:30 --> Model Class Initialized
INFO - 2021-03-31 19:30:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:30:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:30:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:30:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:30:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:30:30 --> Final output sent to browser
DEBUG - 2021-03-31 19:30:30 --> Total execution time: 0.0425
INFO - 2021-03-31 19:30:30 --> Config Class Initialized
INFO - 2021-03-31 19:30:30 --> Config Class Initialized
INFO - 2021-03-31 19:30:30 --> Hooks Class Initialized
INFO - 2021-03-31 19:30:30 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:30 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 19:30:30 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:30 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:30 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:30 --> URI Class Initialized
INFO - 2021-03-31 19:30:30 --> URI Class Initialized
INFO - 2021-03-31 19:30:30 --> Config Class Initialized
INFO - 2021-03-31 19:30:30 --> Router Class Initialized
INFO - 2021-03-31 19:30:30 --> Hooks Class Initialized
INFO - 2021-03-31 19:30:30 --> Output Class Initialized
DEBUG - 2021-03-31 19:30:30 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:30 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:30 --> Security Class Initialized
INFO - 2021-03-31 19:30:30 --> URI Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:30 --> Input Class Initialized
INFO - 2021-03-31 19:30:30 --> Router Class Initialized
INFO - 2021-03-31 19:30:30 --> Language Class Initialized
INFO - 2021-03-31 19:30:30 --> Router Class Initialized
INFO - 2021-03-31 19:30:30 --> Output Class Initialized
ERROR - 2021-03-31 19:30:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:30:30 --> Output Class Initialized
INFO - 2021-03-31 19:30:30 --> Security Class Initialized
INFO - 2021-03-31 19:30:30 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:30 --> Input Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:30 --> Input Class Initialized
INFO - 2021-03-31 19:30:30 --> Language Class Initialized
INFO - 2021-03-31 19:30:30 --> Language Class Initialized
ERROR - 2021-03-31 19:30:30 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:30:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:30:30 --> Config Class Initialized
INFO - 2021-03-31 19:30:30 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:30 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:30 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:30 --> URI Class Initialized
INFO - 2021-03-31 19:30:30 --> Router Class Initialized
INFO - 2021-03-31 19:30:30 --> Output Class Initialized
INFO - 2021-03-31 19:30:30 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:30 --> Input Class Initialized
INFO - 2021-03-31 19:30:30 --> Language Class Initialized
ERROR - 2021-03-31 19:30:30 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
INFO - 2021-03-31 19:30:46 --> Loader Class Initialized
INFO - 2021-03-31 19:30:46 --> Helper loaded: url_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: form_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: common_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: util_helper
INFO - 2021-03-31 19:30:46 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:30:46 --> Form Validation Class Initialized
INFO - 2021-03-31 19:30:46 --> Controller Class Initialized
INFO - 2021-03-31 19:30:46 --> Model Class Initialized
INFO - 2021-03-31 19:30:46 --> Model Class Initialized
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
INFO - 2021-03-31 19:30:46 --> Loader Class Initialized
INFO - 2021-03-31 19:30:46 --> Helper loaded: url_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: form_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: common_helper
INFO - 2021-03-31 19:30:46 --> Helper loaded: util_helper
INFO - 2021-03-31 19:30:46 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:30:46 --> Form Validation Class Initialized
INFO - 2021-03-31 19:30:46 --> Controller Class Initialized
INFO - 2021-03-31 19:30:46 --> Model Class Initialized
INFO - 2021-03-31 19:30:46 --> Model Class Initialized
INFO - 2021-03-31 19:30:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:30:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:30:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:30:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:30:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:30:46 --> Final output sent to browser
DEBUG - 2021-03-31 19:30:46 --> Total execution time: 0.0384
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
ERROR - 2021-03-31 19:30:46 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:30:46 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
INFO - 2021-03-31 19:30:46 --> Config Class Initialized
INFO - 2021-03-31 19:30:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
DEBUG - 2021-03-31 19:30:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:30:46 --> Utf8 Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> URI Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
INFO - 2021-03-31 19:30:46 --> Router Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
INFO - 2021-03-31 19:30:46 --> Output Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
INFO - 2021-03-31 19:30:46 --> Security Class Initialized
DEBUG - 2021-03-31 19:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:30:46 --> Input Class Initialized
ERROR - 2021-03-31 19:30:46 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:30:46 --> Language Class Initialized
ERROR - 2021-03-31 19:30:46 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:35:58 --> Config Class Initialized
INFO - 2021-03-31 19:35:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:35:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:35:58 --> URI Class Initialized
INFO - 2021-03-31 19:35:58 --> Router Class Initialized
INFO - 2021-03-31 19:35:58 --> Output Class Initialized
INFO - 2021-03-31 19:35:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:35:58 --> Input Class Initialized
INFO - 2021-03-31 19:35:58 --> Language Class Initialized
INFO - 2021-03-31 19:35:58 --> Loader Class Initialized
INFO - 2021-03-31 19:35:58 --> Helper loaded: url_helper
INFO - 2021-03-31 19:35:58 --> Helper loaded: form_helper
INFO - 2021-03-31 19:35:58 --> Helper loaded: common_helper
INFO - 2021-03-31 19:35:58 --> Helper loaded: util_helper
INFO - 2021-03-31 19:35:58 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:35:58 --> Form Validation Class Initialized
INFO - 2021-03-31 19:35:58 --> Controller Class Initialized
INFO - 2021-03-31 19:35:58 --> Model Class Initialized
INFO - 2021-03-31 19:35:58 --> Model Class Initialized
INFO - 2021-03-31 19:35:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:35:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:35:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:35:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:35:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:35:58 --> Final output sent to browser
DEBUG - 2021-03-31 19:35:58 --> Total execution time: 0.0366
INFO - 2021-03-31 19:35:58 --> Config Class Initialized
INFO - 2021-03-31 19:35:58 --> Hooks Class Initialized
INFO - 2021-03-31 19:35:58 --> Config Class Initialized
INFO - 2021-03-31 19:35:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:35:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:35:58 --> URI Class Initialized
INFO - 2021-03-31 19:35:58 --> Router Class Initialized
DEBUG - 2021-03-31 19:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:35:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:35:58 --> Output Class Initialized
INFO - 2021-03-31 19:35:58 --> URI Class Initialized
INFO - 2021-03-31 19:35:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:35:58 --> Input Class Initialized
INFO - 2021-03-31 19:35:58 --> Router Class Initialized
INFO - 2021-03-31 19:35:58 --> Language Class Initialized
INFO - 2021-03-31 19:35:58 --> Output Class Initialized
ERROR - 2021-03-31 19:35:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:35:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:35:58 --> Input Class Initialized
INFO - 2021-03-31 19:35:58 --> Language Class Initialized
ERROR - 2021-03-31 19:35:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:35:58 --> Config Class Initialized
INFO - 2021-03-31 19:35:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:35:58 --> Utf8 Class Initialized
INFO - 2021-03-31 19:35:58 --> URI Class Initialized
INFO - 2021-03-31 19:35:58 --> Router Class Initialized
INFO - 2021-03-31 19:35:58 --> Config Class Initialized
INFO - 2021-03-31 19:35:58 --> Hooks Class Initialized
INFO - 2021-03-31 19:35:58 --> Output Class Initialized
INFO - 2021-03-31 19:35:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:35:58 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:35:58 --> URI Class Initialized
INFO - 2021-03-31 19:35:58 --> Input Class Initialized
INFO - 2021-03-31 19:35:58 --> Language Class Initialized
INFO - 2021-03-31 19:35:58 --> Router Class Initialized
INFO - 2021-03-31 19:35:58 --> Output Class Initialized
ERROR - 2021-03-31 19:35:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:35:58 --> Security Class Initialized
DEBUG - 2021-03-31 19:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:35:58 --> Input Class Initialized
INFO - 2021-03-31 19:35:58 --> Language Class Initialized
ERROR - 2021-03-31 19:35:58 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:36:02 --> Config Class Initialized
INFO - 2021-03-31 19:36:02 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:36:02 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:36:02 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:02 --> URI Class Initialized
INFO - 2021-03-31 19:36:02 --> Router Class Initialized
INFO - 2021-03-31 19:36:03 --> Output Class Initialized
INFO - 2021-03-31 19:36:03 --> Security Class Initialized
DEBUG - 2021-03-31 19:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:03 --> Input Class Initialized
INFO - 2021-03-31 19:36:03 --> Language Class Initialized
INFO - 2021-03-31 19:36:03 --> Loader Class Initialized
INFO - 2021-03-31 19:36:03 --> Helper loaded: url_helper
INFO - 2021-03-31 19:36:03 --> Helper loaded: form_helper
INFO - 2021-03-31 19:36:03 --> Helper loaded: common_helper
INFO - 2021-03-31 19:36:03 --> Helper loaded: util_helper
INFO - 2021-03-31 19:36:03 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:36:03 --> Form Validation Class Initialized
INFO - 2021-03-31 19:36:03 --> Controller Class Initialized
INFO - 2021-03-31 19:36:03 --> Model Class Initialized
INFO - 2021-03-31 19:36:03 --> Model Class Initialized
ERROR - 2021-03-31 19:36:03 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: UPDATE `company` SET `company_status` = '0'
WHERE `company` = ''
INFO - 2021-03-31 19:36:03 --> Final output sent to browser
DEBUG - 2021-03-31 19:36:03 --> Total execution time: 0.0348
INFO - 2021-03-31 19:36:22 --> Config Class Initialized
INFO - 2021-03-31 19:36:22 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:36:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:36:22 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:22 --> URI Class Initialized
INFO - 2021-03-31 19:36:22 --> Router Class Initialized
INFO - 2021-03-31 19:36:22 --> Output Class Initialized
INFO - 2021-03-31 19:36:22 --> Security Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:22 --> Input Class Initialized
INFO - 2021-03-31 19:36:22 --> Language Class Initialized
INFO - 2021-03-31 19:36:22 --> Loader Class Initialized
INFO - 2021-03-31 19:36:22 --> Helper loaded: url_helper
INFO - 2021-03-31 19:36:22 --> Helper loaded: form_helper
INFO - 2021-03-31 19:36:22 --> Helper loaded: common_helper
INFO - 2021-03-31 19:36:22 --> Helper loaded: util_helper
INFO - 2021-03-31 19:36:22 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:36:22 --> Form Validation Class Initialized
INFO - 2021-03-31 19:36:22 --> Controller Class Initialized
INFO - 2021-03-31 19:36:22 --> Model Class Initialized
INFO - 2021-03-31 19:36:22 --> Model Class Initialized
INFO - 2021-03-31 19:36:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:36:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:36:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:36:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:36:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:36:22 --> Final output sent to browser
DEBUG - 2021-03-31 19:36:22 --> Total execution time: 0.0376
INFO - 2021-03-31 19:36:22 --> Config Class Initialized
INFO - 2021-03-31 19:36:22 --> Hooks Class Initialized
INFO - 2021-03-31 19:36:22 --> Config Class Initialized
INFO - 2021-03-31 19:36:22 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:36:22 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 19:36:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:36:22 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:22 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:22 --> URI Class Initialized
INFO - 2021-03-31 19:36:22 --> URI Class Initialized
INFO - 2021-03-31 19:36:22 --> Router Class Initialized
INFO - 2021-03-31 19:36:22 --> Router Class Initialized
INFO - 2021-03-31 19:36:22 --> Output Class Initialized
INFO - 2021-03-31 19:36:22 --> Output Class Initialized
INFO - 2021-03-31 19:36:22 --> Security Class Initialized
INFO - 2021-03-31 19:36:22 --> Security Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:22 --> Input Class Initialized
INFO - 2021-03-31 19:36:22 --> Language Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:22 --> Input Class Initialized
ERROR - 2021-03-31 19:36:22 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:36:22 --> Language Class Initialized
ERROR - 2021-03-31 19:36:22 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:36:22 --> Config Class Initialized
INFO - 2021-03-31 19:36:22 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:36:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:36:22 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:22 --> URI Class Initialized
INFO - 2021-03-31 19:36:22 --> Router Class Initialized
INFO - 2021-03-31 19:36:22 --> Output Class Initialized
INFO - 2021-03-31 19:36:22 --> Security Class Initialized
INFO - 2021-03-31 19:36:22 --> Config Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:22 --> Hooks Class Initialized
INFO - 2021-03-31 19:36:22 --> Input Class Initialized
INFO - 2021-03-31 19:36:22 --> Language Class Initialized
DEBUG - 2021-03-31 19:36:22 --> UTF-8 Support Enabled
ERROR - 2021-03-31 19:36:22 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:36:22 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:22 --> URI Class Initialized
INFO - 2021-03-31 19:36:22 --> Router Class Initialized
INFO - 2021-03-31 19:36:22 --> Output Class Initialized
INFO - 2021-03-31 19:36:22 --> Security Class Initialized
DEBUG - 2021-03-31 19:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:22 --> Input Class Initialized
INFO - 2021-03-31 19:36:22 --> Language Class Initialized
ERROR - 2021-03-31 19:36:22 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:36:28 --> Config Class Initialized
INFO - 2021-03-31 19:36:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:36:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:36:28 --> Utf8 Class Initialized
INFO - 2021-03-31 19:36:28 --> URI Class Initialized
INFO - 2021-03-31 19:36:28 --> Router Class Initialized
INFO - 2021-03-31 19:36:28 --> Output Class Initialized
INFO - 2021-03-31 19:36:28 --> Security Class Initialized
DEBUG - 2021-03-31 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:36:28 --> Input Class Initialized
INFO - 2021-03-31 19:36:28 --> Language Class Initialized
INFO - 2021-03-31 19:36:28 --> Loader Class Initialized
INFO - 2021-03-31 19:36:28 --> Helper loaded: url_helper
INFO - 2021-03-31 19:36:28 --> Helper loaded: form_helper
INFO - 2021-03-31 19:36:28 --> Helper loaded: common_helper
INFO - 2021-03-31 19:36:28 --> Helper loaded: util_helper
INFO - 2021-03-31 19:36:28 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:36:28 --> Form Validation Class Initialized
INFO - 2021-03-31 19:36:28 --> Controller Class Initialized
INFO - 2021-03-31 19:36:28 --> Model Class Initialized
INFO - 2021-03-31 19:36:28 --> Model Class Initialized
ERROR - 2021-03-31 19:36:28 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: UPDATE `company` SET `company_status` = '0'
WHERE `company` = ''
INFO - 2021-03-31 19:36:28 --> Final output sent to browser
DEBUG - 2021-03-31 19:36:28 --> Total execution time: 0.0486
INFO - 2021-03-31 19:38:11 --> Config Class Initialized
INFO - 2021-03-31 19:38:11 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:11 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:11 --> URI Class Initialized
INFO - 2021-03-31 19:38:11 --> Router Class Initialized
INFO - 2021-03-31 19:38:11 --> Output Class Initialized
INFO - 2021-03-31 19:38:11 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:11 --> Input Class Initialized
INFO - 2021-03-31 19:38:11 --> Language Class Initialized
INFO - 2021-03-31 19:38:11 --> Loader Class Initialized
INFO - 2021-03-31 19:38:11 --> Helper loaded: url_helper
INFO - 2021-03-31 19:38:11 --> Helper loaded: form_helper
INFO - 2021-03-31 19:38:11 --> Helper loaded: common_helper
INFO - 2021-03-31 19:38:11 --> Helper loaded: util_helper
INFO - 2021-03-31 19:38:11 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:38:11 --> Form Validation Class Initialized
INFO - 2021-03-31 19:38:11 --> Controller Class Initialized
INFO - 2021-03-31 19:38:11 --> Model Class Initialized
INFO - 2021-03-31 19:38:11 --> Model Class Initialized
INFO - 2021-03-31 19:38:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:38:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:38:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:38:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:38:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:38:11 --> Final output sent to browser
DEBUG - 2021-03-31 19:38:11 --> Total execution time: 0.0429
INFO - 2021-03-31 19:38:11 --> Config Class Initialized
INFO - 2021-03-31 19:38:11 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:11 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:11 --> Config Class Initialized
INFO - 2021-03-31 19:38:11 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:11 --> URI Class Initialized
DEBUG - 2021-03-31 19:38:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:11 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:11 --> Router Class Initialized
INFO - 2021-03-31 19:38:11 --> URI Class Initialized
INFO - 2021-03-31 19:38:11 --> Router Class Initialized
INFO - 2021-03-31 19:38:11 --> Output Class Initialized
INFO - 2021-03-31 19:38:11 --> Output Class Initialized
INFO - 2021-03-31 19:38:11 --> Security Class Initialized
INFO - 2021-03-31 19:38:11 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 19:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:11 --> Input Class Initialized
INFO - 2021-03-31 19:38:11 --> Input Class Initialized
INFO - 2021-03-31 19:38:11 --> Language Class Initialized
INFO - 2021-03-31 19:38:11 --> Language Class Initialized
ERROR - 2021-03-31 19:38:11 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:38:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:11 --> Config Class Initialized
INFO - 2021-03-31 19:38:11 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:11 --> Config Class Initialized
INFO - 2021-03-31 19:38:11 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:11 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:11 --> URI Class Initialized
DEBUG - 2021-03-31 19:38:11 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:11 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:11 --> Router Class Initialized
INFO - 2021-03-31 19:38:11 --> URI Class Initialized
INFO - 2021-03-31 19:38:11 --> Output Class Initialized
INFO - 2021-03-31 19:38:11 --> Router Class Initialized
INFO - 2021-03-31 19:38:11 --> Security Class Initialized
INFO - 2021-03-31 19:38:11 --> Output Class Initialized
DEBUG - 2021-03-31 19:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:11 --> Input Class Initialized
INFO - 2021-03-31 19:38:11 --> Security Class Initialized
INFO - 2021-03-31 19:38:11 --> Language Class Initialized
DEBUG - 2021-03-31 19:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:11 --> Input Class Initialized
ERROR - 2021-03-31 19:38:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:11 --> Language Class Initialized
ERROR - 2021-03-31 19:38:11 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:18 --> Config Class Initialized
INFO - 2021-03-31 19:38:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:18 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:18 --> URI Class Initialized
INFO - 2021-03-31 19:38:18 --> Router Class Initialized
INFO - 2021-03-31 19:38:18 --> Output Class Initialized
INFO - 2021-03-31 19:38:18 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:18 --> Input Class Initialized
INFO - 2021-03-31 19:38:18 --> Language Class Initialized
INFO - 2021-03-31 19:38:18 --> Loader Class Initialized
INFO - 2021-03-31 19:38:18 --> Helper loaded: url_helper
INFO - 2021-03-31 19:38:18 --> Helper loaded: form_helper
INFO - 2021-03-31 19:38:18 --> Helper loaded: common_helper
INFO - 2021-03-31 19:38:18 --> Helper loaded: util_helper
INFO - 2021-03-31 19:38:18 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:38:18 --> Form Validation Class Initialized
INFO - 2021-03-31 19:38:18 --> Controller Class Initialized
INFO - 2021-03-31 19:38:18 --> Model Class Initialized
INFO - 2021-03-31 19:38:18 --> Model Class Initialized
ERROR - 2021-03-31 19:38:18 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: UPDATE `company` SET `company_status` = '0'
WHERE `company` = ''
INFO - 2021-03-31 19:38:18 --> Final output sent to browser
DEBUG - 2021-03-31 19:38:18 --> Total execution time: 0.0411
INFO - 2021-03-31 19:38:28 --> Config Class Initialized
INFO - 2021-03-31 19:38:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:28 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:28 --> URI Class Initialized
INFO - 2021-03-31 19:38:28 --> Router Class Initialized
INFO - 2021-03-31 19:38:28 --> Output Class Initialized
INFO - 2021-03-31 19:38:28 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:28 --> Input Class Initialized
INFO - 2021-03-31 19:38:28 --> Language Class Initialized
INFO - 2021-03-31 19:38:28 --> Loader Class Initialized
INFO - 2021-03-31 19:38:28 --> Helper loaded: url_helper
INFO - 2021-03-31 19:38:28 --> Helper loaded: form_helper
INFO - 2021-03-31 19:38:28 --> Helper loaded: common_helper
INFO - 2021-03-31 19:38:28 --> Helper loaded: util_helper
INFO - 2021-03-31 19:38:28 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:38:28 --> Form Validation Class Initialized
INFO - 2021-03-31 19:38:28 --> Controller Class Initialized
INFO - 2021-03-31 19:38:28 --> Model Class Initialized
INFO - 2021-03-31 19:38:28 --> Model Class Initialized
INFO - 2021-03-31 19:38:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:38:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:38:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:38:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:38:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:38:28 --> Final output sent to browser
DEBUG - 2021-03-31 19:38:28 --> Total execution time: 0.0503
INFO - 2021-03-31 19:38:28 --> Config Class Initialized
INFO - 2021-03-31 19:38:28 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:28 --> Config Class Initialized
INFO - 2021-03-31 19:38:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:28 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:38:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:28 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:28 --> URI Class Initialized
INFO - 2021-03-31 19:38:28 --> URI Class Initialized
INFO - 2021-03-31 19:38:28 --> Router Class Initialized
INFO - 2021-03-31 19:38:28 --> Router Class Initialized
INFO - 2021-03-31 19:38:28 --> Output Class Initialized
INFO - 2021-03-31 19:38:28 --> Output Class Initialized
INFO - 2021-03-31 19:38:28 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:28 --> Security Class Initialized
INFO - 2021-03-31 19:38:28 --> Input Class Initialized
INFO - 2021-03-31 19:38:28 --> Language Class Initialized
DEBUG - 2021-03-31 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:28 --> Input Class Initialized
ERROR - 2021-03-31 19:38:28 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:28 --> Config Class Initialized
INFO - 2021-03-31 19:38:28 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:28 --> Config Class Initialized
INFO - 2021-03-31 19:38:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:28 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:28 --> URI Class Initialized
DEBUG - 2021-03-31 19:38:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:28 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:28 --> Router Class Initialized
INFO - 2021-03-31 19:38:28 --> URI Class Initialized
INFO - 2021-03-31 19:38:28 --> Output Class Initialized
INFO - 2021-03-31 19:38:28 --> Router Class Initialized
INFO - 2021-03-31 19:38:28 --> Security Class Initialized
INFO - 2021-03-31 19:38:28 --> Output Class Initialized
DEBUG - 2021-03-31 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:28 --> Input Class Initialized
INFO - 2021-03-31 19:38:28 --> Language Class Initialized
INFO - 2021-03-31 19:38:28 --> Security Class Initialized
ERROR - 2021-03-31 19:38:28 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-31 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:28 --> Input Class Initialized
INFO - 2021-03-31 19:38:28 --> Language Class Initialized
INFO - 2021-03-31 19:38:28 --> Language Class Initialized
ERROR - 2021-03-31 19:38:28 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:38:28 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:57 --> Config Class Initialized
INFO - 2021-03-31 19:38:57 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:57 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:57 --> URI Class Initialized
INFO - 2021-03-31 19:38:57 --> Router Class Initialized
INFO - 2021-03-31 19:38:57 --> Output Class Initialized
INFO - 2021-03-31 19:38:57 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:57 --> Input Class Initialized
INFO - 2021-03-31 19:38:57 --> Language Class Initialized
INFO - 2021-03-31 19:38:57 --> Loader Class Initialized
INFO - 2021-03-31 19:38:57 --> Helper loaded: url_helper
INFO - 2021-03-31 19:38:57 --> Helper loaded: form_helper
INFO - 2021-03-31 19:38:57 --> Helper loaded: common_helper
INFO - 2021-03-31 19:38:57 --> Helper loaded: util_helper
INFO - 2021-03-31 19:38:57 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:38:57 --> Form Validation Class Initialized
INFO - 2021-03-31 19:38:57 --> Controller Class Initialized
INFO - 2021-03-31 19:38:57 --> Model Class Initialized
INFO - 2021-03-31 19:38:57 --> Model Class Initialized
INFO - 2021-03-31 19:38:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:38:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:38:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:38:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:38:57 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:38:57 --> Final output sent to browser
DEBUG - 2021-03-31 19:38:57 --> Total execution time: 0.0380
INFO - 2021-03-31 19:38:57 --> Config Class Initialized
INFO - 2021-03-31 19:38:57 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:57 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:57 --> Config Class Initialized
INFO - 2021-03-31 19:38:57 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:57 --> URI Class Initialized
INFO - 2021-03-31 19:38:57 --> Router Class Initialized
DEBUG - 2021-03-31 19:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:57 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:57 --> URI Class Initialized
INFO - 2021-03-31 19:38:57 --> Output Class Initialized
INFO - 2021-03-31 19:38:57 --> Security Class Initialized
INFO - 2021-03-31 19:38:57 --> Router Class Initialized
DEBUG - 2021-03-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:57 --> Input Class Initialized
INFO - 2021-03-31 19:38:57 --> Output Class Initialized
INFO - 2021-03-31 19:38:57 --> Language Class Initialized
INFO - 2021-03-31 19:38:57 --> Security Class Initialized
ERROR - 2021-03-31 19:38:57 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:57 --> Input Class Initialized
INFO - 2021-03-31 19:38:57 --> Language Class Initialized
ERROR - 2021-03-31 19:38:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:57 --> Config Class Initialized
INFO - 2021-03-31 19:38:57 --> Hooks Class Initialized
INFO - 2021-03-31 19:38:57 --> Config Class Initialized
INFO - 2021-03-31 19:38:57 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:57 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:38:57 --> URI Class Initialized
INFO - 2021-03-31 19:38:57 --> Utf8 Class Initialized
INFO - 2021-03-31 19:38:57 --> URI Class Initialized
INFO - 2021-03-31 19:38:57 --> Router Class Initialized
INFO - 2021-03-31 19:38:57 --> Router Class Initialized
INFO - 2021-03-31 19:38:57 --> Output Class Initialized
INFO - 2021-03-31 19:38:57 --> Output Class Initialized
INFO - 2021-03-31 19:38:57 --> Security Class Initialized
INFO - 2021-03-31 19:38:57 --> Security Class Initialized
DEBUG - 2021-03-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:57 --> Input Class Initialized
INFO - 2021-03-31 19:38:57 --> Language Class Initialized
DEBUG - 2021-03-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:38:57 --> Input Class Initialized
ERROR - 2021-03-31 19:38:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:38:57 --> Language Class Initialized
ERROR - 2021-03-31 19:38:57 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:39:09 --> Config Class Initialized
INFO - 2021-03-31 19:39:09 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:39:09 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:39:09 --> Utf8 Class Initialized
INFO - 2021-03-31 19:39:09 --> URI Class Initialized
INFO - 2021-03-31 19:39:09 --> Router Class Initialized
INFO - 2021-03-31 19:39:09 --> Output Class Initialized
INFO - 2021-03-31 19:39:09 --> Security Class Initialized
DEBUG - 2021-03-31 19:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:39:09 --> Input Class Initialized
INFO - 2021-03-31 19:39:09 --> Language Class Initialized
INFO - 2021-03-31 19:39:09 --> Loader Class Initialized
INFO - 2021-03-31 19:39:09 --> Helper loaded: url_helper
INFO - 2021-03-31 19:39:09 --> Helper loaded: form_helper
INFO - 2021-03-31 19:39:09 --> Helper loaded: common_helper
INFO - 2021-03-31 19:39:09 --> Helper loaded: util_helper
INFO - 2021-03-31 19:39:09 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:39:09 --> Form Validation Class Initialized
INFO - 2021-03-31 19:39:09 --> Controller Class Initialized
INFO - 2021-03-31 19:39:09 --> Model Class Initialized
INFO - 2021-03-31 19:39:09 --> Model Class Initialized
ERROR - 2021-03-31 19:39:09 --> Query error: Unknown column 'company' in 'where clause' - Invalid query: UPDATE `company` SET `company_status` = '0'
WHERE `company` = '1'
INFO - 2021-03-31 19:39:09 --> Final output sent to browser
DEBUG - 2021-03-31 19:39:09 --> Total execution time: 0.0357
INFO - 2021-03-31 19:40:18 --> Config Class Initialized
INFO - 2021-03-31 19:40:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:18 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:18 --> URI Class Initialized
INFO - 2021-03-31 19:40:18 --> Router Class Initialized
INFO - 2021-03-31 19:40:18 --> Output Class Initialized
INFO - 2021-03-31 19:40:18 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:19 --> Input Class Initialized
INFO - 2021-03-31 19:40:19 --> Language Class Initialized
INFO - 2021-03-31 19:40:19 --> Loader Class Initialized
INFO - 2021-03-31 19:40:19 --> Helper loaded: url_helper
INFO - 2021-03-31 19:40:19 --> Helper loaded: form_helper
INFO - 2021-03-31 19:40:19 --> Helper loaded: common_helper
INFO - 2021-03-31 19:40:19 --> Helper loaded: util_helper
INFO - 2021-03-31 19:40:19 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:40:19 --> Form Validation Class Initialized
INFO - 2021-03-31 19:40:19 --> Controller Class Initialized
INFO - 2021-03-31 19:40:19 --> Model Class Initialized
INFO - 2021-03-31 19:40:19 --> Model Class Initialized
INFO - 2021-03-31 19:40:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:40:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:40:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:40:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:40:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:40:19 --> Final output sent to browser
DEBUG - 2021-03-31 19:40:19 --> Total execution time: 0.0469
INFO - 2021-03-31 19:40:19 --> Config Class Initialized
INFO - 2021-03-31 19:40:19 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:19 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:19 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:19 --> URI Class Initialized
INFO - 2021-03-31 19:40:19 --> Router Class Initialized
INFO - 2021-03-31 19:40:19 --> Config Class Initialized
INFO - 2021-03-31 19:40:19 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:19 --> Output Class Initialized
INFO - 2021-03-31 19:40:19 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:19 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:19 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:19 --> URI Class Initialized
INFO - 2021-03-31 19:40:19 --> Input Class Initialized
INFO - 2021-03-31 19:40:19 --> Language Class Initialized
INFO - 2021-03-31 19:40:19 --> Router Class Initialized
ERROR - 2021-03-31 19:40:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:19 --> Output Class Initialized
INFO - 2021-03-31 19:40:19 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:19 --> Input Class Initialized
INFO - 2021-03-31 19:40:19 --> Language Class Initialized
ERROR - 2021-03-31 19:40:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:19 --> Config Class Initialized
INFO - 2021-03-31 19:40:19 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:19 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:19 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:19 --> URI Class Initialized
INFO - 2021-03-31 19:40:19 --> Router Class Initialized
INFO - 2021-03-31 19:40:19 --> Output Class Initialized
INFO - 2021-03-31 19:40:19 --> Config Class Initialized
INFO - 2021-03-31 19:40:19 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:19 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 19:40:19 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:19 --> Input Class Initialized
INFO - 2021-03-31 19:40:19 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:19 --> Language Class Initialized
INFO - 2021-03-31 19:40:19 --> URI Class Initialized
ERROR - 2021-03-31 19:40:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:19 --> Router Class Initialized
INFO - 2021-03-31 19:40:19 --> Output Class Initialized
INFO - 2021-03-31 19:40:19 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:19 --> Input Class Initialized
INFO - 2021-03-31 19:40:19 --> Language Class Initialized
ERROR - 2021-03-31 19:40:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:24 --> Config Class Initialized
INFO - 2021-03-31 19:40:24 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:24 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:24 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:24 --> URI Class Initialized
INFO - 2021-03-31 19:40:24 --> Router Class Initialized
INFO - 2021-03-31 19:40:24 --> Output Class Initialized
INFO - 2021-03-31 19:40:24 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:24 --> Input Class Initialized
INFO - 2021-03-31 19:40:24 --> Language Class Initialized
INFO - 2021-03-31 19:40:24 --> Loader Class Initialized
INFO - 2021-03-31 19:40:24 --> Helper loaded: url_helper
INFO - 2021-03-31 19:40:24 --> Helper loaded: form_helper
INFO - 2021-03-31 19:40:24 --> Helper loaded: common_helper
INFO - 2021-03-31 19:40:24 --> Helper loaded: util_helper
INFO - 2021-03-31 19:40:24 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:40:24 --> Form Validation Class Initialized
INFO - 2021-03-31 19:40:24 --> Controller Class Initialized
INFO - 2021-03-31 19:40:24 --> Model Class Initialized
INFO - 2021-03-31 19:40:24 --> Model Class Initialized
INFO - 2021-03-31 19:40:24 --> Final output sent to browser
DEBUG - 2021-03-31 19:40:24 --> Total execution time: 0.0892
INFO - 2021-03-31 19:40:29 --> Config Class Initialized
INFO - 2021-03-31 19:40:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:29 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:29 --> URI Class Initialized
INFO - 2021-03-31 19:40:29 --> Router Class Initialized
INFO - 2021-03-31 19:40:29 --> Output Class Initialized
INFO - 2021-03-31 19:40:29 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:29 --> Input Class Initialized
INFO - 2021-03-31 19:40:29 --> Language Class Initialized
INFO - 2021-03-31 19:40:29 --> Loader Class Initialized
INFO - 2021-03-31 19:40:29 --> Helper loaded: url_helper
INFO - 2021-03-31 19:40:29 --> Helper loaded: form_helper
INFO - 2021-03-31 19:40:29 --> Helper loaded: common_helper
INFO - 2021-03-31 19:40:29 --> Helper loaded: util_helper
INFO - 2021-03-31 19:40:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:40:29 --> Form Validation Class Initialized
INFO - 2021-03-31 19:40:29 --> Controller Class Initialized
INFO - 2021-03-31 19:40:29 --> Model Class Initialized
INFO - 2021-03-31 19:40:29 --> Model Class Initialized
INFO - 2021-03-31 19:40:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:40:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:40:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:40:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:40:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:40:29 --> Final output sent to browser
DEBUG - 2021-03-31 19:40:29 --> Total execution time: 0.0413
INFO - 2021-03-31 19:40:29 --> Config Class Initialized
INFO - 2021-03-31 19:40:29 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:29 --> Config Class Initialized
INFO - 2021-03-31 19:40:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 19:40:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:29 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:29 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:29 --> URI Class Initialized
INFO - 2021-03-31 19:40:29 --> URI Class Initialized
INFO - 2021-03-31 19:40:29 --> Router Class Initialized
INFO - 2021-03-31 19:40:29 --> Router Class Initialized
INFO - 2021-03-31 19:40:29 --> Output Class Initialized
INFO - 2021-03-31 19:40:29 --> Output Class Initialized
INFO - 2021-03-31 19:40:29 --> Security Class Initialized
INFO - 2021-03-31 19:40:29 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:29 --> Input Class Initialized
INFO - 2021-03-31 19:40:29 --> Language Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:29 --> Input Class Initialized
ERROR - 2021-03-31 19:40:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:29 --> Language Class Initialized
ERROR - 2021-03-31 19:40:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:29 --> Config Class Initialized
INFO - 2021-03-31 19:40:29 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:29 --> Config Class Initialized
INFO - 2021-03-31 19:40:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:29 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:29 --> URI Class Initialized
DEBUG - 2021-03-31 19:40:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:29 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:29 --> Router Class Initialized
INFO - 2021-03-31 19:40:29 --> URI Class Initialized
INFO - 2021-03-31 19:40:29 --> Output Class Initialized
INFO - 2021-03-31 19:40:29 --> Router Class Initialized
INFO - 2021-03-31 19:40:29 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:29 --> Input Class Initialized
INFO - 2021-03-31 19:40:29 --> Language Class Initialized
ERROR - 2021-03-31 19:40:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:29 --> Output Class Initialized
INFO - 2021-03-31 19:40:29 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:29 --> Input Class Initialized
INFO - 2021-03-31 19:40:29 --> Language Class Initialized
ERROR - 2021-03-31 19:40:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:34 --> Config Class Initialized
INFO - 2021-03-31 19:40:34 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:34 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:34 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:34 --> URI Class Initialized
INFO - 2021-03-31 19:40:34 --> Router Class Initialized
INFO - 2021-03-31 19:40:34 --> Output Class Initialized
INFO - 2021-03-31 19:40:34 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:34 --> Input Class Initialized
INFO - 2021-03-31 19:40:34 --> Language Class Initialized
INFO - 2021-03-31 19:40:34 --> Loader Class Initialized
INFO - 2021-03-31 19:40:34 --> Helper loaded: url_helper
INFO - 2021-03-31 19:40:34 --> Helper loaded: form_helper
INFO - 2021-03-31 19:40:34 --> Helper loaded: common_helper
INFO - 2021-03-31 19:40:34 --> Helper loaded: util_helper
INFO - 2021-03-31 19:40:34 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:40:34 --> Form Validation Class Initialized
INFO - 2021-03-31 19:40:34 --> Controller Class Initialized
INFO - 2021-03-31 19:40:34 --> Model Class Initialized
INFO - 2021-03-31 19:40:34 --> Model Class Initialized
INFO - 2021-03-31 19:40:34 --> Final output sent to browser
DEBUG - 2021-03-31 19:40:34 --> Total execution time: 0.0942
INFO - 2021-03-31 19:40:37 --> Config Class Initialized
INFO - 2021-03-31 19:40:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:37 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:37 --> URI Class Initialized
INFO - 2021-03-31 19:40:37 --> Router Class Initialized
INFO - 2021-03-31 19:40:37 --> Output Class Initialized
INFO - 2021-03-31 19:40:37 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:37 --> Input Class Initialized
INFO - 2021-03-31 19:40:37 --> Language Class Initialized
INFO - 2021-03-31 19:40:37 --> Loader Class Initialized
INFO - 2021-03-31 19:40:37 --> Helper loaded: url_helper
INFO - 2021-03-31 19:40:37 --> Helper loaded: form_helper
INFO - 2021-03-31 19:40:37 --> Helper loaded: common_helper
INFO - 2021-03-31 19:40:37 --> Helper loaded: util_helper
INFO - 2021-03-31 19:40:37 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:40:37 --> Form Validation Class Initialized
INFO - 2021-03-31 19:40:37 --> Controller Class Initialized
INFO - 2021-03-31 19:40:37 --> Model Class Initialized
INFO - 2021-03-31 19:40:37 --> Model Class Initialized
INFO - 2021-03-31 19:40:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 19:40:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 19:40:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 19:40:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 19:40:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 19:40:37 --> Final output sent to browser
DEBUG - 2021-03-31 19:40:37 --> Total execution time: 0.0428
INFO - 2021-03-31 19:40:37 --> Config Class Initialized
INFO - 2021-03-31 19:40:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:37 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:37 --> URI Class Initialized
INFO - 2021-03-31 19:40:37 --> Config Class Initialized
INFO - 2021-03-31 19:40:37 --> Router Class Initialized
INFO - 2021-03-31 19:40:37 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:37 --> Output Class Initialized
INFO - 2021-03-31 19:40:37 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:37 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:37 --> Input Class Initialized
INFO - 2021-03-31 19:40:37 --> Language Class Initialized
INFO - 2021-03-31 19:40:37 --> URI Class Initialized
INFO - 2021-03-31 19:40:37 --> Router Class Initialized
ERROR - 2021-03-31 19:40:37 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:37 --> Output Class Initialized
INFO - 2021-03-31 19:40:37 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:37 --> Input Class Initialized
INFO - 2021-03-31 19:40:37 --> Language Class Initialized
ERROR - 2021-03-31 19:40:37 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:40:37 --> Config Class Initialized
INFO - 2021-03-31 19:40:37 --> Config Class Initialized
INFO - 2021-03-31 19:40:37 --> Hooks Class Initialized
INFO - 2021-03-31 19:40:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:40:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:37 --> Utf8 Class Initialized
DEBUG - 2021-03-31 19:40:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:40:37 --> Utf8 Class Initialized
INFO - 2021-03-31 19:40:37 --> URI Class Initialized
INFO - 2021-03-31 19:40:37 --> URI Class Initialized
INFO - 2021-03-31 19:40:37 --> Router Class Initialized
INFO - 2021-03-31 19:40:37 --> Router Class Initialized
INFO - 2021-03-31 19:40:37 --> Output Class Initialized
INFO - 2021-03-31 19:40:37 --> Output Class Initialized
INFO - 2021-03-31 19:40:37 --> Security Class Initialized
INFO - 2021-03-31 19:40:37 --> Security Class Initialized
DEBUG - 2021-03-31 19:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 19:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:40:37 --> Input Class Initialized
INFO - 2021-03-31 19:40:37 --> Input Class Initialized
INFO - 2021-03-31 19:40:37 --> Language Class Initialized
INFO - 2021-03-31 19:40:37 --> Language Class Initialized
ERROR - 2021-03-31 19:40:37 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 19:40:37 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 19:50:44 --> Config Class Initialized
INFO - 2021-03-31 19:50:44 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:50:44 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:50:44 --> Utf8 Class Initialized
INFO - 2021-03-31 19:50:44 --> URI Class Initialized
INFO - 2021-03-31 19:50:44 --> Router Class Initialized
INFO - 2021-03-31 19:50:44 --> Output Class Initialized
INFO - 2021-03-31 19:50:44 --> Security Class Initialized
DEBUG - 2021-03-31 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:50:44 --> Input Class Initialized
INFO - 2021-03-31 19:50:44 --> Language Class Initialized
INFO - 2021-03-31 19:50:44 --> Loader Class Initialized
INFO - 2021-03-31 19:50:44 --> Helper loaded: url_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: form_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: common_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: util_helper
INFO - 2021-03-31 19:50:44 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:50:44 --> Form Validation Class Initialized
INFO - 2021-03-31 19:50:44 --> Controller Class Initialized
INFO - 2021-03-31 19:50:44 --> Model Class Initialized
INFO - 2021-03-31 19:50:44 --> Config Class Initialized
INFO - 2021-03-31 19:50:44 --> Hooks Class Initialized
DEBUG - 2021-03-31 19:50:44 --> UTF-8 Support Enabled
INFO - 2021-03-31 19:50:44 --> Utf8 Class Initialized
INFO - 2021-03-31 19:50:44 --> URI Class Initialized
INFO - 2021-03-31 19:50:44 --> Router Class Initialized
INFO - 2021-03-31 19:50:44 --> Output Class Initialized
INFO - 2021-03-31 19:50:44 --> Security Class Initialized
DEBUG - 2021-03-31 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 19:50:44 --> Input Class Initialized
INFO - 2021-03-31 19:50:44 --> Language Class Initialized
INFO - 2021-03-31 19:50:44 --> Loader Class Initialized
INFO - 2021-03-31 19:50:44 --> Helper loaded: url_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: form_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: common_helper
INFO - 2021-03-31 19:50:44 --> Helper loaded: util_helper
INFO - 2021-03-31 19:50:44 --> Database Driver Class Initialized
DEBUG - 2021-03-31 19:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 19:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 19:50:44 --> Form Validation Class Initialized
INFO - 2021-03-31 19:50:44 --> Controller Class Initialized
INFO - 2021-03-31 19:50:44 --> Model Class Initialized
INFO - 2021-03-31 19:50:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 19:50:44 --> Final output sent to browser
DEBUG - 2021-03-31 19:50:44 --> Total execution time: 0.0440
INFO - 2021-03-31 22:24:46 --> Config Class Initialized
INFO - 2021-03-31 22:24:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:46 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:46 --> URI Class Initialized
INFO - 2021-03-31 22:24:46 --> Router Class Initialized
INFO - 2021-03-31 22:24:46 --> Output Class Initialized
INFO - 2021-03-31 22:24:46 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:46 --> Input Class Initialized
INFO - 2021-03-31 22:24:46 --> Language Class Initialized
INFO - 2021-03-31 22:24:46 --> Loader Class Initialized
INFO - 2021-03-31 22:24:46 --> Helper loaded: url_helper
INFO - 2021-03-31 22:24:46 --> Helper loaded: form_helper
INFO - 2021-03-31 22:24:46 --> Helper loaded: common_helper
INFO - 2021-03-31 22:24:46 --> Helper loaded: util_helper
INFO - 2021-03-31 22:24:46 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:24:46 --> Form Validation Class Initialized
INFO - 2021-03-31 22:24:46 --> Controller Class Initialized
INFO - 2021-03-31 22:24:46 --> Model Class Initialized
INFO - 2021-03-31 22:24:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 22:24:46 --> Final output sent to browser
DEBUG - 2021-03-31 22:24:46 --> Total execution time: 0.0508
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
INFO - 2021-03-31 22:24:48 --> Loader Class Initialized
INFO - 2021-03-31 22:24:48 --> Helper loaded: url_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: form_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: common_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: util_helper
INFO - 2021-03-31 22:24:48 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:24:48 --> Form Validation Class Initialized
INFO - 2021-03-31 22:24:48 --> Controller Class Initialized
INFO - 2021-03-31 22:24:48 --> Model Class Initialized
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
INFO - 2021-03-31 22:24:48 --> Loader Class Initialized
INFO - 2021-03-31 22:24:48 --> Helper loaded: url_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: form_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: common_helper
INFO - 2021-03-31 22:24:48 --> Helper loaded: util_helper
INFO - 2021-03-31 22:24:48 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:24:48 --> Form Validation Class Initialized
INFO - 2021-03-31 22:24:48 --> Controller Class Initialized
INFO - 2021-03-31 22:24:48 --> Model Class Initialized
INFO - 2021-03-31 22:24:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:24:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:24:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-31 22:24:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:24:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:24:48 --> Final output sent to browser
DEBUG - 2021-03-31 22:24:48 --> Total execution time: 0.0433
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
ERROR - 2021-03-31 22:24:48 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Config Class Initialized
INFO - 2021-03-31 22:24:48 --> Hooks Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
DEBUG - 2021-03-31 22:24:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:48 --> Utf8 Class Initialized
ERROR - 2021-03-31 22:24:48 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 22:24:48 --> URI Class Initialized
INFO - 2021-03-31 22:24:48 --> Router Class Initialized
INFO - 2021-03-31 22:24:48 --> Output Class Initialized
INFO - 2021-03-31 22:24:48 --> Security Class Initialized
ERROR - 2021-03-31 22:24:48 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-31 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:48 --> Input Class Initialized
INFO - 2021-03-31 22:24:48 --> Language Class Initialized
ERROR - 2021-03-31 22:24:48 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 22:24:56 --> Config Class Initialized
INFO - 2021-03-31 22:24:56 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:56 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:56 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:56 --> URI Class Initialized
INFO - 2021-03-31 22:24:56 --> Router Class Initialized
INFO - 2021-03-31 22:24:56 --> Output Class Initialized
INFO - 2021-03-31 22:24:56 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:56 --> Input Class Initialized
INFO - 2021-03-31 22:24:56 --> Language Class Initialized
INFO - 2021-03-31 22:24:56 --> Loader Class Initialized
INFO - 2021-03-31 22:24:56 --> Helper loaded: url_helper
INFO - 2021-03-31 22:24:56 --> Helper loaded: form_helper
INFO - 2021-03-31 22:24:56 --> Helper loaded: common_helper
INFO - 2021-03-31 22:24:56 --> Helper loaded: util_helper
INFO - 2021-03-31 22:24:56 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:24:56 --> Form Validation Class Initialized
INFO - 2021-03-31 22:24:56 --> Controller Class Initialized
INFO - 2021-03-31 22:24:56 --> Model Class Initialized
INFO - 2021-03-31 22:24:56 --> Model Class Initialized
INFO - 2021-03-31 22:24:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:24:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:24:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 22:24:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:24:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:24:56 --> Final output sent to browser
DEBUG - 2021-03-31 22:24:56 --> Total execution time: 0.0358
INFO - 2021-03-31 22:24:56 --> Config Class Initialized
INFO - 2021-03-31 22:24:56 --> Hooks Class Initialized
INFO - 2021-03-31 22:24:56 --> Config Class Initialized
INFO - 2021-03-31 22:24:56 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:56 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:56 --> Utf8 Class Initialized
DEBUG - 2021-03-31 22:24:56 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:56 --> URI Class Initialized
INFO - 2021-03-31 22:24:56 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:56 --> Router Class Initialized
INFO - 2021-03-31 22:24:56 --> URI Class Initialized
INFO - 2021-03-31 22:24:56 --> Output Class Initialized
INFO - 2021-03-31 22:24:56 --> Router Class Initialized
INFO - 2021-03-31 22:24:56 --> Security Class Initialized
DEBUG - 2021-03-31 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:56 --> Input Class Initialized
INFO - 2021-03-31 22:24:56 --> Output Class Initialized
INFO - 2021-03-31 22:24:56 --> Language Class Initialized
INFO - 2021-03-31 22:24:56 --> Security Class Initialized
ERROR - 2021-03-31 22:24:56 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-03-31 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:56 --> Input Class Initialized
INFO - 2021-03-31 22:24:56 --> Language Class Initialized
ERROR - 2021-03-31 22:24:56 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:24:56 --> Config Class Initialized
INFO - 2021-03-31 22:24:56 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:24:56 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:56 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:56 --> Config Class Initialized
INFO - 2021-03-31 22:24:56 --> Hooks Class Initialized
INFO - 2021-03-31 22:24:56 --> URI Class Initialized
INFO - 2021-03-31 22:24:56 --> Router Class Initialized
DEBUG - 2021-03-31 22:24:56 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:24:56 --> Utf8 Class Initialized
INFO - 2021-03-31 22:24:56 --> Output Class Initialized
INFO - 2021-03-31 22:24:56 --> URI Class Initialized
INFO - 2021-03-31 22:24:56 --> Security Class Initialized
INFO - 2021-03-31 22:24:56 --> Router Class Initialized
DEBUG - 2021-03-31 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:56 --> Input Class Initialized
INFO - 2021-03-31 22:24:56 --> Output Class Initialized
INFO - 2021-03-31 22:24:56 --> Language Class Initialized
INFO - 2021-03-31 22:24:56 --> Security Class Initialized
ERROR - 2021-03-31 22:24:56 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-03-31 22:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:24:56 --> Input Class Initialized
INFO - 2021-03-31 22:24:56 --> Language Class Initialized
ERROR - 2021-03-31 22:24:56 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:32:06 --> Config Class Initialized
INFO - 2021-03-31 22:32:06 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:32:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:32:06 --> Utf8 Class Initialized
INFO - 2021-03-31 22:32:06 --> URI Class Initialized
INFO - 2021-03-31 22:32:06 --> Router Class Initialized
INFO - 2021-03-31 22:32:06 --> Output Class Initialized
INFO - 2021-03-31 22:32:06 --> Security Class Initialized
DEBUG - 2021-03-31 22:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:32:06 --> Input Class Initialized
INFO - 2021-03-31 22:32:06 --> Language Class Initialized
INFO - 2021-03-31 22:32:06 --> Loader Class Initialized
INFO - 2021-03-31 22:32:06 --> Helper loaded: url_helper
INFO - 2021-03-31 22:32:06 --> Helper loaded: form_helper
INFO - 2021-03-31 22:32:06 --> Helper loaded: common_helper
INFO - 2021-03-31 22:32:06 --> Helper loaded: util_helper
INFO - 2021-03-31 22:32:06 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:32:07 --> Form Validation Class Initialized
INFO - 2021-03-31 22:32:07 --> Controller Class Initialized
INFO - 2021-03-31 22:32:07 --> Model Class Initialized
INFO - 2021-03-31 22:32:07 --> Model Class Initialized
INFO - 2021-03-31 22:32:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:32:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:32:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 22:32:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:32:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:32:07 --> Final output sent to browser
DEBUG - 2021-03-31 22:32:07 --> Total execution time: 0.0439
INFO - 2021-03-31 22:32:07 --> Config Class Initialized
INFO - 2021-03-31 22:32:07 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:32:07 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:32:07 --> Utf8 Class Initialized
INFO - 2021-03-31 22:32:07 --> URI Class Initialized
INFO - 2021-03-31 22:32:07 --> Config Class Initialized
INFO - 2021-03-31 22:32:07 --> Hooks Class Initialized
INFO - 2021-03-31 22:32:07 --> Router Class Initialized
DEBUG - 2021-03-31 22:32:07 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:32:07 --> Utf8 Class Initialized
INFO - 2021-03-31 22:32:07 --> URI Class Initialized
INFO - 2021-03-31 22:32:07 --> Router Class Initialized
INFO - 2021-03-31 22:32:07 --> Output Class Initialized
INFO - 2021-03-31 22:32:07 --> Output Class Initialized
INFO - 2021-03-31 22:32:07 --> Security Class Initialized
INFO - 2021-03-31 22:32:07 --> Security Class Initialized
DEBUG - 2021-03-31 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:32:07 --> Input Class Initialized
INFO - 2021-03-31 22:32:07 --> Language Class Initialized
DEBUG - 2021-03-31 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:32:07 --> Input Class Initialized
INFO - 2021-03-31 22:32:07 --> Language Class Initialized
ERROR - 2021-03-31 22:32:07 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 22:32:07 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:32:07 --> Config Class Initialized
INFO - 2021-03-31 22:32:07 --> Hooks Class Initialized
INFO - 2021-03-31 22:32:07 --> Config Class Initialized
INFO - 2021-03-31 22:32:07 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:32:07 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:32:07 --> Utf8 Class Initialized
INFO - 2021-03-31 22:32:07 --> URI Class Initialized
DEBUG - 2021-03-31 22:32:07 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:32:07 --> Utf8 Class Initialized
INFO - 2021-03-31 22:32:07 --> Router Class Initialized
INFO - 2021-03-31 22:32:07 --> URI Class Initialized
INFO - 2021-03-31 22:32:07 --> Output Class Initialized
INFO - 2021-03-31 22:32:07 --> Router Class Initialized
INFO - 2021-03-31 22:32:07 --> Security Class Initialized
DEBUG - 2021-03-31 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:32:07 --> Input Class Initialized
INFO - 2021-03-31 22:32:07 --> Output Class Initialized
INFO - 2021-03-31 22:32:07 --> Language Class Initialized
INFO - 2021-03-31 22:32:07 --> Security Class Initialized
ERROR - 2021-03-31 22:32:07 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-03-31 22:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:32:07 --> Input Class Initialized
INFO - 2021-03-31 22:32:07 --> Language Class Initialized
ERROR - 2021-03-31 22:32:07 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:33:39 --> Config Class Initialized
INFO - 2021-03-31 22:33:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:39 --> URI Class Initialized
INFO - 2021-03-31 22:33:39 --> Router Class Initialized
INFO - 2021-03-31 22:33:39 --> Output Class Initialized
INFO - 2021-03-31 22:33:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:39 --> Input Class Initialized
INFO - 2021-03-31 22:33:39 --> Language Class Initialized
INFO - 2021-03-31 22:33:39 --> Loader Class Initialized
INFO - 2021-03-31 22:33:39 --> Helper loaded: url_helper
INFO - 2021-03-31 22:33:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:33:39 --> Helper loaded: common_helper
INFO - 2021-03-31 22:33:39 --> Helper loaded: util_helper
INFO - 2021-03-31 22:33:39 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:33:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:33:39 --> Controller Class Initialized
INFO - 2021-03-31 22:33:39 --> Model Class Initialized
INFO - 2021-03-31 22:33:39 --> Model Class Initialized
INFO - 2021-03-31 22:33:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:33:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:33:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 22:33:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:33:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:33:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:33:39 --> Total execution time: 0.0354
INFO - 2021-03-31 22:33:39 --> Config Class Initialized
INFO - 2021-03-31 22:33:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:39 --> Config Class Initialized
INFO - 2021-03-31 22:33:39 --> URI Class Initialized
INFO - 2021-03-31 22:33:39 --> Hooks Class Initialized
INFO - 2021-03-31 22:33:39 --> Router Class Initialized
DEBUG - 2021-03-31 22:33:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:39 --> Output Class Initialized
INFO - 2021-03-31 22:33:39 --> URI Class Initialized
INFO - 2021-03-31 22:33:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:39 --> Router Class Initialized
INFO - 2021-03-31 22:33:39 --> Input Class Initialized
INFO - 2021-03-31 22:33:39 --> Language Class Initialized
INFO - 2021-03-31 22:33:39 --> Output Class Initialized
ERROR - 2021-03-31 22:33:39 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:33:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:39 --> Input Class Initialized
INFO - 2021-03-31 22:33:39 --> Language Class Initialized
ERROR - 2021-03-31 22:33:39 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:33:39 --> Config Class Initialized
INFO - 2021-03-31 22:33:39 --> Hooks Class Initialized
INFO - 2021-03-31 22:33:39 --> Config Class Initialized
INFO - 2021-03-31 22:33:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 22:33:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:39 --> URI Class Initialized
INFO - 2021-03-31 22:33:39 --> URI Class Initialized
INFO - 2021-03-31 22:33:39 --> Router Class Initialized
INFO - 2021-03-31 22:33:39 --> Router Class Initialized
INFO - 2021-03-31 22:33:39 --> Output Class Initialized
INFO - 2021-03-31 22:33:39 --> Output Class Initialized
INFO - 2021-03-31 22:33:39 --> Security Class Initialized
INFO - 2021-03-31 22:33:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:39 --> Input Class Initialized
DEBUG - 2021-03-31 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:39 --> Language Class Initialized
INFO - 2021-03-31 22:33:39 --> Input Class Initialized
INFO - 2021-03-31 22:33:39 --> Language Class Initialized
ERROR - 2021-03-31 22:33:39 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 22:33:39 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:33:42 --> Config Class Initialized
INFO - 2021-03-31 22:33:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:42 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:42 --> URI Class Initialized
INFO - 2021-03-31 22:33:42 --> Router Class Initialized
INFO - 2021-03-31 22:33:42 --> Output Class Initialized
INFO - 2021-03-31 22:33:42 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:42 --> Input Class Initialized
INFO - 2021-03-31 22:33:42 --> Language Class Initialized
INFO - 2021-03-31 22:33:42 --> Loader Class Initialized
INFO - 2021-03-31 22:33:42 --> Helper loaded: url_helper
INFO - 2021-03-31 22:33:42 --> Helper loaded: form_helper
INFO - 2021-03-31 22:33:42 --> Helper loaded: common_helper
INFO - 2021-03-31 22:33:42 --> Helper loaded: util_helper
INFO - 2021-03-31 22:33:42 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:33:42 --> Form Validation Class Initialized
INFO - 2021-03-31 22:33:42 --> Controller Class Initialized
INFO - 2021-03-31 22:33:42 --> Model Class Initialized
INFO - 2021-03-31 22:33:42 --> Model Class Initialized
INFO - 2021-03-31 22:33:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:33:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:33:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 22:33:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:33:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:33:42 --> Final output sent to browser
DEBUG - 2021-03-31 22:33:42 --> Total execution time: 0.0360
INFO - 2021-03-31 22:33:42 --> Config Class Initialized
INFO - 2021-03-31 22:33:42 --> Config Class Initialized
INFO - 2021-03-31 22:33:42 --> Hooks Class Initialized
INFO - 2021-03-31 22:33:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 22:33:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:42 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:42 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:42 --> URI Class Initialized
INFO - 2021-03-31 22:33:42 --> URI Class Initialized
INFO - 2021-03-31 22:33:42 --> Router Class Initialized
INFO - 2021-03-31 22:33:42 --> Router Class Initialized
INFO - 2021-03-31 22:33:42 --> Output Class Initialized
INFO - 2021-03-31 22:33:42 --> Output Class Initialized
INFO - 2021-03-31 22:33:42 --> Security Class Initialized
INFO - 2021-03-31 22:33:42 --> Security Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:42 --> Input Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:42 --> Input Class Initialized
INFO - 2021-03-31 22:33:42 --> Language Class Initialized
INFO - 2021-03-31 22:33:42 --> Language Class Initialized
ERROR - 2021-03-31 22:33:42 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 22:33:42 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:33:42 --> Config Class Initialized
INFO - 2021-03-31 22:33:42 --> Hooks Class Initialized
INFO - 2021-03-31 22:33:42 --> Config Class Initialized
INFO - 2021-03-31 22:33:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:33:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:42 --> Utf8 Class Initialized
DEBUG - 2021-03-31 22:33:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:33:42 --> Utf8 Class Initialized
INFO - 2021-03-31 22:33:42 --> URI Class Initialized
INFO - 2021-03-31 22:33:42 --> URI Class Initialized
INFO - 2021-03-31 22:33:42 --> Router Class Initialized
INFO - 2021-03-31 22:33:42 --> Router Class Initialized
INFO - 2021-03-31 22:33:42 --> Output Class Initialized
INFO - 2021-03-31 22:33:42 --> Security Class Initialized
INFO - 2021-03-31 22:33:42 --> Output Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:42 --> Security Class Initialized
INFO - 2021-03-31 22:33:42 --> Input Class Initialized
INFO - 2021-03-31 22:33:42 --> Language Class Initialized
DEBUG - 2021-03-31 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:33:42 --> Input Class Initialized
INFO - 2021-03-31 22:33:42 --> Language Class Initialized
ERROR - 2021-03-31 22:33:42 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 22:33:42 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:35:16 --> Config Class Initialized
INFO - 2021-03-31 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:16 --> URI Class Initialized
INFO - 2021-03-31 22:35:16 --> Router Class Initialized
INFO - 2021-03-31 22:35:16 --> Output Class Initialized
INFO - 2021-03-31 22:35:16 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:16 --> Input Class Initialized
INFO - 2021-03-31 22:35:16 --> Language Class Initialized
INFO - 2021-03-31 22:35:16 --> Loader Class Initialized
INFO - 2021-03-31 22:35:16 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:16 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:16 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:16 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:16 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:16 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:16 --> Controller Class Initialized
INFO - 2021-03-31 22:35:16 --> Model Class Initialized
INFO - 2021-03-31 22:35:16 --> Model Class Initialized
INFO - 2021-03-31 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:16 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:16 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:16 --> Total execution time: 0.0432
INFO - 2021-03-31 22:35:16 --> Config Class Initialized
INFO - 2021-03-31 22:35:16 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:16 --> Config Class Initialized
INFO - 2021-03-31 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:16 --> URI Class Initialized
DEBUG - 2021-03-31 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:16 --> Router Class Initialized
INFO - 2021-03-31 22:35:16 --> URI Class Initialized
INFO - 2021-03-31 22:35:16 --> Output Class Initialized
INFO - 2021-03-31 22:35:16 --> Security Class Initialized
INFO - 2021-03-31 22:35:16 --> Router Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:16 --> Input Class Initialized
INFO - 2021-03-31 22:35:16 --> Output Class Initialized
INFO - 2021-03-31 22:35:16 --> Language Class Initialized
INFO - 2021-03-31 22:35:16 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-31 22:35:16 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:35:16 --> Input Class Initialized
INFO - 2021-03-31 22:35:16 --> Language Class Initialized
ERROR - 2021-03-31 22:35:16 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:35:16 --> Config Class Initialized
INFO - 2021-03-31 22:35:16 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:16 --> Config Class Initialized
INFO - 2021-03-31 22:35:16 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:16 --> URI Class Initialized
DEBUG - 2021-03-31 22:35:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:16 --> Router Class Initialized
INFO - 2021-03-31 22:35:16 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:16 --> URI Class Initialized
INFO - 2021-03-31 22:35:16 --> Output Class Initialized
INFO - 2021-03-31 22:35:16 --> Router Class Initialized
INFO - 2021-03-31 22:35:16 --> Security Class Initialized
INFO - 2021-03-31 22:35:16 --> Output Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:16 --> Input Class Initialized
INFO - 2021-03-31 22:35:16 --> Security Class Initialized
INFO - 2021-03-31 22:35:16 --> Language Class Initialized
DEBUG - 2021-03-31 22:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:16 --> Input Class Initialized
INFO - 2021-03-31 22:35:16 --> Language Class Initialized
ERROR - 2021-03-31 22:35:16 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 22:35:16 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 22:35:35 --> Config Class Initialized
INFO - 2021-03-31 22:35:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:35 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:35 --> URI Class Initialized
INFO - 2021-03-31 22:35:35 --> Router Class Initialized
INFO - 2021-03-31 22:35:35 --> Output Class Initialized
INFO - 2021-03-31 22:35:35 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:35 --> Input Class Initialized
INFO - 2021-03-31 22:35:35 --> Language Class Initialized
INFO - 2021-03-31 22:35:35 --> Loader Class Initialized
INFO - 2021-03-31 22:35:35 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:35 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:35 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:35 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:35 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:35 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:35 --> Controller Class Initialized
INFO - 2021-03-31 22:35:35 --> Model Class Initialized
INFO - 2021-03-31 22:35:35 --> Model Class Initialized
INFO - 2021-03-31 22:35:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-03-31 22:35:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:35 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:35 --> Total execution time: 0.0367
INFO - 2021-03-31 22:35:35 --> Config Class Initialized
INFO - 2021-03-31 22:35:35 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:35 --> Config Class Initialized
INFO - 2021-03-31 22:35:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:35 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 22:35:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:35 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:35 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:35 --> URI Class Initialized
INFO - 2021-03-31 22:35:35 --> URI Class Initialized
INFO - 2021-03-31 22:35:35 --> Router Class Initialized
INFO - 2021-03-31 22:35:35 --> Router Class Initialized
INFO - 2021-03-31 22:35:35 --> Output Class Initialized
INFO - 2021-03-31 22:35:35 --> Output Class Initialized
INFO - 2021-03-31 22:35:35 --> Security Class Initialized
INFO - 2021-03-31 22:35:35 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 22:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:35 --> Input Class Initialized
INFO - 2021-03-31 22:35:35 --> Input Class Initialized
INFO - 2021-03-31 22:35:35 --> Language Class Initialized
INFO - 2021-03-31 22:35:35 --> Language Class Initialized
ERROR - 2021-03-31 22:35:35 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-31 22:35:35 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 22:35:35 --> Config Class Initialized
INFO - 2021-03-31 22:35:35 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:35 --> Config Class Initialized
INFO - 2021-03-31 22:35:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:35 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:35 --> URI Class Initialized
DEBUG - 2021-03-31 22:35:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:35 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:35 --> URI Class Initialized
INFO - 2021-03-31 22:35:35 --> Router Class Initialized
INFO - 2021-03-31 22:35:35 --> Router Class Initialized
INFO - 2021-03-31 22:35:35 --> Output Class Initialized
INFO - 2021-03-31 22:35:35 --> Security Class Initialized
INFO - 2021-03-31 22:35:35 --> Output Class Initialized
DEBUG - 2021-03-31 22:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:35 --> Input Class Initialized
INFO - 2021-03-31 22:35:35 --> Security Class Initialized
INFO - 2021-03-31 22:35:35 --> Language Class Initialized
DEBUG - 2021-03-31 22:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:35 --> Input Class Initialized
ERROR - 2021-03-31 22:35:35 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 22:35:35 --> Language Class Initialized
ERROR - 2021-03-31 22:35:35 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-31 22:35:39 --> Config Class Initialized
INFO - 2021-03-31 22:35:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:39 --> URI Class Initialized
INFO - 2021-03-31 22:35:39 --> Router Class Initialized
INFO - 2021-03-31 22:35:39 --> Output Class Initialized
INFO - 2021-03-31 22:35:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:39 --> Input Class Initialized
INFO - 2021-03-31 22:35:39 --> Language Class Initialized
INFO - 2021-03-31 22:35:39 --> Loader Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:39 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:39 --> Controller Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:39 --> Total execution time: 0.0357
INFO - 2021-03-31 22:35:39 --> Config Class Initialized
INFO - 2021-03-31 22:35:39 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:39 --> Config Class Initialized
INFO - 2021-03-31 22:35:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:35:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:39 --> URI Class Initialized
DEBUG - 2021-03-31 22:35:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:39 --> URI Class Initialized
INFO - 2021-03-31 22:35:39 --> Router Class Initialized
INFO - 2021-03-31 22:35:39 --> Router Class Initialized
INFO - 2021-03-31 22:35:39 --> Output Class Initialized
INFO - 2021-03-31 22:35:39 --> Security Class Initialized
INFO - 2021-03-31 22:35:39 --> Output Class Initialized
INFO - 2021-03-31 22:35:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:39 --> Input Class Initialized
INFO - 2021-03-31 22:35:39 --> Language Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:39 --> Loader Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:39 --> Config Class Initialized
INFO - 2021-03-31 22:35:39 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: common_helper
DEBUG - 2021-03-31 22:35:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:39 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:39 --> URI Class Initialized
INFO - 2021-03-31 22:35:39 --> Router Class Initialized
INFO - 2021-03-31 22:35:39 --> Input Class Initialized
INFO - 2021-03-31 22:35:39 --> Language Class Initialized
INFO - 2021-03-31 22:35:39 --> Output Class Initialized
INFO - 2021-03-31 22:35:39 --> Database Driver Class Initialized
INFO - 2021-03-31 22:35:39 --> Security Class Initialized
INFO - 2021-03-31 22:35:39 --> Loader Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:39 --> Input Class Initialized
INFO - 2021-03-31 22:35:39 --> Language Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: url_helper
DEBUG - 2021-03-31 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:39 --> Loader Class Initialized
INFO - 2021-03-31 22:35:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:39 --> Controller Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:39 --> Config Class Initialized
INFO - 2021-03-31 22:35:39 --> Hooks Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: util_helper
DEBUG - 2021-03-31 22:35:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:39 --> Utf8 Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:39 --> URI Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:39 --> Router Class Initialized
INFO - 2021-03-31 22:35:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:39 --> Total execution time: 0.0441
INFO - 2021-03-31 22:35:39 --> Database Driver Class Initialized
INFO - 2021-03-31 22:35:39 --> Output Class Initialized
INFO - 2021-03-31 22:35:39 --> Security Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:35:39 --> Input Class Initialized
INFO - 2021-03-31 22:35:39 --> Language Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:39 --> Database Driver Class Initialized
INFO - 2021-03-31 22:35:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:39 --> Controller Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
DEBUG - 2021-03-31 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:39 --> Loader Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:39 --> Helper loaded: url_helper
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:39 --> Helper loaded: form_helper
INFO - 2021-03-31 22:35:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:39 --> Total execution time: 0.0446
INFO - 2021-03-31 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:39 --> Helper loaded: common_helper
INFO - 2021-03-31 22:35:39 --> Helper loaded: util_helper
INFO - 2021-03-31 22:35:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:39 --> Controller Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:39 --> Database Driver Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:39 --> Total execution time: 0.0748
DEBUG - 2021-03-31 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:35:39 --> Form Validation Class Initialized
INFO - 2021-03-31 22:35:39 --> Controller Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> Model Class Initialized
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:35:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:35:39 --> Final output sent to browser
DEBUG - 2021-03-31 22:35:39 --> Total execution time: 0.0520
INFO - 2021-03-31 22:42:36 --> Config Class Initialized
INFO - 2021-03-31 22:42:36 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:42:36 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:42:36 --> Utf8 Class Initialized
INFO - 2021-03-31 22:42:36 --> URI Class Initialized
INFO - 2021-03-31 22:42:36 --> Router Class Initialized
INFO - 2021-03-31 22:42:36 --> Output Class Initialized
INFO - 2021-03-31 22:42:36 --> Security Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:42:36 --> Input Class Initialized
INFO - 2021-03-31 22:42:36 --> Language Class Initialized
INFO - 2021-03-31 22:42:36 --> Loader Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: url_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: form_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: common_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: util_helper
INFO - 2021-03-31 22:42:36 --> Database Driver Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:42:36 --> Form Validation Class Initialized
INFO - 2021-03-31 22:42:36 --> Controller Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2021-03-31 22:42:36 --> Total execution time: 0.0474
INFO - 2021-03-31 22:42:36 --> Config Class Initialized
INFO - 2021-03-31 22:42:36 --> Hooks Class Initialized
INFO - 2021-03-31 22:42:36 --> Config Class Initialized
INFO - 2021-03-31 22:42:36 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:42:36 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:42:36 --> Utf8 Class Initialized
INFO - 2021-03-31 22:42:36 --> URI Class Initialized
DEBUG - 2021-03-31 22:42:36 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:42:36 --> Utf8 Class Initialized
INFO - 2021-03-31 22:42:36 --> Router Class Initialized
INFO - 2021-03-31 22:42:36 --> Output Class Initialized
INFO - 2021-03-31 22:42:36 --> URI Class Initialized
INFO - 2021-03-31 22:42:36 --> Security Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:42:36 --> Input Class Initialized
INFO - 2021-03-31 22:42:36 --> Language Class Initialized
INFO - 2021-03-31 22:42:36 --> Router Class Initialized
INFO - 2021-03-31 22:42:36 --> Output Class Initialized
INFO - 2021-03-31 22:42:36 --> Loader Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: url_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: form_helper
INFO - 2021-03-31 22:42:36 --> Security Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: common_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: util_helper
DEBUG - 2021-03-31 22:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:42:36 --> Input Class Initialized
INFO - 2021-03-31 22:42:36 --> Language Class Initialized
INFO - 2021-03-31 22:42:36 --> Loader Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: url_helper
INFO - 2021-03-31 22:42:36 --> Config Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: form_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: common_helper
INFO - 2021-03-31 22:42:36 --> Hooks Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: util_helper
INFO - 2021-03-31 22:42:36 --> Config Class Initialized
INFO - 2021-03-31 22:42:36 --> Hooks Class Initialized
DEBUG - 2021-03-31 22:42:36 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:42:36 --> Utf8 Class Initialized
DEBUG - 2021-03-31 22:42:36 --> UTF-8 Support Enabled
INFO - 2021-03-31 22:42:36 --> Database Driver Class Initialized
INFO - 2021-03-31 22:42:36 --> Utf8 Class Initialized
INFO - 2021-03-31 22:42:36 --> URI Class Initialized
INFO - 2021-03-31 22:42:36 --> URI Class Initialized
INFO - 2021-03-31 22:42:36 --> Router Class Initialized
INFO - 2021-03-31 22:42:36 --> Router Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:42:36 --> Output Class Initialized
INFO - 2021-03-31 22:42:36 --> Form Validation Class Initialized
INFO - 2021-03-31 22:42:36 --> Controller Class Initialized
INFO - 2021-03-31 22:42:36 --> Security Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Input Class Initialized
INFO - 2021-03-31 22:42:36 --> Output Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Language Class Initialized
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:42:36 --> Loader Class Initialized
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2021-03-31 22:42:36 --> Total execution time: 0.0577
INFO - 2021-03-31 22:42:36 --> Security Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: url_helper
DEBUG - 2021-03-31 22:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 22:42:36 --> Helper loaded: form_helper
INFO - 2021-03-31 22:42:36 --> Input Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: common_helper
INFO - 2021-03-31 22:42:36 --> Helper loaded: util_helper
INFO - 2021-03-31 22:42:36 --> Database Driver Class Initialized
INFO - 2021-03-31 22:42:36 --> Language Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:42:36 --> Database Driver Class Initialized
INFO - 2021-03-31 22:42:36 --> Loader Class Initialized
INFO - 2021-03-31 22:42:36 --> Form Validation Class Initialized
INFO - 2021-03-31 22:42:36 --> Controller Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Helper loaded: url_helper
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
DEBUG - 2021-03-31 22:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:42:36 --> Helper loaded: form_helper
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:42:36 --> Helper loaded: common_helper
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:42:36 --> Helper loaded: util_helper
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2021-03-31 22:42:36 --> Total execution time: 0.0812
INFO - 2021-03-31 22:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:42:36 --> Form Validation Class Initialized
INFO - 2021-03-31 22:42:36 --> Controller Class Initialized
INFO - 2021-03-31 22:42:36 --> Database Driver Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-31 22:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2021-03-31 22:42:36 --> Total execution time: 0.0601
INFO - 2021-03-31 22:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 22:42:36 --> Form Validation Class Initialized
INFO - 2021-03-31 22:42:36 --> Controller Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> Model Class Initialized
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 22:42:36 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2021-03-31 22:42:36 --> Total execution time: 0.0807
INFO - 2021-03-31 23:04:04 --> Config Class Initialized
INFO - 2021-03-31 23:04:04 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:04:04 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:04:04 --> Utf8 Class Initialized
INFO - 2021-03-31 23:04:04 --> URI Class Initialized
INFO - 2021-03-31 23:04:04 --> Router Class Initialized
INFO - 2021-03-31 23:04:04 --> Output Class Initialized
INFO - 2021-03-31 23:04:04 --> Security Class Initialized
DEBUG - 2021-03-31 23:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:04:04 --> Input Class Initialized
INFO - 2021-03-31 23:04:04 --> Language Class Initialized
INFO - 2021-03-31 23:04:04 --> Loader Class Initialized
INFO - 2021-03-31 23:04:04 --> Helper loaded: url_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: form_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: common_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: util_helper
INFO - 2021-03-31 23:04:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:04:04 --> Form Validation Class Initialized
INFO - 2021-03-31 23:04:04 --> Controller Class Initialized
INFO - 2021-03-31 23:04:04 --> Model Class Initialized
INFO - 2021-03-31 23:04:04 --> Config Class Initialized
INFO - 2021-03-31 23:04:04 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:04:04 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:04:04 --> Utf8 Class Initialized
INFO - 2021-03-31 23:04:04 --> URI Class Initialized
INFO - 2021-03-31 23:04:04 --> Router Class Initialized
INFO - 2021-03-31 23:04:04 --> Output Class Initialized
INFO - 2021-03-31 23:04:04 --> Security Class Initialized
DEBUG - 2021-03-31 23:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:04:04 --> Input Class Initialized
INFO - 2021-03-31 23:04:04 --> Language Class Initialized
INFO - 2021-03-31 23:04:04 --> Loader Class Initialized
INFO - 2021-03-31 23:04:04 --> Helper loaded: url_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: form_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: common_helper
INFO - 2021-03-31 23:04:04 --> Helper loaded: util_helper
INFO - 2021-03-31 23:04:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:04:04 --> Form Validation Class Initialized
INFO - 2021-03-31 23:04:04 --> Controller Class Initialized
INFO - 2021-03-31 23:04:04 --> Model Class Initialized
INFO - 2021-03-31 23:04:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 23:04:04 --> Final output sent to browser
DEBUG - 2021-03-31 23:04:04 --> Total execution time: 0.0329
INFO - 2021-03-31 23:38:12 --> Config Class Initialized
INFO - 2021-03-31 23:38:12 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:12 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:12 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:12 --> URI Class Initialized
INFO - 2021-03-31 23:38:12 --> Router Class Initialized
INFO - 2021-03-31 23:38:12 --> Output Class Initialized
INFO - 2021-03-31 23:38:12 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:12 --> Input Class Initialized
INFO - 2021-03-31 23:38:12 --> Language Class Initialized
INFO - 2021-03-31 23:38:12 --> Loader Class Initialized
INFO - 2021-03-31 23:38:12 --> Helper loaded: url_helper
INFO - 2021-03-31 23:38:12 --> Helper loaded: form_helper
INFO - 2021-03-31 23:38:12 --> Helper loaded: common_helper
INFO - 2021-03-31 23:38:12 --> Helper loaded: util_helper
INFO - 2021-03-31 23:38:12 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:38:12 --> Form Validation Class Initialized
INFO - 2021-03-31 23:38:12 --> Controller Class Initialized
INFO - 2021-03-31 23:38:12 --> Model Class Initialized
INFO - 2021-03-31 23:38:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 23:38:12 --> Final output sent to browser
DEBUG - 2021-03-31 23:38:12 --> Total execution time: 0.1092
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
INFO - 2021-03-31 23:38:15 --> Loader Class Initialized
INFO - 2021-03-31 23:38:15 --> Helper loaded: url_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: form_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: common_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: util_helper
INFO - 2021-03-31 23:38:15 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:38:15 --> Form Validation Class Initialized
INFO - 2021-03-31 23:38:15 --> Controller Class Initialized
INFO - 2021-03-31 23:38:15 --> Model Class Initialized
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
INFO - 2021-03-31 23:38:15 --> Loader Class Initialized
INFO - 2021-03-31 23:38:15 --> Helper loaded: url_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: form_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: common_helper
INFO - 2021-03-31 23:38:15 --> Helper loaded: util_helper
INFO - 2021-03-31 23:38:15 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:38:15 --> Form Validation Class Initialized
INFO - 2021-03-31 23:38:15 --> Controller Class Initialized
INFO - 2021-03-31 23:38:15 --> Model Class Initialized
INFO - 2021-03-31 23:38:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:38:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:38:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-31 23:38:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:38:15 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:38:15 --> Final output sent to browser
DEBUG - 2021-03-31 23:38:15 --> Total execution time: 0.0340
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
ERROR - 2021-03-31 23:38:15 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> Config Class Initialized
INFO - 2021-03-31 23:38:15 --> Hooks Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
DEBUG - 2021-03-31 23:38:15 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
INFO - 2021-03-31 23:38:15 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> URI Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
INFO - 2021-03-31 23:38:15 --> Router Class Initialized
ERROR - 2021-03-31 23:38:15 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-31 23:38:15 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:38:15 --> Output Class Initialized
INFO - 2021-03-31 23:38:15 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:15 --> Input Class Initialized
INFO - 2021-03-31 23:38:15 --> Language Class Initialized
ERROR - 2021-03-31 23:38:15 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:38:22 --> Config Class Initialized
INFO - 2021-03-31 23:38:22 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:22 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:22 --> URI Class Initialized
INFO - 2021-03-31 23:38:22 --> Router Class Initialized
INFO - 2021-03-31 23:38:22 --> Output Class Initialized
INFO - 2021-03-31 23:38:22 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:22 --> Input Class Initialized
INFO - 2021-03-31 23:38:22 --> Language Class Initialized
INFO - 2021-03-31 23:38:22 --> Loader Class Initialized
INFO - 2021-03-31 23:38:22 --> Helper loaded: url_helper
INFO - 2021-03-31 23:38:22 --> Helper loaded: form_helper
INFO - 2021-03-31 23:38:22 --> Helper loaded: common_helper
INFO - 2021-03-31 23:38:22 --> Helper loaded: util_helper
INFO - 2021-03-31 23:38:22 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:38:22 --> Form Validation Class Initialized
INFO - 2021-03-31 23:38:22 --> Controller Class Initialized
INFO - 2021-03-31 23:38:22 --> Model Class Initialized
INFO - 2021-03-31 23:38:22 --> Model Class Initialized
INFO - 2021-03-31 23:38:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:38:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:38:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 23:38:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:38:22 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:38:22 --> Final output sent to browser
DEBUG - 2021-03-31 23:38:22 --> Total execution time: 0.0339
INFO - 2021-03-31 23:38:22 --> Config Class Initialized
INFO - 2021-03-31 23:38:22 --> Hooks Class Initialized
INFO - 2021-03-31 23:38:22 --> Config Class Initialized
DEBUG - 2021-03-31 23:38:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:22 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:22 --> Hooks Class Initialized
INFO - 2021-03-31 23:38:22 --> URI Class Initialized
INFO - 2021-03-31 23:38:22 --> Router Class Initialized
INFO - 2021-03-31 23:38:22 --> Output Class Initialized
INFO - 2021-03-31 23:38:22 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:22 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:22 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:22 --> Input Class Initialized
INFO - 2021-03-31 23:38:22 --> Language Class Initialized
INFO - 2021-03-31 23:38:22 --> URI Class Initialized
ERROR - 2021-03-31 23:38:22 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:38:23 --> Router Class Initialized
INFO - 2021-03-31 23:38:23 --> Output Class Initialized
INFO - 2021-03-31 23:38:23 --> Security Class Initialized
INFO - 2021-03-31 23:38:23 --> Config Class Initialized
INFO - 2021-03-31 23:38:23 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:23 --> Input Class Initialized
DEBUG - 2021-03-31 23:38:23 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:23 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:23 --> Language Class Initialized
INFO - 2021-03-31 23:38:23 --> URI Class Initialized
ERROR - 2021-03-31 23:38:23 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:38:23 --> Router Class Initialized
INFO - 2021-03-31 23:38:23 --> Output Class Initialized
INFO - 2021-03-31 23:38:23 --> Config Class Initialized
INFO - 2021-03-31 23:38:23 --> Hooks Class Initialized
INFO - 2021-03-31 23:38:23 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:23 --> Input Class Initialized
DEBUG - 2021-03-31 23:38:23 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:38:23 --> Language Class Initialized
INFO - 2021-03-31 23:38:23 --> Utf8 Class Initialized
INFO - 2021-03-31 23:38:23 --> URI Class Initialized
ERROR - 2021-03-31 23:38:23 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:38:23 --> Router Class Initialized
INFO - 2021-03-31 23:38:23 --> Output Class Initialized
INFO - 2021-03-31 23:38:23 --> Security Class Initialized
DEBUG - 2021-03-31 23:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:38:23 --> Input Class Initialized
INFO - 2021-03-31 23:38:23 --> Language Class Initialized
ERROR - 2021-03-31 23:38:23 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:39:06 --> Config Class Initialized
INFO - 2021-03-31 23:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:39:06 --> Utf8 Class Initialized
INFO - 2021-03-31 23:39:06 --> URI Class Initialized
INFO - 2021-03-31 23:39:06 --> Router Class Initialized
INFO - 2021-03-31 23:39:06 --> Output Class Initialized
INFO - 2021-03-31 23:39:06 --> Security Class Initialized
DEBUG - 2021-03-31 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:39:06 --> Input Class Initialized
INFO - 2021-03-31 23:39:06 --> Language Class Initialized
INFO - 2021-03-31 23:39:06 --> Loader Class Initialized
INFO - 2021-03-31 23:39:06 --> Helper loaded: url_helper
INFO - 2021-03-31 23:39:06 --> Helper loaded: form_helper
INFO - 2021-03-31 23:39:06 --> Helper loaded: common_helper
INFO - 2021-03-31 23:39:06 --> Helper loaded: util_helper
INFO - 2021-03-31 23:39:06 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:39:06 --> Form Validation Class Initialized
INFO - 2021-03-31 23:39:06 --> Controller Class Initialized
INFO - 2021-03-31 23:39:06 --> Model Class Initialized
INFO - 2021-03-31 23:39:06 --> Model Class Initialized
INFO - 2021-03-31 23:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 23:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:39:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:39:06 --> Final output sent to browser
DEBUG - 2021-03-31 23:39:06 --> Total execution time: 0.0356
INFO - 2021-03-31 23:39:06 --> Config Class Initialized
INFO - 2021-03-31 23:39:06 --> Hooks Class Initialized
INFO - 2021-03-31 23:39:06 --> Config Class Initialized
INFO - 2021-03-31 23:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:39:06 --> Utf8 Class Initialized
DEBUG - 2021-03-31 23:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:39:06 --> URI Class Initialized
INFO - 2021-03-31 23:39:06 --> Utf8 Class Initialized
INFO - 2021-03-31 23:39:06 --> URI Class Initialized
INFO - 2021-03-31 23:39:06 --> Router Class Initialized
INFO - 2021-03-31 23:39:06 --> Router Class Initialized
INFO - 2021-03-31 23:39:06 --> Output Class Initialized
INFO - 2021-03-31 23:39:06 --> Security Class Initialized
INFO - 2021-03-31 23:39:06 --> Output Class Initialized
INFO - 2021-03-31 23:39:06 --> Security Class Initialized
DEBUG - 2021-03-31 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:39:06 --> Input Class Initialized
INFO - 2021-03-31 23:39:06 --> Language Class Initialized
DEBUG - 2021-03-31 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:39:06 --> Input Class Initialized
INFO - 2021-03-31 23:39:06 --> Language Class Initialized
ERROR - 2021-03-31 23:39:06 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 23:39:06 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:39:06 --> Config Class Initialized
INFO - 2021-03-31 23:39:06 --> Config Class Initialized
INFO - 2021-03-31 23:39:06 --> Hooks Class Initialized
INFO - 2021-03-31 23:39:06 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:39:06 --> Utf8 Class Initialized
DEBUG - 2021-03-31 23:39:06 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:39:06 --> Utf8 Class Initialized
INFO - 2021-03-31 23:39:06 --> URI Class Initialized
INFO - 2021-03-31 23:39:06 --> URI Class Initialized
INFO - 2021-03-31 23:39:06 --> Router Class Initialized
INFO - 2021-03-31 23:39:06 --> Router Class Initialized
INFO - 2021-03-31 23:39:06 --> Output Class Initialized
INFO - 2021-03-31 23:39:06 --> Output Class Initialized
INFO - 2021-03-31 23:39:06 --> Security Class Initialized
INFO - 2021-03-31 23:39:06 --> Security Class Initialized
DEBUG - 2021-03-31 23:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:39:06 --> Input Class Initialized
INFO - 2021-03-31 23:39:06 --> Input Class Initialized
INFO - 2021-03-31 23:39:06 --> Language Class Initialized
INFO - 2021-03-31 23:39:06 --> Language Class Initialized
ERROR - 2021-03-31 23:39:06 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 23:39:06 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:41:31 --> Config Class Initialized
INFO - 2021-03-31 23:41:31 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:41:31 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:31 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:31 --> URI Class Initialized
INFO - 2021-03-31 23:41:31 --> Router Class Initialized
INFO - 2021-03-31 23:41:31 --> Output Class Initialized
INFO - 2021-03-31 23:41:31 --> Security Class Initialized
DEBUG - 2021-03-31 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:41:31 --> Input Class Initialized
INFO - 2021-03-31 23:41:31 --> Language Class Initialized
INFO - 2021-03-31 23:41:31 --> Loader Class Initialized
INFO - 2021-03-31 23:41:31 --> Helper loaded: url_helper
INFO - 2021-03-31 23:41:31 --> Helper loaded: form_helper
INFO - 2021-03-31 23:41:31 --> Helper loaded: common_helper
INFO - 2021-03-31 23:41:31 --> Helper loaded: util_helper
INFO - 2021-03-31 23:41:31 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:41:31 --> Form Validation Class Initialized
INFO - 2021-03-31 23:41:31 --> Controller Class Initialized
INFO - 2021-03-31 23:41:31 --> Model Class Initialized
INFO - 2021-03-31 23:41:31 --> Model Class Initialized
INFO - 2021-03-31 23:41:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:41:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:41:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 23:41:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:41:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:41:31 --> Final output sent to browser
DEBUG - 2021-03-31 23:41:31 --> Total execution time: 0.0374
INFO - 2021-03-31 23:41:31 --> Config Class Initialized
INFO - 2021-03-31 23:41:31 --> Hooks Class Initialized
INFO - 2021-03-31 23:41:31 --> Config Class Initialized
DEBUG - 2021-03-31 23:41:31 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:31 --> Hooks Class Initialized
INFO - 2021-03-31 23:41:31 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:31 --> URI Class Initialized
DEBUG - 2021-03-31 23:41:31 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:31 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:31 --> Router Class Initialized
INFO - 2021-03-31 23:41:31 --> URI Class Initialized
INFO - 2021-03-31 23:41:31 --> Output Class Initialized
INFO - 2021-03-31 23:41:31 --> Router Class Initialized
INFO - 2021-03-31 23:41:31 --> Output Class Initialized
INFO - 2021-03-31 23:41:31 --> Security Class Initialized
INFO - 2021-03-31 23:41:31 --> Security Class Initialized
DEBUG - 2021-03-31 23:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:41:31 --> Input Class Initialized
INFO - 2021-03-31 23:41:31 --> Input Class Initialized
INFO - 2021-03-31 23:41:31 --> Language Class Initialized
INFO - 2021-03-31 23:41:31 --> Language Class Initialized
ERROR - 2021-03-31 23:41:31 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 23:41:31 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:41:31 --> Config Class Initialized
INFO - 2021-03-31 23:41:31 --> Config Class Initialized
INFO - 2021-03-31 23:41:31 --> Hooks Class Initialized
INFO - 2021-03-31 23:41:31 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-03-31 23:41:31 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:31 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:31 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:31 --> URI Class Initialized
INFO - 2021-03-31 23:41:31 --> URI Class Initialized
INFO - 2021-03-31 23:41:31 --> Router Class Initialized
INFO - 2021-03-31 23:41:31 --> Router Class Initialized
INFO - 2021-03-31 23:41:31 --> Output Class Initialized
INFO - 2021-03-31 23:41:31 --> Output Class Initialized
INFO - 2021-03-31 23:41:31 --> Security Class Initialized
INFO - 2021-03-31 23:41:31 --> Security Class Initialized
DEBUG - 2021-03-31 23:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-31 23:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:41:31 --> Input Class Initialized
INFO - 2021-03-31 23:41:31 --> Input Class Initialized
INFO - 2021-03-31 23:41:31 --> Language Class Initialized
INFO - 2021-03-31 23:41:31 --> Language Class Initialized
ERROR - 2021-03-31 23:41:31 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-31 23:41:31 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:41:35 --> Config Class Initialized
INFO - 2021-03-31 23:41:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:41:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:35 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:35 --> URI Class Initialized
INFO - 2021-03-31 23:41:35 --> Router Class Initialized
INFO - 2021-03-31 23:41:35 --> Output Class Initialized
INFO - 2021-03-31 23:41:35 --> Security Class Initialized
DEBUG - 2021-03-31 23:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:41:35 --> Input Class Initialized
INFO - 2021-03-31 23:41:35 --> Language Class Initialized
INFO - 2021-03-31 23:41:35 --> Loader Class Initialized
INFO - 2021-03-31 23:41:35 --> Helper loaded: url_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: form_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: common_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: util_helper
INFO - 2021-03-31 23:41:35 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:41:35 --> Form Validation Class Initialized
INFO - 2021-03-31 23:41:35 --> Controller Class Initialized
INFO - 2021-03-31 23:41:35 --> Model Class Initialized
INFO - 2021-03-31 23:41:35 --> Config Class Initialized
INFO - 2021-03-31 23:41:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:41:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:41:35 --> Utf8 Class Initialized
INFO - 2021-03-31 23:41:35 --> URI Class Initialized
INFO - 2021-03-31 23:41:35 --> Router Class Initialized
INFO - 2021-03-31 23:41:35 --> Output Class Initialized
INFO - 2021-03-31 23:41:35 --> Security Class Initialized
DEBUG - 2021-03-31 23:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:41:35 --> Input Class Initialized
INFO - 2021-03-31 23:41:35 --> Language Class Initialized
INFO - 2021-03-31 23:41:35 --> Loader Class Initialized
INFO - 2021-03-31 23:41:35 --> Helper loaded: url_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: form_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: common_helper
INFO - 2021-03-31 23:41:35 --> Helper loaded: util_helper
INFO - 2021-03-31 23:41:35 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:41:35 --> Form Validation Class Initialized
INFO - 2021-03-31 23:41:35 --> Controller Class Initialized
INFO - 2021-03-31 23:41:35 --> Model Class Initialized
INFO - 2021-03-31 23:41:35 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 23:41:35 --> Final output sent to browser
DEBUG - 2021-03-31 23:41:35 --> Total execution time: 0.0329
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
INFO - 2021-03-31 23:42:29 --> Loader Class Initialized
INFO - 2021-03-31 23:42:29 --> Helper loaded: url_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: form_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: common_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: util_helper
INFO - 2021-03-31 23:42:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:42:29 --> Form Validation Class Initialized
INFO - 2021-03-31 23:42:29 --> Controller Class Initialized
INFO - 2021-03-31 23:42:29 --> Model Class Initialized
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
INFO - 2021-03-31 23:42:29 --> Loader Class Initialized
INFO - 2021-03-31 23:42:29 --> Helper loaded: url_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: form_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: common_helper
INFO - 2021-03-31 23:42:29 --> Helper loaded: util_helper
INFO - 2021-03-31 23:42:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:42:29 --> Form Validation Class Initialized
INFO - 2021-03-31 23:42:29 --> Controller Class Initialized
INFO - 2021-03-31 23:42:29 --> Model Class Initialized
INFO - 2021-03-31 23:42:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:42:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:42:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-31 23:42:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:42:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:42:29 --> Final output sent to browser
DEBUG - 2021-03-31 23:42:29 --> Total execution time: 0.0365
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
ERROR - 2021-03-31 23:42:29 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
ERROR - 2021-03-31 23:42:29 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
ERROR - 2021-03-31 23:42:29 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:42:29 --> Config Class Initialized
INFO - 2021-03-31 23:42:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:29 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:29 --> URI Class Initialized
INFO - 2021-03-31 23:42:29 --> Router Class Initialized
INFO - 2021-03-31 23:42:29 --> Output Class Initialized
INFO - 2021-03-31 23:42:29 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:29 --> Input Class Initialized
INFO - 2021-03-31 23:42:29 --> Language Class Initialized
ERROR - 2021-03-31 23:42:29 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-31 23:42:33 --> Config Class Initialized
INFO - 2021-03-31 23:42:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:33 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:33 --> URI Class Initialized
INFO - 2021-03-31 23:42:33 --> Router Class Initialized
INFO - 2021-03-31 23:42:33 --> Output Class Initialized
INFO - 2021-03-31 23:42:33 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:33 --> Input Class Initialized
INFO - 2021-03-31 23:42:33 --> Language Class Initialized
INFO - 2021-03-31 23:42:33 --> Loader Class Initialized
INFO - 2021-03-31 23:42:33 --> Helper loaded: url_helper
INFO - 2021-03-31 23:42:33 --> Helper loaded: form_helper
INFO - 2021-03-31 23:42:33 --> Helper loaded: common_helper
INFO - 2021-03-31 23:42:33 --> Helper loaded: util_helper
INFO - 2021-03-31 23:42:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:42:33 --> Form Validation Class Initialized
INFO - 2021-03-31 23:42:33 --> Controller Class Initialized
INFO - 2021-03-31 23:42:33 --> Model Class Initialized
INFO - 2021-03-31 23:42:33 --> Model Class Initialized
INFO - 2021-03-31 23:42:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-31 23:42:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-31 23:42:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-31 23:42:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-31 23:42:33 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-31 23:42:33 --> Final output sent to browser
DEBUG - 2021-03-31 23:42:33 --> Total execution time: 0.0426
INFO - 2021-03-31 23:42:33 --> Config Class Initialized
INFO - 2021-03-31 23:42:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:33 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:33 --> URI Class Initialized
INFO - 2021-03-31 23:42:33 --> Router Class Initialized
INFO - 2021-03-31 23:42:33 --> Config Class Initialized
INFO - 2021-03-31 23:42:33 --> Hooks Class Initialized
INFO - 2021-03-31 23:42:33 --> Output Class Initialized
INFO - 2021-03-31 23:42:33 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:33 --> Utf8 Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:33 --> Input Class Initialized
INFO - 2021-03-31 23:42:33 --> Language Class Initialized
INFO - 2021-03-31 23:42:33 --> URI Class Initialized
INFO - 2021-03-31 23:42:33 --> Router Class Initialized
ERROR - 2021-03-31 23:42:33 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:42:33 --> Config Class Initialized
INFO - 2021-03-31 23:42:33 --> Hooks Class Initialized
INFO - 2021-03-31 23:42:33 --> Output Class Initialized
DEBUG - 2021-03-31 23:42:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:33 --> Security Class Initialized
INFO - 2021-03-31 23:42:33 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:33 --> URI Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:33 --> Input Class Initialized
INFO - 2021-03-31 23:42:33 --> Language Class Initialized
INFO - 2021-03-31 23:42:33 --> Router Class Initialized
INFO - 2021-03-31 23:42:33 --> Output Class Initialized
ERROR - 2021-03-31 23:42:33 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:42:33 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:33 --> Input Class Initialized
INFO - 2021-03-31 23:42:33 --> Language Class Initialized
ERROR - 2021-03-31 23:42:33 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:42:33 --> Config Class Initialized
INFO - 2021-03-31 23:42:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:33 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:33 --> URI Class Initialized
INFO - 2021-03-31 23:42:33 --> Router Class Initialized
INFO - 2021-03-31 23:42:33 --> Output Class Initialized
INFO - 2021-03-31 23:42:33 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:33 --> Input Class Initialized
INFO - 2021-03-31 23:42:33 --> Language Class Initialized
ERROR - 2021-03-31 23:42:33 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-31 23:42:39 --> Config Class Initialized
INFO - 2021-03-31 23:42:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:39 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:39 --> URI Class Initialized
INFO - 2021-03-31 23:42:39 --> Router Class Initialized
INFO - 2021-03-31 23:42:39 --> Output Class Initialized
INFO - 2021-03-31 23:42:39 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:39 --> Input Class Initialized
INFO - 2021-03-31 23:42:39 --> Language Class Initialized
INFO - 2021-03-31 23:42:39 --> Loader Class Initialized
INFO - 2021-03-31 23:42:39 --> Helper loaded: url_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: form_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: common_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: util_helper
INFO - 2021-03-31 23:42:39 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:42:39 --> Form Validation Class Initialized
INFO - 2021-03-31 23:42:39 --> Controller Class Initialized
INFO - 2021-03-31 23:42:39 --> Model Class Initialized
INFO - 2021-03-31 23:42:39 --> Config Class Initialized
INFO - 2021-03-31 23:42:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 23:42:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 23:42:39 --> Utf8 Class Initialized
INFO - 2021-03-31 23:42:39 --> URI Class Initialized
INFO - 2021-03-31 23:42:39 --> Router Class Initialized
INFO - 2021-03-31 23:42:39 --> Output Class Initialized
INFO - 2021-03-31 23:42:39 --> Security Class Initialized
DEBUG - 2021-03-31 23:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 23:42:39 --> Input Class Initialized
INFO - 2021-03-31 23:42:39 --> Language Class Initialized
INFO - 2021-03-31 23:42:39 --> Loader Class Initialized
INFO - 2021-03-31 23:42:39 --> Helper loaded: url_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: form_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: common_helper
INFO - 2021-03-31 23:42:39 --> Helper loaded: util_helper
INFO - 2021-03-31 23:42:39 --> Database Driver Class Initialized
DEBUG - 2021-03-31 23:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 23:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 23:42:39 --> Form Validation Class Initialized
INFO - 2021-03-31 23:42:39 --> Controller Class Initialized
INFO - 2021-03-31 23:42:39 --> Model Class Initialized
INFO - 2021-03-31 23:42:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-31 23:42:39 --> Final output sent to browser
DEBUG - 2021-03-31 23:42:39 --> Total execution time: 0.0307
