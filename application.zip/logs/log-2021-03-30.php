INFO - 2021-03-30 23:35:10 --> Config Class Initialized
INFO - 2021-03-30 23:35:10 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:35:10 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:35:10 --> Utf8 Class Initialized
INFO - 2021-03-30 23:35:10 --> URI Class Initialized
INFO - 2021-03-30 23:35:10 --> Router Class Initialized
INFO - 2021-03-30 23:35:10 --> Output Class Initialized
INFO - 2021-03-30 23:35:10 --> Security Class Initialized
DEBUG - 2021-03-30 23:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:35:10 --> Input Class Initialized
INFO - 2021-03-30 23:35:10 --> Language Class Initialized
ERROR - 2021-03-30 23:35:10 --> 404 Page Not Found: administrator/Company/add
INFO - 2021-03-30 23:35:14 --> Config Class Initialized
INFO - 2021-03-30 23:35:14 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:35:14 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:35:14 --> Utf8 Class Initialized
INFO - 2021-03-30 23:35:14 --> URI Class Initialized
INFO - 2021-03-30 23:35:14 --> Router Class Initialized
INFO - 2021-03-30 23:35:14 --> Output Class Initialized
INFO - 2021-03-30 23:35:14 --> Security Class Initialized
DEBUG - 2021-03-30 23:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:35:14 --> Input Class Initialized
INFO - 2021-03-30 23:35:14 --> Language Class Initialized
ERROR - 2021-03-30 23:35:14 --> 404 Page Not Found: administrator/Company/add
INFO - 2021-03-30 23:35:17 --> Config Class Initialized
INFO - 2021-03-30 23:35:17 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:35:17 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:35:17 --> Utf8 Class Initialized
INFO - 2021-03-30 23:35:17 --> URI Class Initialized
INFO - 2021-03-30 23:35:17 --> Router Class Initialized
INFO - 2021-03-30 23:35:17 --> Output Class Initialized
INFO - 2021-03-30 23:35:17 --> Security Class Initialized
DEBUG - 2021-03-30 23:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:35:17 --> Input Class Initialized
INFO - 2021-03-30 23:35:17 --> Language Class Initialized
ERROR - 2021-03-30 23:35:17 --> 404 Page Not Found: administrator/Company/add
INFO - 2021-03-30 23:36:32 --> Config Class Initialized
INFO - 2021-03-30 23:36:32 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:36:32 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:36:32 --> Utf8 Class Initialized
INFO - 2021-03-30 23:36:32 --> URI Class Initialized
INFO - 2021-03-30 23:36:32 --> Router Class Initialized
INFO - 2021-03-30 23:36:32 --> Output Class Initialized
INFO - 2021-03-30 23:36:32 --> Security Class Initialized
DEBUG - 2021-03-30 23:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:36:32 --> Input Class Initialized
INFO - 2021-03-30 23:36:32 --> Language Class Initialized
ERROR - 2021-03-30 23:36:32 --> 404 Page Not Found: administrator/Company/add
INFO - 2021-03-30 23:37:06 --> Config Class Initialized
INFO - 2021-03-30 23:37:06 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:37:06 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:37:06 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:06 --> URI Class Initialized
INFO - 2021-03-30 23:37:06 --> Router Class Initialized
INFO - 2021-03-30 23:37:06 --> Output Class Initialized
INFO - 2021-03-30 23:37:06 --> Security Class Initialized
DEBUG - 2021-03-30 23:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:37:06 --> Input Class Initialized
INFO - 2021-03-30 23:37:06 --> Language Class Initialized
INFO - 2021-03-30 23:37:06 --> Loader Class Initialized
INFO - 2021-03-30 23:37:06 --> Helper loaded: url_helper
INFO - 2021-03-30 23:37:06 --> Helper loaded: form_helper
INFO - 2021-03-30 23:37:06 --> Helper loaded: common_helper
INFO - 2021-03-30 23:37:06 --> Helper loaded: util_helper
INFO - 2021-03-30 23:37:06 --> Database Driver Class Initialized
DEBUG - 2021-03-30 23:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-30 23:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-30 23:37:06 --> Form Validation Class Initialized
INFO - 2021-03-30 23:37:06 --> Controller Class Initialized
INFO - 2021-03-30 23:37:06 --> Model Class Initialized
INFO - 2021-03-30 23:37:25 --> Config Class Initialized
INFO - 2021-03-30 23:37:25 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:37:25 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:25 --> URI Class Initialized
INFO - 2021-03-30 23:37:25 --> Router Class Initialized
INFO - 2021-03-30 23:37:25 --> Output Class Initialized
INFO - 2021-03-30 23:37:25 --> Security Class Initialized
DEBUG - 2021-03-30 23:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:37:25 --> Input Class Initialized
INFO - 2021-03-30 23:37:25 --> Language Class Initialized
INFO - 2021-03-30 23:37:25 --> Loader Class Initialized
INFO - 2021-03-30 23:37:25 --> Helper loaded: url_helper
INFO - 2021-03-30 23:37:25 --> Helper loaded: form_helper
INFO - 2021-03-30 23:37:25 --> Helper loaded: common_helper
INFO - 2021-03-30 23:37:25 --> Helper loaded: util_helper
INFO - 2021-03-30 23:37:25 --> Database Driver Class Initialized
DEBUG - 2021-03-30 23:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-30 23:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-30 23:37:25 --> Form Validation Class Initialized
INFO - 2021-03-30 23:37:25 --> Controller Class Initialized
INFO - 2021-03-30 23:37:25 --> Model Class Initialized
INFO - 2021-03-30 23:37:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-30 23:37:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-30 23:37:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-30 23:37:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-30 23:37:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-30 23:37:25 --> Final output sent to browser
DEBUG - 2021-03-30 23:37:25 --> Total execution time: 0.0361
INFO - 2021-03-30 23:37:25 --> Config Class Initialized
INFO - 2021-03-30 23:37:25 --> Config Class Initialized
INFO - 2021-03-30 23:37:25 --> Hooks Class Initialized
INFO - 2021-03-30 23:37:25 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-03-30 23:37:25 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:25 --> URI Class Initialized
INFO - 2021-03-30 23:37:25 --> URI Class Initialized
INFO - 2021-03-30 23:37:25 --> Router Class Initialized
INFO - 2021-03-30 23:37:25 --> Router Class Initialized
INFO - 2021-03-30 23:37:25 --> Output Class Initialized
INFO - 2021-03-30 23:37:25 --> Output Class Initialized
INFO - 2021-03-30 23:37:25 --> Security Class Initialized
INFO - 2021-03-30 23:37:25 --> Security Class Initialized
DEBUG - 2021-03-30 23:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:37:25 --> Input Class Initialized
INFO - 2021-03-30 23:37:25 --> Language Class Initialized
ERROR - 2021-03-30 23:37:25 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-03-30 23:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:37:25 --> Input Class Initialized
INFO - 2021-03-30 23:37:25 --> Language Class Initialized
ERROR - 2021-03-30 23:37:25 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-30 23:37:25 --> Config Class Initialized
INFO - 2021-03-30 23:37:25 --> Hooks Class Initialized
INFO - 2021-03-30 23:37:25 --> Config Class Initialized
DEBUG - 2021-03-30 23:37:25 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:37:25 --> Hooks Class Initialized
INFO - 2021-03-30 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:25 --> URI Class Initialized
DEBUG - 2021-03-30 23:37:25 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-30 23:37:25 --> Router Class Initialized
INFO - 2021-03-30 23:37:25 --> URI Class Initialized
INFO - 2021-03-30 23:37:25 --> Router Class Initialized
INFO - 2021-03-30 23:37:25 --> Output Class Initialized
INFO - 2021-03-30 23:37:25 --> Output Class Initialized
INFO - 2021-03-30 23:37:25 --> Security Class Initialized
DEBUG - 2021-03-30 23:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:37:25 --> Input Class Initialized
INFO - 2021-03-30 23:37:25 --> Security Class Initialized
INFO - 2021-03-30 23:37:25 --> Language Class Initialized
DEBUG - 2021-03-30 23:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-30 23:37:25 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-30 23:37:25 --> Input Class Initialized
INFO - 2021-03-30 23:37:25 --> Language Class Initialized
ERROR - 2021-03-30 23:37:25 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-30 23:39:40 --> Config Class Initialized
INFO - 2021-03-30 23:39:40 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:39:40 --> Utf8 Class Initialized
INFO - 2021-03-30 23:39:40 --> URI Class Initialized
INFO - 2021-03-30 23:39:40 --> Router Class Initialized
INFO - 2021-03-30 23:39:40 --> Output Class Initialized
INFO - 2021-03-30 23:39:40 --> Security Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:39:40 --> Input Class Initialized
INFO - 2021-03-30 23:39:40 --> Language Class Initialized
INFO - 2021-03-30 23:39:40 --> Loader Class Initialized
INFO - 2021-03-30 23:39:40 --> Helper loaded: url_helper
INFO - 2021-03-30 23:39:40 --> Helper loaded: form_helper
INFO - 2021-03-30 23:39:40 --> Helper loaded: common_helper
INFO - 2021-03-30 23:39:40 --> Helper loaded: util_helper
INFO - 2021-03-30 23:39:40 --> Database Driver Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-30 23:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-30 23:39:40 --> Form Validation Class Initialized
INFO - 2021-03-30 23:39:40 --> Controller Class Initialized
INFO - 2021-03-30 23:39:40 --> Model Class Initialized
INFO - 2021-03-30 23:39:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-30 23:39:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-30 23:39:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-03-30 23:39:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-30 23:39:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-30 23:39:40 --> Final output sent to browser
DEBUG - 2021-03-30 23:39:40 --> Total execution time: 0.0485
INFO - 2021-03-30 23:39:40 --> Config Class Initialized
INFO - 2021-03-30 23:39:40 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:39:40 --> Utf8 Class Initialized
INFO - 2021-03-30 23:39:40 --> Config Class Initialized
INFO - 2021-03-30 23:39:40 --> URI Class Initialized
INFO - 2021-03-30 23:39:40 --> Hooks Class Initialized
INFO - 2021-03-30 23:39:40 --> Router Class Initialized
INFO - 2021-03-30 23:39:40 --> Output Class Initialized
DEBUG - 2021-03-30 23:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:39:40 --> Utf8 Class Initialized
INFO - 2021-03-30 23:39:40 --> URI Class Initialized
INFO - 2021-03-30 23:39:40 --> Security Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:39:40 --> Input Class Initialized
INFO - 2021-03-30 23:39:40 --> Router Class Initialized
INFO - 2021-03-30 23:39:40 --> Language Class Initialized
INFO - 2021-03-30 23:39:40 --> Output Class Initialized
ERROR - 2021-03-30 23:39:40 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-30 23:39:40 --> Security Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:39:40 --> Input Class Initialized
INFO - 2021-03-30 23:39:40 --> Language Class Initialized
ERROR - 2021-03-30 23:39:40 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-03-30 23:39:40 --> Config Class Initialized
INFO - 2021-03-30 23:39:40 --> Hooks Class Initialized
DEBUG - 2021-03-30 23:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:39:40 --> Utf8 Class Initialized
INFO - 2021-03-30 23:39:40 --> Config Class Initialized
INFO - 2021-03-30 23:39:40 --> Hooks Class Initialized
INFO - 2021-03-30 23:39:40 --> URI Class Initialized
DEBUG - 2021-03-30 23:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-30 23:39:40 --> Utf8 Class Initialized
INFO - 2021-03-30 23:39:40 --> Router Class Initialized
INFO - 2021-03-30 23:39:40 --> URI Class Initialized
INFO - 2021-03-30 23:39:40 --> Output Class Initialized
INFO - 2021-03-30 23:39:40 --> Router Class Initialized
INFO - 2021-03-30 23:39:40 --> Security Class Initialized
INFO - 2021-03-30 23:39:40 --> Output Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:39:40 --> Input Class Initialized
INFO - 2021-03-30 23:39:40 --> Security Class Initialized
INFO - 2021-03-30 23:39:40 --> Language Class Initialized
DEBUG - 2021-03-30 23:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-30 23:39:40 --> Input Class Initialized
INFO - 2021-03-30 23:39:40 --> Language Class Initialized
ERROR - 2021-03-30 23:39:40 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-03-30 23:39:40 --> 404 Page Not Found: administrator/Company/dist
