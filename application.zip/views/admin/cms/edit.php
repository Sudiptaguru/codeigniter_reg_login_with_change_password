<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/CMS')?>">List CMs</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-12">

   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Edit CMS</h3>
      </div>
      <!-- /.card-header -->


       <div class="card-body">   
         <form action="<?= base_url('cms/updateData') ?>" method="post">
            <input type="hidden" class="" id="" name="cms_id" value="<?php echo $cms['cms_id'] ?>" placeholder="Enter Title">
            <div class="form-group">
               <label for="exampleInputEmail1"> Page Title</label>
               <input type="text" class="form-control" id="title" name="title" value="<?php echo $cms['title'] ?>" placeholder="Enter Title">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Page Slug</label>
               <input type="text" class="form-control" id="page_slug" name="page_slug" value="<?php echo $cms['page_slug'] ?>" placeholder="Enter Page Slug">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Description</label>
              
                <textarea name="slug" value="" placeholder="Enter content"><?php echo $cms['content'] ?>
                </textarea>
            </div>
           
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
      
     </div>
      </div>
</section>
</div>
<script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
<script>
   CKEDITOR.replace( 'slug' );
</script>