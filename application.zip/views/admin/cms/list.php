<?php
if ($this -> session -> userdata('is_logged'))  {?>

<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Cms/add')?>"><i class="fa fa-plus"></i> Add CMS</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
        <div class="col-md-12">
            <!-- general form elements -->
            <?php echo validation_errors(); ?>
            <?php
               if($this -> session -> flashdata('success')) {?>
            <div class="alert alert-info" role="alert">
               <?=$this -> session -> flashdata('success')?>
            </div>
            <?php } ?>
            <?php
               if($this -> session -> flashdata('error')) {?>
            <div class="alert alert-danger" role="alert">
               <?=$this -> session -> flashdata('error')?>
            </div>
            <?php } ?>
         </div>
    <!-- Main content -->
    <?php include "section.php"; ?>
  </div>
  <?php } else { ?>
  <?php include "dashboard_record.php"; ?>
<?php }