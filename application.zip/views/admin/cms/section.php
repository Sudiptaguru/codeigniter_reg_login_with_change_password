<section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div> -->
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">CMS List</h3>

                <!-- <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div> -->
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                     
                       <th>Sno.</th>
                      <th>Title</th>
                      <th>Page Slug</th>              
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if (count($cms)){

                    foreach ($cms as  $k => $u) {

                      ?>
                    <tr>
                       <td><?=$k+1?></td>
                     
                      <td><?=$u['title']?></td>
                      <td><?=$u['page_slug']?></td>
                      <td>
                      <a  href="<?=base_url('cms/update/'.$u['cms_id'])?>">Edit</a> | 
                      <a onclick ="return confirm('Do you want to delete?');" href="<?=base_url('administrator/Cms/delete_row/'.$u['cms_id'])?>">Delete</a> 

                      <!-- <a  href="<?php echo base_url('administrator/Cms/delete_row/'.$cms_id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fa fa-trash"></i></a> -->
                    </td>
                    </tr>
                   <?php 
                 }
                 }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>