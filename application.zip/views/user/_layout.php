<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="<?=base_url()?>fassets/img/fav-icon.png">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/theme.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/responsive.css">
<title>Food Track</title>
</head>
<body>

	<div class="container-fluid">
		<div class="row align-items-center">
			<div class="col-md-6">
				<div class="logo">
					<a href="<?= base_url(); ?>"><i class="fas fa-home"></i></a>
				</div>
			</div>
			<div class="col-md-6">
				<ul class="top-list">
					<li><a href="<?=base_url('Home/logout')?>">Sign Out</a></li>
				</ul>
			</div>
		</div>

		<?php $this -> load -> view($main) ?>

	<ul class="footer-menu">
			<li><a href="#">Advertising Programs</a></li>
			<li><a href="#">Privacy & Terms</a></li>
			<li><a href="#">About WITFT</a></li>
		</ul>
	</div>


 


<!-- Bootstrap core JavaScript --> 
<!--<script src="https://code.jquery.com/jquery-3.4.1.js"></script>--> 
<script src="<?=base_url()?>fassets/js/jquery.1.11.3.min.js"></script>
<script src="<?=base_url()?>fassets/js/owl.carousel.js"></script>  
<script src="<?=base_url()?>fassets/js/bootstrap.min.js"></script> 	
<script src="<?=base_url()?>fassets/js/theme.js"></script> 
</body>
</html>
<script type="text/javascript">
    $("#mobile").keypress(function (e) {
        //if the letter is not digit then display error and don't type anything
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
          
                 return false;
        }
      });
    function readURL(input) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function(e) {
	            $('#imagePreview').css('background-image', 'url('+e.target.result +')');
	            $('#imagePreview').hide();
	            $('#imagePreview').fadeIn(650);
	        }
	        reader.readAsDataURL(input.files[0]);
	    }
	}
    $("#imageUpload").change(function() {
	    readURL(this);
	    alert("hello");
	    var file_data = $(this).prop('files')[0];
	    var form_data = new FormData();
        form_data.append('profile_image', file_data);
        form_data.append('user_id',"<?php echo $this->session->userdata('user_id'); ?>");
	    $.ajax({
	        url: '<?= base_url()?>/users/UpdateProfileImage', // point to server-side controller method
	        dataType: 'text', // what to expect back from the server
	        cache: false,
	        contentType: false,
	        processData: false,
	        data: form_data,
	        type: 'post',
	        dataType: "json",
	        success: function (res) {
	        	// console.log(res.success);
	           	if (res.success == 1) {
					swal("Success", res.message, "success");
					GetProfileDetails();
				}else{
					swal("Error", res.message, "error");
				};
	        }
	        
	    });
	});
  </script>