<!-- <b>
        <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
  </b> -->
<form action="<?php echo base_url() ?>user/Dashboard/update" method="post">
<div class="template-format">
   <h1 class="page-title">WHERE is that FOOD TRUCK?</h1>
   <div class="row">
    <div class="col-md-2">
     <div class="ad-sec">
      <h4>PAID AD</h4>
     </div>
    </div>
    <div class="col-md-8">
     <div class="middle-sec">
      <div class="account-sec">
       <div class="cover-pic">
        <img src="<?=base_url()?>fassets/img/cover-pic.jpg" width="100%">
        <h3>MY ACCOUNT</h3>
       </div>

       <input type="hidden" value="<?php echo $account_detail['user_id']?>" name="user_id" class="form-control">
       <div class="edit-profile">
        <div class="edit-profile-top">
         <div class="info-profile-img">
         <img src="<?=base_url()?>fassets/img/profile-pic.jpg" class="profile-pic">
         <div class="p-image">
          <label><i class="fas fa-pencil-alt"></i></label>
          <input type="file" id="imageUpload" class="file-upload">
         </div>
        </div>
        <!-- <h5>steve@smith</h5> -->
        </div>
      
       <div class="row">
        <div class="col-md-12">
         <div class="form-group">
          <input type="text" value="<?php echo $account_detail['first_name']?>" name="first_name" class="form-control" placeholder="First Name" required>
         </div>
        </div>
        <div class="col-md-12">
         <div class="form-group">
          <input type="text" value="<?php echo $account_detail['last_name']?>" name="last_name" class="form-control" placeholder="Last Name" required>
         </div>
        </div>
        <div class="col-md-12">
         <div class="form-group">
          <input type="email" value="<?php echo $account_detail['email']?>" name="email" class="form-control" readonly placeholder="Email Address" required>
         </div>
        </div>
        <div class="col-md-12">
         <div class="form-group">
          <input type="text" id="mobile" pattern=".{10}"  required title="10 Digit Mobile Number" maxlength="10" value="<?php echo $account_detail['mobile']?>" name="mobile" class="form-control" placeholder="Phone Number" required>
         </div>
        </div>
        <!-- <div class="col-md-12">
         <div class="form-group">
          <select class="form-control">
           <option>Select State</option>
          </select>
         </div>
        </div> -->
        <!-- <div class="col-md-6">
         <div class="form-group">
          <input type="password" value="******" class="form-control">
         </div>
        </div> -->
        <!-- <div class="col-md-6">
         <div class="form-group">
          <a href="#" style="color: #ff6f2a;font-size: 12px">Change Password</a>
         </div>
        </div> -->
        <div class="col-md-12">
         <div class="form-group  text-center">
          <button type="submit">UPDATE</button>
         </div>
        </div>
       </div>
       </div>
      </div>
     </div>
    </div>
    <div class="col-md-2">
     <div class="ad-sec">
      <h4>PAID AD</h4>
     </div>
    </div>
   </div>
  </div>
  </form>
  