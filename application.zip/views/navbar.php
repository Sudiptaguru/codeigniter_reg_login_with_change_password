<ul class="top-list">
			<li><a href="#">Sign In</a></li>
			<li><a href="#">Register</a></li>
		</ul>