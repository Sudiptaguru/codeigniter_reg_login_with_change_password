
<div class="dashcontent_right">
		
		<div class="dashboard_right_header">
			<div class="form_box addprofilemain">
			<?php echo validation_errors()?>			
				
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>
			
			 <?php if($this -> session -> flashdata('error')) {?>
                <div class="alert alert-danger" role="alert">
                  <?=$this -> session -> flashdata('error')?>
                </div>

            <?php } ?>
			<form action="" id="form-profile" method="post" autocomplete="off">			
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						
							
							
								
								<div class="form-group col-md-6">									
		Old Password:<input class="form-control" name="oldpass" type="password"  value="<?=set_value('oldpass')?>" placeholder="Old password..." />
								</div>
							
							
							
							
								
								<div class="form-group col-md-6">									
		New Password:<input class="form-control" name="newpass" type="password" required  placeholder="New password..." value="<?=set_value('newpass')?>" />
								</div>
							
							
							
								
								<div class="form-group col-md-6">									
		Confirm Password:<input class="form-control" type="password" name="passconf"  required placeholder="Confirm password..." value="<?=set_value('passconf')?>"/>
								</div>
								<div class="form-group col-md-6">
									<button href="javascript:;" id="publish"  class="btn btn-primary">UPDATE</button>
								</div>
								
											
						
					</div>
					
				</div>
				
				</form>
			</div>
		</div>
		
	</div>
	

<script>
$(function(){
	$("#publish").click(function(){
		$("#form-profile").submit();
	});
});
</script>