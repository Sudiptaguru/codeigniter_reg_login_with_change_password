<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?=$title?> | <?= $this -> sitename ?></title>

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <!-- <link rel="stylesheet" href="<?=base_url()?>vendor/bootstrap/css/bootstrap.min.css"> -->
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?=base_url()?>vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="<?=base_url()?>css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="<?=base_url()?>https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="<?=base_url()?>css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="<?=base_url()?>vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?=base_url()?>css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?=base_url()?>css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?=base_url()?>img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/theme.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/responsive.css">
    <style>
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #4d4d4d;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>

        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <?php
                    if ($this -> session -> userdata('is_logged'))  {?>
                      <li class="nav-item dropdown">
                      <a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle">Records</a>
                      <ul class="dropdown-content" aria-labelledby="languages">
                        <li><a rel="nofollow" href="<?=base_url('administrator/Cms/index')?>" class="dropdown-item"><span>List of Records</span></a></li>
                      </ul>
                    </li>
                    <?php } ?>
                  

                  <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                    <?php
                    if ($this -> session -> userdata('is_logged'))  {?>
                      <li class="nav-item dropdown"><a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle"><span class="d-none d-sm-inline-block"><?=$_SESSION['first_name']?></span></a>
                        <ul aria-labelledby="languages" class="dropdown-menu">
                        	<li><a rel="nofollow" href="<?=base_url('provider/Profile/changepassword')?>" class="dropdown-item"><span>Change Password</span></a></li>
                          <li><a rel="nofollow" href="<?=base_url('Home/logout')?>" class="dropdown-item"><span>Logout</span></a></li>
                        </ul>
                          <?php } else { ?>
                          <li><a rel="nofollow" href="<?=base_url('register')?>?utype=user" class="dropdown-item"><span>Register</span></a></li>
                          <li><a rel="nofollow" href="<?=base_url('login')?>" class="dropdown-item"><span>Login</span></a></li>
                      </li>
                    <?php } ?>
                      
                  </ul>
            </div>
          </div>
        </nav>

        <!-- Counts Section -->
      

<div class="dashboard_content">

	<?php $this -> load -> view($main) ?>
	<div class="clr"></div>
</div>
      <!-- Header Section-->
 
    <!-- JavaScript files-->
    <script src="<?=base_url()?>vendor/jquery/jquery.min.js"></script>
    <script src="<?=base_url()?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url()?>js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="<?=base_url()?>vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="<?=base_url()?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?=base_url()?>vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?=base_url()?>js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>

    <script>
      $('.sub-menu ul').hide();
      $(".sub-menu a").click(function () {
        $(this).parent(".sub-menu").children("ul").slideToggle("100");
        $(this).find(".right").toggleClass("fa-caret-up fa-caret-down");
      });
    </script>
  </body>
</html>

