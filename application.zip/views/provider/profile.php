<div class="dashcontent_right">
		
		<div class="dashboard_right_header">
			<h2>Update Profile <a href="javascript:;" id="publish"  class="addnewdashboard">PUBLISH</a><a href="" class="cancelnewdashboard">CANCEL</a></h2>
			<div class="form_box addprofilemain">
			<?php echo validation_errors()?>			
					  <?php 
		  if($this -> session -> flashdata('uploaderror')) {
				echo $this -> session -> flashdata('uploaderror');
		       }
		  ?>
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>
			
			 <?php if($this -> session -> flashdata('error')) {?>
                <div class="alert alert-danger" role="alert">
                  <?=$this -> session -> flashdata('error')?>
                </div>

            <?php } ?>
			<form action="" id="form-profile" method="post" autocomplete="off" enctype="multipart/form-data">			
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="row">
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<label>First Name :</label>									
								</div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">									
									<input class="form-control" name="first_name" type="text" value="<?=set_value('first_name',$detail['first_name'])?>" />
								</div>
							</div>
														
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<label>Last Name :</label>									
								</div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">									
									<input class="form-control" type="text" name="last_name" value="<?=set_value('last_name',$detail['last_name'])?>" />
								</div>
							</div>
							
							
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<label>Email ID :</label>									
								</div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">									
									<input class="form-control" type="text" disabled value="<?=$detail['email']?>" />
								</div>
							</div>
							
							
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<label>Contact Number :</label>									
								</div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">									
							<input class="form-control" name="contact" type="text" value="<?=set_value('contact',$detail['mobile'])?>" />
								</div>
							</div>
													
							
							
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<label>Upload Image :</label>									
								</div>
							</div>
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">									
									<div class="fileUpload">
										<input type="file" class="upload"  id="file" name="files[]" onchange="previewFile(this);" />
										<span>Upload</span>
									</div>
									<div class="profile_img">
									<?php
									if ($detail['profile_pic'] == "") {?>
										<img class="previewImg" src="<?=base_url()?>fassets/img/profile_img.jpg" alt="profile_img"/>
									<?php } else {?>
									
									<img  class="previewImg" src="<?=base_url()?>uploads/profile/<?=$detail['profile_pic']?>" alt="profile_img"/>
									<?php } ?>
									</div>
									<div class="clear"></div>
								</div>
								
								
							</div>						
						</div>
					</div>
					
				</div>
				<input type="hidden" name="old_image" value="<?=$detail['profile_pic']?>" />
				</form>
			</div>
		</div>
		
	</div>
	
<script>
    function previewFile(input){
        var file = $("input[type=file]").get(0).files[0];
 
        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $(".previewImg").attr("src", reader.result);
            }
 
            reader.readAsDataURL(file);
        }
    }
</script>
<script>
$(function(){
	$("#publish").click(function(){
		$("#form-profile").submit();
	});
});
</script>